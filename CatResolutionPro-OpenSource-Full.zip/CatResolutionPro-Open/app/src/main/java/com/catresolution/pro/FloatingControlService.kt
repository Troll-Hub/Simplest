package com.catresolution.pro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat

class FloatingControlService : Service() {
    companion object {
        @Volatile var running = false
        fun start(ctx: Context) {
            ctx.startForegroundService(Intent(ctx, FloatingControlService::class.java))
        }
        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, FloatingControlService::class.java))
        }
    }

    private var wm: WindowManager? = null
    private var bubble: View? = null
    private var ratio = 150
    private var vertical = true

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        createChannel()
        startForeground(42, buildNotif())
        showBubble()
    }

    override fun onDestroy() {
        running = false
        removeBubble()
        WmController.reset()
        WmController.disconnect()
        super.onDestroy()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("float", getString(R.string.channel_floating), NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotif(): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "float")
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_floating))
            .setSmallIcon(android.R.drawable.ic_menu_crop)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun showBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 20
            y = 200
        }

        val tv = TextView(this).apply {
            text = "CR ${ratio / 100f}"
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xE0FF6B00.toInt())
            setPadding(28, 18, 28, 18)
            textSize = 14f
            setOnTouchListener(DragTouch(params))
            setOnClickListener {
                ratio = if (ratio >= 180) 100 else ratio + 10
                text = "CR ${ratio / 100f}"
                WmController.apply(ratio, vertical)
            }
            setOnLongClickListener {
                vertical = !vertical
                text = "CR ${ratio / 100f}${if (vertical) " V" else " H"}"
                WmController.apply(ratio, vertical)
                true
            }
        }
        bubble = tv
        wm?.addView(tv, params)
    }

    private fun removeBubble() {
        bubble?.let { try { wm?.removeView(it) } catch (_: Throwable) {} }
        bubble = null
    }

    private inner class DragTouch(private val p: WindowManager.LayoutParams) : View.OnTouchListener {
        private var ix = 0f
        private var iy = 0f
        private var px = 0
        private var py = 0
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    ix = e.rawX; iy = e.rawY; px = p.x; py = p.y
                    return false
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = px + (ix - e.rawX).toInt()
                    p.y = py + (e.rawY - iy).toInt()
                    wm?.updateViewLayout(v, p)
                    return true
                }
            }
            return false
        }
    }
}
