package com.catresolution.pro

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.edit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CatResolutionTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF0D0D0D)) {
                    MainScreen()
                }
            }
        }
    }
}

@Composable
fun CatResolutionTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFFF6B00),
            secondary = Color(0xFFFF9A3C),
            background = Color(0xFF0D0D0D),
            surface = Color(0xFF1A1A1A),
            onPrimary = Color.Black,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}

@Composable
fun MainScreen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("crp", Context.MODE_PRIVATE) }
    var ratio by remember { mutableIntStateOf(prefs.getInt("r", 150)) }
    var vertical by remember { mutableStateOf(prefs.getBoolean("axis", true)) }
    var projMode by remember { mutableStateOf(prefs.getBoolean("proj", true)) }
    var status by remember { mutableStateOf("Listo · open source") }
    var applied by remember { mutableStateOf(prefs.getBoolean("applied", false)) }
    var showDiag by remember { mutableStateOf(false) }
    var diagText by remember { mutableStateOf("") }
    var shizukuState by remember { mutableStateOf(HorizonBridge.state().name) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(16.dp))
        Text("CAT RESOLUTION PRO", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color(0xFFFF6B00))
        Text("Open Source · Full Compatibility", fontSize = 12.sp, color = Color(0xFF888888))
        Spacer(Modifier.height(8.dp))
        Text("Shizuku: $shizukuState", fontSize = 11.sp, color = Color(0xFF666666))

        Spacer(Modifier.height(20.dp))

        // Ratio card
        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("Factor de estiramiento", color = Color(0xFFAAAAAA), fontSize = 13.sp)
                Text("${"%.2f".format(ratio / 100f)}", fontSize = 48.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Slider(
                    value = ratio.toFloat(),
                    onValueChange = { ratio = it.toInt() },
                    valueRange = 100f..199f,
                    steps = 98,
                    colors = SliderDefaults.colors(thumbColor = Color(0xFFFF6B00), activeTrackColor = Color(0xFFFF6B00))
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    listOf(100, 120, 140, 150, 160, 180).forEach { p ->
                        TextButton(onClick = { ratio = p }, contentPadding = PaddingValues(4.dp)) {
                            Text("${p / 100f}", fontSize = 11.sp, color = if (ratio == p) Color(0xFFFF6B00) else Color(0xFF888888))
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilterChip(selected = vertical, onClick = { vertical = true }, label = { Text("Vertical") },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFFFF6B00), selectedLabelColor = Color.Black),
                modifier = Modifier.weight(1f))
            FilterChip(selected = !vertical, onClick = { vertical = false }, label = { Text("Horizontal") },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFFFF6B00), selectedLabelColor = Color.Black),
                modifier = Modifier.weight(1f))
        }

        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Modo Pro (SurfaceFlinger)", color = Color.White, modifier = Modifier.weight(1f), fontSize = 14.sp)
            Switch(checked = projMode, onCheckedChange = { projMode = it },
                colors = SwitchDefaults.colors(checkedTrackColor = Color(0xFFFF6B00)))
        }

        Spacer(Modifier.height(20.dp))

        Button(
            onClick = {
                if (!Permisos.listo(ctx as ComponentActivity)) return@Button
                status = "Conectando…"
                shizukuState = HorizonBridge.state().name
                Thread {
                    val ok = WmController.connect(ctx)
                    (ctx as ComponentActivity).runOnUiThread {
                        if (!ok) {
                            status = "Shizuku no listo"
                            Toast.makeText(ctx, "Shizuku no activo o sin permiso", Toast.LENGTH_LONG).show()
                            return@runOnUiThread
                        }
                        prefs.edit {
                            putInt("r", ratio)
                            putBoolean("axis", vertical)
                            putBoolean("proj", projMode)
                            putBoolean("applied", true)
                        }
                        WmController.projMode = projMode
                        WmController.apply(ratio, vertical)
                        FloatingControlService.start(ctx)
                        applied = true
                        status = "Aplicado · ${"%.2f".format(ratio / 100f)} · ${if (projMode) "Pro" else "wm"}"
                    }
                }.start()
            },
            modifier = Modifier.fillMaxWidth().height(54.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF6B00)),
            shape = RoundedCornerShape(14.dp)
        ) {
            Icon(Icons.Default.PlayArrow, null)
            Spacer(Modifier.width(8.dp))
            Text("APLICAR ESTIRAMIENTO", fontWeight = FontWeight.Bold, color = Color.Black)
        }

        Spacer(Modifier.height(10.dp))

        OutlinedButton(
            onClick = {
                FloatingControlService.stop(ctx)
                WmController.reset()
                WmController.disconnect()
                prefs.edit { putBoolean("applied", false) }
                applied = false
                status = "Restaurado"
            },
            modifier = Modifier.fillMaxWidth().height(46.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF6B00))
        ) {
            Icon(Icons.Default.Refresh, null)
            Spacer(Modifier.width(8.dp))
            Text("RESTAURAR TODO")
        }

        Spacer(Modifier.height(10.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
                onClick = {
                    Thread {
                        val t = if (WmController.connect(ctx)) WmController.probe() else "Sin conexión Shizuku"
                        (ctx as ComponentActivity).runOnUiThread {
                            diagText = t
                            showDiag = true
                        }
                    }.start()
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) { Text("Diagnóstico", fontSize = 12.sp) }
            OutlinedButton(
                onClick = {
                    Thread {
                        val t = if (WmController.connect(ctx)) WmController.proProbe() else "Sin conexión Shizuku"
                        (ctx as ComponentActivity).runOnUiThread {
                            diagText = t
                            showDiag = true
                        }
                    }.start()
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) { Text("Pro Probe", fontSize = 12.sp) }
        }

        Spacer(Modifier.height(16.dp))
        Text(status, color = Color(0xFF888888), fontSize = 13.sp)
        if (applied) Text("Control flotante activo · Vol+ = emergencia", color = Color(0xFF4CAF50), fontSize = 12.sp)

        if (showDiag) {
            Spacer(Modifier.height(16.dp))
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF121212)), shape = RoundedCornerShape(12.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Diagnóstico", fontWeight = FontWeight.Bold, color = Color(0xFFFF6B00))
                        TextButton(onClick = { showDiag = false }) { Text("Cerrar", color = Color(0xFF888888)) }
                    }
                    Text(diagText, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color(0xFFCCCCCC), modifier = Modifier.heightIn(max = 400.dp))
                }
            }
        }

        Spacer(Modifier.height(32.dp))
        Text("Código 100% open source · Compatible Shizuku + SurfaceFlinger", fontSize = 10.sp, color = Color(0xFF555555))
    }
}
