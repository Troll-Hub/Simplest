# Cat Resolution Pro — Open Source Full

Implementación open-source completa de las funciones de Cat Resolution Pro:

## Funciones incluidas
- **wm size / reset** (modo clásico)
- **Modo Pro**: proyección SurfaceFlinger vía `setDisplayProjection`
- **Token físico**: `SurfaceControl.getPhysicalDisplayToken` + fallback ISurfaceComposer transact 7
- **Control flotante** arrastrable (tap = +0.10, long-press = eje)
- **Emergencia**: Volumen + restaura todo (getevent)
- **Diagnóstico** y **Pro Probe** completos
- **Permisos** idénticos a CRP (overlay, FGS specialUse, Shizuku, etc.)
- UI Compose Material3 moderna
- Compatible Android 8+ / Motorola y genéricos

## Requisitos
- Shizuku instalado y activo
- Permiso de superposición
- Android Studio / Gradle 8.7+ / SDK 35

## Build
```bash
./gradlew assembleDebug
```

Todo el código es libre y abierto. Sin autenticación propietaria, sin binarios cerrados.
