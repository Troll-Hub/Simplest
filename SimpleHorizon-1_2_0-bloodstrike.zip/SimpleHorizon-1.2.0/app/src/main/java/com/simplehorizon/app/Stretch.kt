package com.simplehorizon.app

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** Juego al que está dedicada la app. */
object Game {
    const val NAME = "Blood Strike"
    const val PKG = "com.netease.newspike"
    const val ACTIVITY = "com.netease.game.MessiahNativeActivity"
}

object Stretch {
    const val MIN = 100   // 1.00 = sin estirar
    const val MAX = 199   // 1.99 = tope
    fun clamp(r: Int) = r.coerceIn(MIN, MAX)

    /** Tamaño de la pantalla virtual: en horizontal reduce el eje elegido (alto o ancho) entre la relación. */
    fun size(w: Int, h: Int, ratio: Int, vertical: Boolean): Pair<Int, Int> {
        val p = clamp(ratio)
        fun cut(v: Int) = ((v * 100 / p) / 2 * 2).coerceAtLeast(64)
        return if (vertical) w to cut(h) else cut(w) to h
    }
}

object HorizonBridge {
    private const val REQ = 4243
    private const val VERSION = 2
    enum class State { NOT_RUNNING, NO_PERMISSION, READY, UNSUPPORTED }

    fun state(): State = try {
        when {
            !Shizuku.pingBinder() -> State.NOT_RUNNING
            Shizuku.isPreV11() -> State.UNSUPPORTED
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> State.READY
            else -> State.NO_PERMISSION
        }
    } catch (_: Throwable) {
        State.NOT_RUNNING
    }

    fun requestPermission() {
        try { Shizuku.requestPermission(REQ) } catch (_: Throwable) {}
    }

    /** No daemon: el servicio (y la pantalla virtual) mueren con la app. */
    fun serviceArgs(ctx: Context): Shizuku.UserServiceArgs =
        Shizuku.UserServiceArgs(ComponentName(ctx.packageName, HorizonService::class.java.name))
            .daemon(false).processNameSuffix("horizon").version(VERSION)
}
