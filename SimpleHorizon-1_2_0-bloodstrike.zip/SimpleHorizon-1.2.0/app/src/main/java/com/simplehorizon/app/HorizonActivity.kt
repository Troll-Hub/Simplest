package com.simplehorizon.app

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Binder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import rikka.shizuku.Shizuku
import java.util.Locale
import kotlin.math.abs

/**
 * El juego corre en una pantalla virtual (Shizuku) y esta ventana la muestra a pantalla completa;
 * Android la escala al panel, y ese escalado es el estiramiento. Incluye un menú flotante propio.
 */
class HorizonActivity : Activity(), SurfaceHolder.Callback {
    companion object {
        private const val EXTRA_PKG = "pkg"
        fun start(ctx: Context, pkg: String) {
            val i = Intent(ctx, HorizonActivity::class.java).putExtra(EXTRA_PKG, pkg)
            if (ctx !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val token = Binder()
    private val statusTag = Any()
    private val applyRun = Runnable { applySize() }
    private lateinit var prefs: SharedPreferences
    private lateinit var surfaceView: SurfaceView
    private lateinit var status: TextView
    private lateinit var bubble: TextView
    private lateinit var panelHost: View
    private lateinit var info: TextView
    private lateinit var ratioLbl: TextView
    private lateinit var ratioBar: SeekBar
    private lateinit var axisBtn: Button
    private lateinit var volCheck: CheckBox

    private var pkg = ""
    private var ratio = 150
    private var vertical = true
    private var volKeys = true
    private var maxHz = 60f
    private var dpi = 0
    @Volatile private var vdHz = 0f
    @Volatile private var vw = 0
    @Volatile private var vh = 0
    @Volatile private var svc: IHorizonService? = null
    @Volatile private var displayId = -1
    @Volatile private var pendingSurface: Surface? = null
    private var starting = false
    private var cleaned = false
    private var args: Shizuku.UserServiceArgs? = null
    private var conn: ServiceConnection? = null
    private var lastBack = 0L
    private var lastVolUp = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = intent.getStringExtra(EXTRA_PKG)
        if (p == null) {
            finish()
            return
        }
        pkg = p
        prefs = getSharedPreferences("horizon", MODE_PRIVATE)
        ratio = Stretch.clamp(prefs.getInt("r", 150))
        vertical = prefs.getBoolean("axis", true)
        volKeys = prefs.getBoolean("vol", true)

        @Suppress("DEPRECATION")
        val disp = windowManager.defaultDisplay
        maxHz = disp.supportedModes.maxOfOrNull { it.refreshRate } ?: disp.refreshRate
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        disp.getRealMetrics(dm)
        dpi = dm.densityDpi

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val lp = window.attributes
        lp.preferredRefreshRate = maxHz // que el panel se mantenga en su frecuencia máxima
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = lp
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideSystemBars()

        val (sw, sh) = targetSize()
        vw = sw
        vh = sh

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        val sv = SurfaceView(this)
        surfaceView = sv
        sv.holder.setFixedSize(vw, vh) // buffer del tamaño estirado; el compositor lo escala al panel
        sv.holder.addCallback(this)
        sv.setOnTouchListener { v, e -> forwardTouch(v, e); true }
        root.addView(sv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(0x99000000.toInt())
            textSize = 13f
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        root.addView(status, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(16) })
        buildMenu(root)
        setContentView(root)
        showStatus(getString(R.string.h_iniciando), false)
        bind()
    }

    // ---------- Tamaño ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** Vertical (menú del juego): sin estirar. Horizontal: relación elegida (1.00–1.99) sobre el eje elegido. */
    private fun targetSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(dm)
        val w = dm.widthPixels
        val h = dm.heightPixels
        return if (w > h) Stretch.size(w, h, ratio, vertical) else w to h
    }

    private fun applySize() {
        val (nw, nh) = targetSize()
        if (nw != vw || nh != vh) {
            vw = nw
            vh = nh
            surfaceView.holder.setFixedSize(nw, nh)
            val service = svc
            if (service != null && displayId >= 0) {
                Thread({
                    try { service.resize(nw, nh, dpi) } catch (_: Throwable) {}
                    readHz()
                }, "simplehorizon-resize").start()
            }
        }
        updateInfo()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::surfaceView.isInitialized) applySize()
    }

    private fun readHz() {
        try { vdHz = svc?.refreshRate() ?: 0f } catch (_: Throwable) {}
        main.post { updateInfo() }
    }

    private fun setRatio(r: Int) {
        ratio = Stretch.clamp(r)
        prefs.edit().putInt("r", ratio).apply()
        ratioBar.progress = ratio - Stretch.MIN
        ratioLbl.text = ratioText()
        main.removeCallbacks(applyRun)
        main.postDelayed(applyRun, 250) // se aplica al dejar de mover
    }

    private fun ratioText() = "Estiramiento: " + String.format(Locale.US, "%.2f", ratio / 100.0) + "×"
    private fun axisText() = if (vertical) "Eje: vertical ↕ (toca para cambiar)" else "Eje: horizontal ↔ (toca para cambiar)"
    private fun updateInfo() {
        info.text = String.format(Locale.US, "%d×%d · pantalla virtual %.0f Hz · panel %.0f Hz", vw, vh, vdHz, maxHz)
    }

    // ---------- Menú flotante ----------
    private fun box(c: Int, r: Int, oval: Boolean = false) = GradientDrawable().apply {
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = r.toFloat()
        setColor(c)
    }

    private fun label(t: String) = TextView(this).apply { text = t; setTextColor(Color.WHITE); textSize = 13f }

    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        textSize = 12f
        isAllCaps = false
        minWidth = 0
        minimumWidth = 0
        setPadding(dp(8), 0, dp(8), 0)
        setOnClickListener { onClick() }
    }

    private fun buildMenu(root: FrameLayout) {
        bubble = TextView(this).apply {
            text = "⚙"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = box(0x99000000.toInt(), 0, true)
        }
        root.addView(bubble, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.END).apply { topMargin = dp(12); marginEnd = dp(12) })
        attachDrag()

        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10)) }
        ratioLbl = label(ratioText())
        panel.addView(ratioLbl)
        ratioBar = SeekBar(this).apply {
            max = Stretch.MAX - Stretch.MIN
            progress = ratio - Stretch.MIN
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) setRatio(Stretch.MIN + p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        panel.addView(ratioBar)
        fun row(vararg items: Pair<String, () -> Unit>) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            for ((t, f) in items) addView(btn(t, f))
        }
        panel.addView(row("−0.01" to { setRatio(ratio - 1) }, "+0.01" to { setRatio(ratio + 1) }, "1.00" to { setRatio(100) }, "1.25" to { setRatio(125) }))
        panel.addView(row("1.33" to { setRatio(133) }, "1.50" to { setRatio(150) }, "1.77" to { setRatio(177) }, "1.99" to { setRatio(199) }))
        axisBtn = btn(axisText()) {
            vertical = !vertical
            prefs.edit().putBoolean("axis", vertical).apply()
            axisBtn.text = axisText()
            applySize()
        }
        panel.addView(axisBtn)
        panel.addView(label("Opacidad del menú"))
        panel.addView(SeekBar(this).apply {
            max = 70
            progress = prefs.getInt("alpha", 100) - 30
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val a = (30 + p) / 100f
                    bubble.alpha = a
                    panelHost.alpha = a
                    if (fromUser) prefs.edit().putInt("alpha", 30 + p).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        volCheck = CheckBox(this).apply {
            text = "Volumen − oculta / + muestra el menú"
            setTextColor(Color.WHITE)
            textSize = 12f
            isChecked = volKeys
            setOnCheckedChangeListener { _, on -> volKeys = on; prefs.edit().putBoolean("vol", on).apply() }
        }
        panel.addView(volCheck)
        info = label("")
        info.textSize = 11f
        panel.addView(info)
        panel.addView(row("Ocultar menú" to { hideMenu() }, "Salir" to { finish() }))

        panelHost = ScrollView(this).apply {
            addView(panel)
            background = box(0xE6101418.toInt(), dp(14))
            visibility = View.GONE
        }
        root.addView(panelHost, FrameLayout.LayoutParams(dp(300), dp(250), Gravity.TOP or Gravity.END).apply { topMargin = dp(64); marginEnd = dp(12) })
        val a = prefs.getInt("alpha", 100) / 100f
        bubble.alpha = a
        panelHost.alpha = a
        updateInfo()
    }

    private fun attachDrag() {
        var dx = 0f
        var dy = 0f
        var moved = false
        bubble.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = v.translationX - e.rawX; dy = v.translationY - e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val nx = e.rawX + dx
                    val ny = e.rawY + dy
                    if (abs(nx - v.translationX) + abs(ny - v.translationY) > dp(4)) moved = true
                    v.translationX = nx
                    v.translationY = ny
                }
                MotionEvent.ACTION_UP -> if (!moved) panelHost.visibility = if (panelHost.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
            true
        }
    }

    /** Ocultar siempre deja activos los botones de volumen, para poder recuperar el menú. */
    private fun hideMenu() {
        if (!volKeys) volCheck.isChecked = true
        bubble.visibility = View.GONE
        panelHost.visibility = View.GONE
    }

    private fun restoreMenu() {
        bubble.translationX = 0f
        bubble.translationY = 0f
        bubble.visibility = View.VISIBLE
        panelHost.visibility = View.VISIBLE
    }

    // Volumen − oculta el menú; Volumen + lo muestra (dos veces seguidas: restaura el estiramiento a 1.00)
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (volKeys && (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP)) {
            if ((event?.repeatCount ?: 0) == 0) {
                if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                    hideMenu()
                } else {
                    val now = SystemClock.uptimeMillis()
                    if (now - lastVolUp < 800) setRatio(100)
                    lastVolUp = now
                    restoreMenu()
                }
            }
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (volKeys && (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP)) return true
        return super.onKeyUp(keyCode, event)
    }

    // ---------- Ventana ----------
    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun showStatus(text: String, persistent: Boolean) {
        status.text = text
        status.visibility = View.VISIBLE
        main.removeCallbacksAndMessages(statusTag)
        if (!persistent) main.postAtTime({ status.visibility = View.GONE }, statusTag, SystemClock.uptimeMillis() + 4000)
    }

    private fun fail(msg: String?) {
        main.post {
            showStatus(getString(R.string.h_error, msg ?: "?"), true)
            main.postDelayed({ if (!isFinishing) finish() }, 6000)
        }
    }

    // ---------- Servicio de Shizuku ----------
    private fun bind() {
        if (HorizonBridge.state() != HorizonBridge.State.READY) {
            fail(getString(R.string.h_shizuku_off))
            return
        }
        val a = HorizonBridge.serviceArgs(this)
        val c = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                val service = if (binder != null && binder.pingBinder()) IHorizonService.Stub.asInterface(binder) else null
                if (service == null) {
                    fail(getString(R.string.h_sin_servicio))
                } else {
                    svc = service
                    tryStart()
                }
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                svc = null
            }
        }
        args = a
        conn = c
        try {
            Shizuku.bindUserService(a, c)
        } catch (e: Throwable) {
            fail(getString(R.string.h_conexion, e.message))
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        pendingSurface = holder.surface
        // Pide a la composición la frecuencia máxima del panel para esta superficie
        if (Build.VERSION.SDK_INT >= 30) {
            try { holder.surface.setFrameRate(maxHz, Surface.FRAME_RATE_COMPATIBILITY_DEFAULT) } catch (_: Throwable) {}
        }
        tryStart()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        pendingSurface = null
        try { svc?.setSurface(null) } catch (_: Throwable) {}
    }

    private fun tryStart() {
        val service = svc ?: return
        val surf = pendingSurface ?: return
        if (!surf.isValid) return
        if (displayId >= 0) {
            try { service.setSurface(surf) } catch (_: Throwable) {}
            return
        }
        if (starting) return
        starting = true
        Thread({
            try {
                service.forceStop(pkg)
                val id = service.startDisplay(surf, vw, vh, dpi, maxHz, token)
                if (id < 0) {
                    fail(service.lastError())
                } else {
                    displayId = id
                    if (service.launchOnDisplay(pkg, Game.ACTIVITY, id)) {
                        main.post { showStatus(getString(R.string.h_salir), false) }
                        readHz()
                    } else {
                        fail(service.lastError())
                    }
                }
            } catch (e: Throwable) {
                fail(e.message)
            }
        }, "simplehorizon-start").start()
    }

    // ---------- Entrada ----------
    private fun forwardTouch(v: View, e: MotionEvent) {
        val service = svc ?: return
        val id = displayId
        if (id < 0 || v.width <= 0 || v.height <= 0) return
        val sx = vw.toFloat() / v.width
        val sy = vh.toFloat() / v.height
        val n = e.pointerCount
        val props = Array(n) { i -> MotionEvent.PointerProperties().also { e.getPointerProperties(i, it) } }
        val coords = Array(n) { i ->
            MotionEvent.PointerCoords().also {
                e.getPointerCoords(i, it)
                it.x *= sx
                it.y *= sy
            }
        }
        val ev = MotionEvent.obtain(
            e.downTime, e.eventTime, e.action, n, props, coords,
            e.metaState, e.buttonState, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0
        )
        try {
            service.injectTouch(ev, id)
        } catch (_: Throwable) {
        } finally {
            ev.recycle()
        }
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        val now = SystemClock.uptimeMillis()
        if (now - lastBack < 700) {
            finish()
            return
        }
        lastBack = now
        val service = svc
        val id = displayId
        if (service != null && id >= 0) {
            Thread({ try { service.injectKey(KeyEvent.KEYCODE_BACK, id) } catch (_: Throwable) {} }, "simplehorizon-back").start()
        } else {
            finish()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        main.removeCallbacksAndMessages(null)
        if (cleaned) return
        cleaned = true
        val service = svc
        val a = args
        val c = conn
        val p = pkg
        Thread({
            try { service?.stopDisplay() } catch (_: Throwable) {}
            try { if (p.isNotEmpty()) service?.forceStop(p) } catch (_: Throwable) {}
            try { if (a != null && c != null) Shizuku.unbindUserService(a, c, true) } catch (_: Throwable) {}
        }, "simplehorizon-cleanup").start()
    }
}
