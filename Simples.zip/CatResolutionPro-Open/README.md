# Cat Resolution Pro — Open Source Clone

Clone open-source completo das funções e interface principal do Cat Resolution Pro (sem login, sem servidor, sem código proprietário).

## O que inclui
- Interface Compose estilo CRP (tema laranja/preto, fator grande, presets 1.00–1.80, eixo V/H, Modo Pro)
- **Modo Pro**: SurfaceFlinger `setDisplayProjection`
- **wm size** clássico
- Token físico (`getPhysicalDisplayToken` + fallback transact 7)
- Controle flutuante completo (APLICAR, +/- 0.10, eixo, fechar)
- Emergência VOLUME + (restaura tudo)
- Diagnóstico + Pro Probe
- Tabs: Esticar / Diagnóstico / Info
- Permissões e componentes alinhados ao CRP
- GitHub Actions workflow (`build.yml`) → gera APK debug automaticamente

## Requisitos
- Shizuku instalado e ativo
- Permissão de sobreposição
- Android 8+ (minSdk 26)

## Build local
```bash
./gradlew assembleDebug
```

## GitHub Actions
Push para `main` ou workflow_dispatch gera o APK como artifact.

100% código aberto. Sem autenticação, sem binários fechados.
