package com.catresolution.pro

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast

object Permisos {
    fun listo(act: Activity): Boolean {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(act)) {
            Toast.makeText(act, "Activa superposición de pantalla", Toast.LENGTH_LONG).show()
            act.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${act.packageName}")))
            return false
        }
        when (HorizonBridge.state()) {
            HorizonBridge.State.NOT_RUNNING -> {
                Toast.makeText(act, "Abre Shizuku e inícialo", Toast.LENGTH_LONG).show()
                return false
            }
            HorizonBridge.State.NO_PERMISSION -> {
                HorizonBridge.requestPermission()
                Toast.makeText(act, "Concede permiso a Shizuku", Toast.LENGTH_LONG).show()
                return false
            }
            HorizonBridge.State.UNSUPPORTED -> {
                Toast.makeText(act, "Shizuku no compatible", Toast.LENGTH_LONG).show()
                return false
            }
            HorizonBridge.State.READY -> return true
        }
    }
}
