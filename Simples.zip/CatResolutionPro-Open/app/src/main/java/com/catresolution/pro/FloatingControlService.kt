package com.catresolution.pro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat

class FloatingControlService : Service() {
    companion object {
        @Volatile var running = false
        fun start(ctx: Context) {
            ctx.startForegroundService(Intent(ctx, FloatingControlService::class.java))
        }
        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, FloatingControlService::class.java))
        }
    }

    private var wm: WindowManager? = null
    private var bubble: View? = null
    private var ratio = 129
    private var vertical = true

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        val prefs = getSharedPreferences("crp", Context.MODE_PRIVATE)
        ratio = prefs.getInt("r", 129)
        vertical = prefs.getBoolean("axis", true)
        createChannel()
        startForeground(42, buildNotif())
        showBubble()
    }

    override fun onDestroy() {
        running = false
        removeBubble()
        WmController.reset()
        WmController.disconnect()
        super.onDestroy()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("float", "Controle flutuante Tela Esticada", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotif(): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "float")
            .setContentTitle("Cat Resolution Pro")
            .setContentText("Controle flutuante ativo · VOLUME + restaura")
            .setSmallIcon(android.R.drawable.ic_menu_crop)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun showBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 16
            y = 180
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 4, 4, 4)
            setBackgroundColor(0xE0111111.toInt())
        }

        fun makeBtn(text: String, bg: Int, action: () -> Unit): TextView {
            return TextView(this).apply {
                this.text = text
                setTextColor(0xFFFFFFFF.toInt())
                setBackgroundColor(bg)
                setPadding(36, 22, 36, 22)
                textSize = 13f
                gravity = android.view.Gravity.CENTER
                setOnClickListener { action() }
            }
        }

        val label = TextView(this).apply {
            text = "CR ${"%.2f".format(ratio / 100f)}"
            setTextColor(0xFFFF6B00.toInt())
            setPadding(28, 16, 28, 8)
            textSize = 15f
            gravity = android.view.Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }

        val applyBtn = makeBtn("APLICAR", 0xFFCC5500.toInt()) {
            WmController.apply(ratio, vertical)
            label.text = "CR ${"%.2f".format(ratio / 100f)}"
        }
        val plusBtn = makeBtn("+0.10", 0xFF333333.toInt()) {
            ratio = (ratio + 10).coerceAtMost(199)
            label.text = "CR ${"%.2f".format(ratio / 100f)}"
            getSharedPreferences("crp", Context.MODE_PRIVATE).edit().putInt("r", ratio).apply()
        }
        val minusBtn = makeBtn("-0.10", 0xFF333333.toInt()) {
            ratio = (ratio - 10).coerceAtLeast(100)
            label.text = "CR ${"%.2f".format(ratio / 100f)}"
            getSharedPreferences("crp", Context.MODE_PRIVATE).edit().putInt("r", ratio).apply()
        }
        val axisBtn = makeBtn(if (vertical) "EIXO V" else "EIXO H", 0xFF222222.toInt()) {
            vertical = !vertical
            axisBtn.text = if (vertical) "EIXO V" else "EIXO H"
            getSharedPreferences("crp", Context.MODE_PRIVATE).edit().putBoolean("axis", vertical).apply()
        }
        val closeBtn = makeBtn("FECHAR", 0xFF442222.toInt()) {
            stopSelf()
        }

        root.addView(label)
        root.addView(applyBtn)
        root.addView(plusBtn)
        root.addView(minusBtn)
        root.addView(axisBtn)
        root.addView(closeBtn)

        // drag
        var ix = 0f; var iy = 0f; var px = 0; var py = 0
        root.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { ix = e.rawX; iy = e.rawY; px = params.x; py = params.y; false }
                MotionEvent.ACTION_MOVE -> {
                    params.x = px + (ix - e.rawX).toInt()
                    params.y = py + (e.rawY - iy).toInt()
                    wm?.updateViewLayout(v, params)
                    true
                }
                else -> false
            }
        }

        bubble = root
        wm?.addView(root, params)
    }

    private fun removeBubble() {
        bubble?.let { try { wm?.removeView(it) } catch (_: Throwable) {} }
        bubble = null
    }
}
