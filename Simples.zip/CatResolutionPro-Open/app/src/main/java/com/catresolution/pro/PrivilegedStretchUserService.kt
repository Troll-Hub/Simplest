package com.catresolution.pro

import android.content.Context
import android.graphics.Rect
import android.os.IBinder
import android.os.Parcel
import android.os.SystemClock
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Servicio privilegiado (uid shell vía Shizuku).
 * Implementación open-source completa de las funciones centrales de Cat Resolution Pro:
 * - wm size / reset
 * - proyección SurfaceFlinger (setDisplayProjection) modo Pro
 * - token físico (getPhysicalDisplayToken + fallback transact 7)
 * - emergencia por volumen +
 * - probes de diagnóstico completos
 * Compatible Android 8+ / Motorola y genéricos.
 */
class PrivilegedStretchUserService() : IPrivilegedStretchService.Stub() {
    private var baseCtx: Context? = null
    constructor(context: Context) : this() { baseCtx = context }

    private fun sh(script: String, timeoutMs: Long = 8000L): Pair<Int, String> = try {
        val p = ProcessBuilder("sh", "-c", script).redirectErrorStream(true).start()
        val out = StringBuilder()
        val t = Thread {
            try { out.append(p.inputStream.bufferedReader().readText()) } catch (_: Throwable) {}
        }
        t.start()
        val finished = p.waitFor(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS)
        if (!finished) {
            p.destroyForcibly()
            -1 to "timeout"
        } else {
            t.join(500)
            p.exitValue() to out.toString().trim()
        }
    } catch (e: Exception) {
        -1 to (e.message ?: "error")
    }

    @Volatile private var projToken: IBinder? = null
    @Volatile private var lastErr = ""
    private val emergencyRunning = AtomicBoolean(false)
    private var lastEmergencyTs = 0L

    override fun lastError(): String = lastErr

    override fun wm(arg: String): String {
        if (arg.isEmpty()) return sh("wm size 2>&1; echo '---'; wm density 2>&1").second
        if (!Regex("^(reset|\\d{3,5}x\\d{3,5})$").matches(arg)) {
            lastErr = "argumento wm no válido"
            return lastErr
        }
        val cmd = if (arg == "reset") "wm size reset" else "wm size $arg"
        val r = sh("$cmd 2>&1").second
        lastErr = if (r.contains("Error", true) || r.contains("Exception", true)) r.take(200) else ""
        return r
    }

    private fun physicalSize(): Pair<Int, Int>? {
        val out = sh("wm size 2>&1").second
        val m = Regex("Physical size: (\\d+)x(\\d+)").find(out)
            ?: Regex("Override size: (\\d+)x(\\d+)").find(out)
            ?: return null
        return m.groupValues[1].toInt() to m.groupValues[2].toInt()
    }

    private fun acquireToken(): String {
        if (projToken != null && projToken!!.isBinderAlive) return "ok"

        // 1) SurfaceControl.getPhysicalDisplayToken
        try {
            val sc = Class.forName("android.view.SurfaceControl")
            var id = 0L
            try {
                val getIds = sc.getDeclaredMethod("getPhysicalDisplayIds")
                getIds.isAccessible = true
                val ids = getIds.invoke(null) as? LongArray
                if (ids != null && ids.isNotEmpty()) id = ids[0]
            } catch (_: Throwable) {}
            val m = sc.getDeclaredMethod("getPhysicalDisplayToken", Long::class.javaPrimitiveType)
            m.isAccessible = true
            val t = m.invoke(null, id) as? IBinder
            if (t != null && t.isBinderAlive) {
                projToken = t
                return "ok"
            }
        } catch (_: Throwable) {}

        // 2) Fallback CRP: ISurfaceComposer transact 7
        val dump = sh("dumpsys SurfaceFlinger --display-id 2>&1").second
        val did = Regex("Display (\\d+) \\(HWC").find(dump)?.groupValues?.get(1)
            ?: Regex("Display (\\d+)").find(dump)?.groupValues?.get(1)
            ?: return "ID de pantalla no encontrado"
        val sf = try {
            Class.forName("android.os.ServiceManager")
                .getMethod("getService", String::class.java)
                .invoke(null, "SurfaceFlinger") as? IBinder
        } catch (_: Throwable) { null } ?: return "SurfaceFlinger no encontrado"

        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        try {
            data.writeInterfaceToken("android.gui.ISurfaceComposer")
            data.writeLong(did.toLong())
            val ok = sf.transact(7, data, reply, 0)
            if (!ok) return "transact 7 falló"
            reply.readException()
            val t = reply.readStrongBinder() ?: return "token NULL"
            projToken = t
            return "ok"
        } catch (e: Throwable) {
            return "error token: ${e.javaClass.simpleName}"
        } finally {
            data.recycle()
            reply.recycle()
        }
    }

    private fun applyProjection(layer: Rect, panelW: Int, panelH: Int): String {
        val token = projToken ?: return "sin token"
        return try {
            val txCls = Class.forName("android.view.SurfaceControl\$Transaction")
            val tx = txCls.getConstructor().newInstance()
            val setProj = txCls.getMethod(
                "setDisplayProjection",
                IBinder::class.java,
                Int::class.javaPrimitiveType,
                Rect::class.java,
                Rect::class.java
            )
            setProj.invoke(tx, token, 0, layer, Rect(0, 0, panelW, panelH))
            txCls.getMethod("apply").invoke(tx)
            "ok"
        } catch (e: Throwable) {
            lastErr = "${e.javaClass.simpleName}: ${e.message}"
            "error: $lastErr"
        }
    }

    override fun projectStretch(ratio: Int, vertical: Boolean): String {
        return try {
            val (pw, ph) = physicalSize() ?: return "tamaño físico no leído"
            val tok = acquireToken()
            if (tok != "ok") return tok
            val p = ratio.coerceIn(100, 199)
            fun cut(v: Int) = ((v * 100L / p).toInt() / 2 * 2).coerceAtLeast(64)
            val layer = when {
                p <= 100 -> Rect(0, 0, pw, ph)
                vertical -> Rect(0, 0, cut(pw), ph)
                else -> Rect(0, 0, pw, cut(ph))
            }
            val r = applyProjection(layer, pw, ph)
            if (r != "ok") lastErr = r
            r
        } catch (e: Throwable) {
            lastErr = "${e.javaClass.simpleName}: ${e.message}"
            "error: $lastErr"
        }
    }

    override fun projectRestore(): String {
        return try {
            val (pw, ph) = physicalSize() ?: return "tamaño físico no leído"
            val tok = acquireToken()
            if (tok != "ok") return tok
            applyProjection(Rect(0, 0, pw, ph), pw, ph)
        } catch (e: Throwable) {
            "error: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    override fun probe(): String {
        val sb = StringBuilder()
        fun add(title: String, body: String) {
            sb.append("## ").append(title).append('\n').append(body.trim().take(1200)).append("\n\n")
        }
        add("id", sh("id").second)
        add("build", sh("getprop ro.build.version.release; getprop ro.build.version.sdk; getprop ro.product.manufacturer; getprop ro.product.model; getprop ro.build.version.security_patch").second)
        add("wm", sh("wm size 2>&1; wm density 2>&1").second)
        add("SurfaceFlinger", sh("dumpsys SurfaceFlinger --display-id 2>&1 | head -25").second)
        add("uinput", sh("ls -l /dev/uinput /dev/input/uinput 2>&1; ls /dev/input 2>&1 | head -15").second)
        return sb.toString()
    }

    override fun proProbe(): String {
        val sb = StringBuilder()
        fun add(title: String, cmd: String) {
            sb.append("## ").append(title).append('\n').append(sh(cmd).second.trim().take(5000)).append("\n\n")
        }
        add("id", "id")
        add("displays", "cmd display get-displays 2>&1 | head -40")
        add("SurfaceFlinger --display-id", "dumpsys SurfaceFlinger --display-id 2>&1 | head -40")
        add("service list SF", "service list 2>&1 | grep -i surface")
        add("uinput", "ls -l /dev/uinput 2>&1; test -w /dev/uinput && echo escribible || echo no_escribible")
        add("input devices", "getevent -pl 2>&1 | grep -E 'add device|name:|ABS_MT_POSITION' | head -60")
        val tokStatus = try {
            val r = acquireToken()
            if (r == "ok") "token OK vivo=${projToken?.isBinderAlive}" else r
        } catch (e: Throwable) {
            "error: ${e.message}"
        }
        sb.append("## token físico\n").append(tokStatus).append("\n\n")
        return sb.toString()
    }

    private fun emergencyRestore() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastEmergencyTs < 1200) return
        lastEmergencyTs = now
        sh("wm size reset")
        try { projectRestore() } catch (_: Throwable) {}
    }

    override fun startEmergency(): String {
        if (!emergencyRunning.compareAndSet(false, true)) return "ok"
        return try {
            val p = ProcessBuilder("sh", "-c", "getevent -l 2>&1").redirectErrorStream(true).start()
            Thread({
                try {
                    p.inputStream.bufferedReader().forEachLine { line ->
                        if (line.contains("KEY_VOLUMEUP") && (line.contains("DOWN") || line.contains("001"))) {
                            emergencyRestore()
                        }
                    }
                } catch (_: Throwable) {
                } finally {
                    emergencyRunning.set(false)
                }
            }, "crp-emergency").start()
            "ok"
        } catch (e: Throwable) {
            emergencyRunning.set(false)
            "error: ${e.message}"
        }
    }

    override fun destroy() {
        try { projectRestore() } catch (_: Throwable) {}
        try { sh("wm size reset") } catch (_: Throwable) {}
        System.exit(0)
    }
}
