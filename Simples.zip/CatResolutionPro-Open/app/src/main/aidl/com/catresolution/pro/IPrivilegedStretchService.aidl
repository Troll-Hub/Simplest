package com.catresolution.pro;

interface IPrivilegedStretchService {
    String lastError();
    String wm(String arg);
    String projectStretch(int ratio, boolean vertical);
    String projectRestore();
    String probe();
    String proProbe();
    String startEmergency();
    void destroy();
}
