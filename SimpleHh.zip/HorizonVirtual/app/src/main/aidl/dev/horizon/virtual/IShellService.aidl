package dev.horizon.virtual;

interface IShellService {
    void destroy() = 16777114;
    String runCommand(String command);
}
