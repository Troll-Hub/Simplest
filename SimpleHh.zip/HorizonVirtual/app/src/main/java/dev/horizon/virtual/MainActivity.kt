package dev.horizon.virtual

import android.app.Activity
import android.content.ComponentName
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private val requestCode = 7312
    private lateinit var status: TextView
    private lateinit var widthInput: EditText
    private lateinit var heightInput: EditText
    private lateinit var dpiInput: EditText
    private lateinit var refreshSpinner: Spinner
    private lateinit var output: TextView

    private var shellService: IShellService? = null
    private var shellServiceBound = false
    private val shellServiceArgs by lazy {
        Shizuku.UserServiceArgs(
            ComponentName(BuildConfig.APPLICATION_ID, ShellUserService::class.java.name)
        )
            .daemon(false)
            .processNameSuffix("shell")
            .debuggable(BuildConfig.DEBUG)
            .version(BuildConfig.VERSION_CODE)
    }
    private val shellServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, service: IBinder) {
            shellService = IShellService.Stub.asInterface(service)
            status.text = "Shizuku conectado y servicio listo."
        }

        override fun onServiceDisconnected(name: ComponentName) {
            shellService = null
            shellServiceBound = false
            if (::status.isInitialized) {
                status.text = "Servicio Shizuku desconectado; vuelve a conectarlo."
            }
        }
    }
    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { code, grantResult ->
            if (code == requestCode) {
                if (grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    status.text = "Permiso concedido; conectando con Shizuku…"
                    bindShellService()
                } else {
                    status.text = "Permiso denegado; autorízalo e inténtalo de nuevo."
                }
            }
        }

    private val bg = Color.rgb(12, 14, 20)
    private val panel = Color.rgb(25, 29, 40)
    private val accent = Color.rgb(255, 55, 85)
    private val fg = Color.rgb(240, 242, 248)
    private val muted = Color.rgb(165, 172, 188)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        Shizuku.addRequestPermissionResultListener(permissionResultListener)
        updateStatus()
        try {
            if (Shizuku.pingBinder() &&
                Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                bindShellService()
            }
        } catch (_: Exception) {
            // updateStatus() already shows that Shizuku is unavailable.
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        if (shellServiceBound) {
            try {
                Shizuku.unbindUserService(shellServiceArgs, shellServiceConnection, true)
            } catch (_: Exception) {
                // Shizuku may already have stopped; there is nothing else to unbind.
            }
            shellServiceBound = false
            shellService = null
        }
        super.onDestroy()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(26), dp(20), dp(28))
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(label("HORIZON VIRTUAL", 25f, fg))
        page.addView(label("Blood Strike · pantalla virtual de prueba", 14f, muted))
        page.addView(space(16))
        page.addView(TextView(this).apply {
            text = "Necesita Shizuku iniciado mediante depuración inalámbrica o ADB. Android o el juego pueden impedir el uso del display secundario. No garantiza 144 FPS."
            textSize = 13f
            setTextColor(muted)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(panel)
        })
        page.addView(space(14))
        status = label("Comprobando Shizuku…", 14f, accent)
        page.addView(status)
        page.addView(space(8))
        page.addView(button("Autorizar Shizuku", accent) { requestShizuku() })
        page.addView(space(18))
        page.addView(label("RESOLUCIÓN DEL DISPLAY", 12f, muted))
        page.addView(space(6))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        widthInput = edit("Ancho", "720")
        heightInput = edit("Alto", "1600")
        dpiInput = edit("DPI", "320")
        row.addView(widthInput, weighted())
        row.addView(heightInput, weighted())
        row.addView(dpiInput, weighted())
        page.addView(row)
        page.addView(space(12))
        page.addView(label("FRECUENCIA MÁXIMA SOLICITADA", 12f, muted))
        refreshSpinner = Spinner(this)
        refreshSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Máxima (144 Hz)", "120 Hz", "90 Hz", "60 Hz"))
        page.addView(refreshSpinner)
        page.addView(space(14))
        page.addView(button("1 · Crear pantalla virtual de prueba", accent) { createDisplay() })
        page.addView(space(7))
        page.addView(button("2 · Abrir Blood Strike en el display", Color.rgb(55, 65, 86)) { launchGame() })
        page.addView(space(7))
        page.addView(button("Aplicar frecuencia máxima", Color.rgb(55, 65, 86)) { applyRefreshRate() })
        page.addView(space(7))
        page.addView(button("Restaurar pantalla virtual", Color.rgb(65, 45, 55)) { restoreDisplay() })
        page.addView(space(16))
        page.addView(label("SALIDA", 12f, muted))
        output = TextView(this).apply {
            text = "Los resultados de los comandos aparecerán aquí."
            textSize = 12f
            setTextColor(fg)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(panel)
        }
        page.addView(output)
    }

    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                status.text = "Inicia Shizuku antes de autorizar Horizon Virtual."
                return
            }
            if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                bindShellService()
            } else {
                Shizuku.requestPermission(requestCode)
            }
        } catch (e: Exception) {
            status.text = "Error de Shizuku: ${e.message}"
        }
    }

    private fun updateStatus() {
        status.text = try {
            when {
                !Shizuku.pingBinder() -> "Inicia Shizuku y vuelve aquí."
                Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED ->
                    "Shizuku activo; falta autorizar esta app."
                shellService != null -> "Shizuku conectado y servicio listo."
                else -> "Shizuku autorizado; conectando el servicio."
            }
        } catch (_: Exception) { "Instala e inicia Shizuku." }
    }

    private fun bindShellService() {
        try {
            if (!Shizuku.pingBinder()) {
                status.text = "Inicia Shizuku antes de conectar el servicio."
                return
            }
            if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                status.text = "Autoriza Horizon Virtual en Shizuku primero."
                return
            }
            if (shellServiceBound) return

            Shizuku.bindUserService(shellServiceArgs, shellServiceConnection)
            shellServiceBound = true
            status.text = "Conectando con el servicio Shizuku…"
        } catch (e: Exception) {
            shellService = null
            shellServiceBound = false
            status.text = "No se pudo conectar con Shizuku: ${e.message}"
        }
    }

    private fun runShell(command: String): String {
        if (!Shizuku.pingBinder()) throw IllegalStateException("Shizuku no está activo.")
        if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED)
            throw SecurityException("Falta permiso de Shizuku.")
        val service = shellService
            ?: throw IllegalStateException("El servicio Shizuku aún está conectando; inténtalo otra vez.")
        return service.runCommand(command)
    }

    private fun createDisplay() {
        val w = widthInput.text.toString().toIntOrNull()
        val h = heightInput.text.toString().toIntOrNull()
        val dpi = dpiInput.text.toString().toIntOrNull()
        if (w == null || h == null || dpi == null || w !in 320..2560 || h !in 480..3840 || dpi !in 120..640) {
            output.text = "Valores no válidos. Ancho 320–2560, alto 480–3840, DPI 120–640."
            return
        }
        try {
            output.text = runShell("settings put global overlay_display_devices '${w}x${h}/$dpi'; sleep 2; dumpsys display | grep -i -E 'Overlay|overlay|DisplayDeviceInfo|mDisplayId' | head -100")
        } catch (e: Exception) { output.text = "Error: ${e.message}" }
    }

    private fun launchGame() {
        val command = listOf(
            "PKG='com.netease.newspike'",
            "INFO=$(cmd package resolve-activity --brief \"\$PKG\" 2>/dev/null | tail -n 1)",
            "echo \"Actividad resuelta: \$INFO\"",
            "DISPLAY_ID=$(dumpsys display | awk '/Overlay #1/ {found=1} found && /mDisplayId=/ {if (match($0, /mDisplayId=[0-9]+/)) {print substr($0, RSTART+10, RLENGTH-10); exit}}')",
            "echo \"Display detectado: \$DISPLAY_ID\"",
            "if [ -z \"\$DISPLAY_ID\" ]; then echo 'No se detectó Overlay #1; revisa dumpsys display.'; exit 2; fi",
            "if [ -z \"\$INFO\" ] || [ \"\$INFO\" = 'No activity found' ]; then echo 'No se encontró la actividad de Blood Strike; comprueba el paquete.'; exit 3; fi",
            "am start --display \"\$DISPLAY_ID\" -n \"\$INFO\""
        ).joinToString("; ")
        try { output.text = runShell(command) }
        catch (e: Exception) { output.text = "No se pudo abrir el juego: ${e.message}" }
    }

    private fun applyRefreshRate() {
        val rate = when (refreshSpinner.selectedItemPosition) {
            1 -> 120
            2 -> 90
            3 -> 60
            else -> 144
        }
        try {
            output.text = runShell("settings put system peak_refresh_rate $rate.0; settings put system min_refresh_rate $rate.0; settings get system peak_refresh_rate; settings get system min_refresh_rate") +
                "\nLa frecuencia efectiva depende del panel, la ROM y el juego."
        } catch (e: Exception) { output.text = "Error de frecuencia: ${e.message}" }
    }

    private fun restoreDisplay() {
        try { output.text = runShell("settings put global overlay_display_devices ''") }
        catch (e: Exception) { output.text = "Error al restaurar: ${e.message}" }
    }

    private fun edit(h: String, v: String) = EditText(this).apply {
        hint = h
        setText(v)
        setTextColor(fg)
        setHintTextColor(muted)
        textSize = 15f
        inputType = android.text.InputType.TYPE_CLASS_NUMBER
        setPadding(dp(8), dp(6), dp(8), dp(6))
    }

    private fun label(s: String, size: Float, color: Int) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
    }

    private fun button(s: String, color: Int, action: () -> Unit) = Button(this).apply {
        text = s
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(color)
        setOnClickListener { action() }
    }

    private fun space(n: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(n))
    }

    private fun weighted() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
        marginEnd = dp(4)
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
}
