package dev.horizon.virtual

class ShellUserService : IShellService.Stub() {
    override fun runCommand(command: String): String {
        val process = ProcessBuilder("sh", "-c", command)
            .redirectErrorStream(true)
            .start()
        val output = process.inputStream.bufferedReader().use { it.readText() }
        val exitCode = process.waitFor()
        return "exit=$exitCode\n$output"
    }

    override fun destroy() {
        System.exit(0)
    }
}
