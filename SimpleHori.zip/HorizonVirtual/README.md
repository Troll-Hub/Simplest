# Horizon Virtual

Starter Android project for testing Android's developer overlay display with Shizuku.

- Configure a development overlay display with custom width, height and DPI.
- Attempt to launch Blood Strike (`com.netease.newspike`) on the detected overlay display.
- Request preferred peak/minimum refresh rate.
- Remove the overlay display.

## Important limitations
`overlay_display_devices` creates a developer overlay, not a guaranteed independent virtual Android device. Android, the vendor ROM or the game may block launching the game there. Refresh-rate settings are requests only and cannot unlock unsupported modes or guarantee 144 FPS. The project is a starter implementation and has not been tested on the target phone. The original refresh-rate values are not saved, so restore them manually if needed.

## Build
Push the project to GitHub and run the `build-horizon-virtual` workflow.
