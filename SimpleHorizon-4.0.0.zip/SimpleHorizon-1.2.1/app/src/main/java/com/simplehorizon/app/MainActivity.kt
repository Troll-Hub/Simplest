package com.simplehorizon.app

import android.app.Activity
import android.app.AlertDialog
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/** Pantalla principal: estado, multiplicador de estiramiento (solo horizontal), juego y diagnóstico. */
class MainActivity : Activity(), StretchBus.Listener {
    private lateinit var prefs: SharedPreferences
    private val main = Handler(Looper.getMainLooper())
    private lateinit var readout: TextView
    private lateinit var sub: TextView
    private lateinit var seek: SeekBar
    private lateinit var edit: EditText
    private lateinit var shizukuTxt: TextView
    private lateinit var permTxt: TextView
    private lateinit var gameTxt: TextView
    private lateinit var applyBtn: TextView
    private var seeking = false
    private var fetching = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Cfg.prefs(this)
        Stretcher.restore(this)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        StretchBus.add(this)
        refresh()
        fetchNative()
    }

    override fun onPause() {
        StretchBus.remove(this)
        super.onPause()
    }

    override fun onStretchChanged() = refresh()

    private fun nl() = Cfg.nl(prefs)

    /** Lee el tamaño físico del panel una sola vez (hace falta Shizuku). */
    private fun fetchNative() {
        if (nl() > 0 || fetching || HorizonBridge.state() != HorizonBridge.State.READY) return
        fetching = true
        val app = applicationContext
        Thread({
            WmController.connect(app)
            if (!BubbleService.running) WmController.shutdown(Cfg.rotation(app))
            main.post { fetching = false; refresh() }
        }, "native-size").start()
    }

    private fun commit(t: Int) {
        if (nl() == 0) { Toast.makeText(this, "Panel no detectado: activa Shizuku", Toast.LENGTH_SHORT).show(); return }
        Cfg.setTarget(prefs, t)
        StretchBus.notifyChanged()
        refresh()
    }

    private fun bump(d: Int) = commit(Cfg.target(prefs) + d)
    private fun pct(p: Int) = commit(nl() + nl() * p / 100)

    private fun buildUi(): View {
        val c = this
        val scroll = ScrollView(c).apply { setBackgroundColor(Ui.BG) }
        val col = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, Ui.dp(c, 28), 0, Ui.dp(c, 32))
        }
        scroll.addView(col)
        col.addView(Ui.text(c, "SimpleHorizon", 28f, Ui.TXT, true).apply { setPadding(Ui.dp(c, 20), 0, Ui.dp(c, 20), 0) })
        col.addView(Ui.text(c, "Estiramiento horizontal solo para ${Game.NAME}", 13f, Ui.MUTED).apply {
            setPadding(Ui.dp(c, 20), Ui.dp(c, 2), Ui.dp(c, 20), Ui.dp(c, 8))
        })

        val st = Ui.card(c)
        shizukuTxt = Ui.text(c, "", 14f, Ui.TXT, true)
        shizukuTxt.setOnClickListener {
            if (HorizonBridge.state() == HorizonBridge.State.NO_PERMISSION) HorizonBridge.requestPermission()
            refresh()
        }
        st.addView(shizukuTxt)
        permTxt = Ui.text(c, "", 12f, Ui.MUTED)
        st.addView(permTxt)
        st.addView(Ui.button(c, "Revisar permisos", false) { Permisos.listo(c); refresh() })
        col.addView(st)

        val es = Ui.card(c)
        es.addView(Ui.text(c, "ANCHO EQUIVALENTE (HORIZONTAL)", 12f, Ui.MUTED, true))
        readout = Ui.text(c, "", 36f, Ui.TXT, true)
        es.addView(readout)
        sub = Ui.text(c, "", 12f, Ui.MUTED)
        es.addView(sub)
        seek = SeekBar(c).apply {
            max = 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser && nl() > 0) readout.text = "${Stretch.clamp(nl() + p, nl())} × ${Cfg.ns(prefs)}"
                }
                override fun onStartTrackingTouch(s: SeekBar?) { seeking = true }
                override fun onStopTrackingTouch(s: SeekBar?) { seeking = false; commit(nl() + seek.progress) }
            })
        }
        es.addView(seek)
        es.addView(chipRow("−50" to { bump(-50) }, "−10" to { bump(-10) }, "+10" to { bump(10) }, "+50" to { bump(50) }))
        es.addView(chipRow("+10%" to { pct(10) }, "+20%" to { pct(20) }, "+29%" to { pct(29) }, "+30%" to { pct(30) }, "+40%" to { pct(40) }))
        val exact = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        edit = EditText(c).apply {
            hint = "Ancho exacto (ej. 3526)"
            setHintTextColor(Ui.MUTED)
            setTextColor(Ui.TXT)
            textSize = 14f
            inputType = InputType.TYPE_CLASS_NUMBER
            background = Ui.round(c, Ui.CHIP, 12)
            setPadding(Ui.dp(c, 12), Ui.dp(c, 10), Ui.dp(c, 12), Ui.dp(c, 10))
        }
        exact.addView(edit, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { topMargin = Ui.dp(c, 8) })
        exact.addView(Ui.chip(c, "Fijar", true, 12) {
            val v = edit.text.toString().toIntOrNull()
            val n = nl()
            when {
                n == 0 -> Toast.makeText(c, "Panel no detectado: activa Shizuku", Toast.LENGTH_SHORT).show()
                v == null || v < n || v > n * 2 -> Toast.makeText(c, "Debe estar entre $n y ${n * 2}", Toast.LENGTH_SHORT).show()
                else -> { commit(v); edit.setText("") }
            }
        }.apply { layoutParams = LinearLayout.LayoutParams(Ui.dp(c, 84), ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(c, 8); leftMargin = Ui.dp(c, 8) } })
        es.addView(exact)
        col.addView(es)

        val jg = Ui.card(c)
        jg.addView(Ui.text(c, "JUEGO", 12f, Ui.MUTED, true))
        gameTxt = Ui.text(c, "", 14f, Ui.TXT)
        jg.addView(gameTxt)
        applyBtn = Ui.button(c, "ABRIR JUEGO Y ESTIRAR", true) { Stretcher.start(c) }
        jg.addView(applyBtn)
        jg.addView(switchRow("Estiramiento activo", "on", true) { StretchBus.notifyChanged() })
        jg.addView(switchRow("Menú flotante dentro del juego", "bubble", true) {})
        jg.addView(Ui.button(c, "Restaurar pantalla y cerrar menú", false) {
            if (BubbleService.running) Stretcher.stop(c) else Stretcher.restore(c, true)
            Toast.makeText(c, "Restaurando…", Toast.LENGTH_SHORT).show()
            main.postDelayed({ refresh() }, 800)
        })
        jg.addView(Ui.text(c, "Modo Pro en dos etapas: primero la pantalla lógica queda pequeña con franjas a los lados y luego se estira a todo el panel, con el táctil corregido. Solo en horizontal y dentro de ${Game.NAME}. Emergencia: Volumen + restaura al instante.", 11f, Ui.MUTED).apply { setPadding(0, Ui.dp(c, 10), 0, 0) })
        col.addView(jg)

        val dg = Ui.card(c)
        dg.addView(Ui.button(c, "Diagnóstico (copiar)", false) { diagnostics() })
        col.addView(dg)
        return scroll
    }

    private fun chipRow(vararg items: Pair<String, () -> Unit>): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((t, f) in items) r.addView(Ui.chip(this, t, false, 10, 13f) { f() })
        return r
    }

    private fun switchRow(title: String, key: String, def: Boolean, after: () -> Unit): Switch {
        val pad = Ui.dp(this, 10)
        return Switch(this).apply {
            text = title
            textSize = 14f
            setTextColor(Ui.TXT)
            setPadding(0, pad, 0, pad)
            isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(key, on).apply(); after() }
        }
    }

    private fun diagnostics() {
        val app = applicationContext
        Thread({
            val ok = WmController.connect(app)
            val body = if (ok) WmController.probe() else "Shizuku no está conectado."
            val text = "SimpleHorizon ${version()}\npanel=${nl()}x${Cfg.ns(prefs)} objetivo=${Cfg.target(prefs)} " +
                "activo=${Cfg.on(prefs)} aplicado=${WmController.applied}\nerror=${WmController.lastError}\n\n$body"
            if (!BubbleService.running) WmController.shutdown(Cfg.rotation(app))
            main.post { showCopyable("Diagnóstico", text) }
        }, "diagnostics").start()
    }

    private fun version(): String = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "?" } catch (_: Exception) { "?" }

    private fun showCopyable(title: String, text: String) {
        val c = this
        val body = TextView(c).apply {
            this.text = text
            textSize = 11f
            setTextColor(Ui.TXT)
            setTextIsSelectable(true)
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(Ui.dp(c, 16), Ui.dp(c, 8), Ui.dp(c, 16), Ui.dp(c, 8))
        }
        val dialog = AlertDialog.Builder(c, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(title)
            .setView(ScrollView(c).apply { addView(body) })
            .setPositiveButton("Cerrar", null)
            .setNeutralButton("Copiar todo", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val cm = getSystemService(android.content.ClipboardManager::class.java)
                cm.setPrimaryClip(android.content.ClipData.newPlainText(title, text))
                Toast.makeText(c, "Copiado", Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()
    }

    private fun refresh() {
        val c = this
        val n = nl()
        val t = Cfg.target(prefs)
        if (n == 0) {
            readout.text = "— × —"
            sub.text = "Panel sin detectar: inicia Shizuku y concede el permiso."
            seek.isEnabled = false
        } else {
            if (!seeking) readout.text = "$t × ${Cfg.ns(prefs)}"
            sub.text = "Panel $n × ${Cfg.ns(prefs)} · lógica ${Stretch.logical(t, n)} × ${Cfg.ns(prefs)} · +" +
                String.format(Locale.US, "%.1f", Stretch.pct(t, n)) + "% · " +
                if (BubbleService.running) (if (Cfg.on(prefs)) "en marcha" else "pausado") else "sin iniciar"
            if (WmController.lastError.isNotEmpty()) sub.text = sub.text.toString() + "\nError: " + WmController.lastError
            seek.isEnabled = true
            seek.max = n
            if (!seeking) seek.progress = (t - n).coerceIn(0, n)
        }
        shizukuTxt.text = when (HorizonBridge.state()) {
            HorizonBridge.State.READY -> "✓ Shizuku listo"
            HorizonBridge.State.NO_PERMISSION -> "✗ Shizuku sin permiso · toca para conceder"
            HorizonBridge.State.NOT_RUNNING -> "✗ Shizuku no está activo"
            HorizonBridge.State.UNSUPPORTED -> "✗ Versión de Shizuku no compatible"
        }
        permTxt.text = "Superposición ${ok(Permisos.overlay(c))} · Notificaciones ${ok(Permisos.notif(c))} · " +
            "Uso de apps ${ok(Permisos.uso(c))} · Batería ${ok(Permisos.bateria(c))}"
        gameTxt.text = if (Permisos.instalado(c)) "${Game.NAME} instalado" else "${Game.NAME} no está instalado"
        applyBtn.text = if (BubbleService.running) "ABRIR JUEGO" else "ABRIR JUEGO Y ESTIRAR"
    }

    private fun ok(b: Boolean) = if (b) "✓" else "✗"
}
