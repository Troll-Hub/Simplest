package com.simplehorizon.app

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import rikka.shizuku.Shizuku
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Controla el servicio de Shizuku. Las órdenes se encolan y se fusionan: siempre gana la última. */
object WmController {
    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val lock = Any()
    @Volatile private var svc: IHorizonService? = null
    private var args: Shizuku.UserServiceArgs? = null
    private var conn: ServiceConnection? = null
    @Volatile var nativeW = 0
    @Volatile var nativeH = 0
    @Volatile var lastError = ""

    /** 0 = pantalla original · >0 = ancho equivalente aplicado · -1 = desconocido (se reaplicará). */
    @Volatile var applied = -1
    @Volatile private var appliedRot = -1
    private var wantT = 0
    private var wantRot = 0
    private var pending = false
    @Volatile private var failAt = 0L
    @Volatile private var reconnecting = false

    fun alive(): Boolean = try { svc?.asBinder()?.pingBinder() == true } catch (_: Throwable) { false }

    /** Bloqueante: llamar desde un hilo de fondo. */
    fun connect(ctx: Context): Boolean {
        try { exec.submit {}.get(3, TimeUnit.SECONDS) } catch (_: Throwable) {}
        if (svc != null && alive()) return true
        if (HorizonBridge.state() != HorizonBridge.State.READY) return false
        val latch = CountDownLatch(1)
        val c = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                svc = if (binder != null && binder.pingBinder()) IHorizonService.Stub.asInterface(binder) else null
                latch.countDown()
            }
            override fun onServiceDisconnected(name: ComponentName?) { svc = null; applied = -1 }
        }
        val a = HorizonBridge.serviceArgs(ctx)
        args = a
        conn = c
        svc = null
        try { Shizuku.bindUserService(a, c) } catch (_: Throwable) { return false }
        latch.await(10, TimeUnit.SECONDS)
        if (svc == null) return false
        applied = -1
        try { svc?.startEmergency() } catch (_: Throwable) {}
        return readNative(ctx)
    }

    private fun readNative(ctx: Context): Boolean {
        val out = try { svc?.wm("") ?: "" } catch (_: Throwable) { "" }
        val m = Regex("Physical size: (\\d+)x(\\d+)").find(out) ?: return false
        nativeW = m.groupValues[1].toInt()
        nativeH = m.groupValues[2].toInt()
        Cfg.prefs(ctx).edit().putInt("natW", nativeW).putInt("natH", nativeH).apply()
        return true
    }

    /** Reconecta si Shizuku o el servicio murieron (una sola vez a la vez). */
    fun reconnectAsync(ctx: Context) {
        if (reconnecting) return
        reconnecting = true
        val app = ctx.applicationContext
        Thread({
            try {
                try { val a = args; val c = conn; if (a != null && c != null) Shizuku.unbindUserService(a, c, true) } catch (_: Throwable) {}
                svc = null
                connect(app)
            } finally {
                reconnecting = false
            }
        }, "wm-reconnect").start()
    }

    /** target = 0 restaura. Sin efecto si ya está aplicado con esa rotación. */
    fun apply(target: Int, rot: Int) {
        if (target == applied && (target == 0 || rot == appliedRot)) return
        if (applied == -1 && System.currentTimeMillis() - failAt < 3000) return
        request(target, rot)
    }

    /** Vuelve a pedir lo aplicado (la proyección se pierde si el sistema redibuja la pantalla). */
    fun reassert() {
        if (applied > 0) request(applied, appliedRot.coerceAtLeast(0))
    }

    /** Restaura siempre, aunque el estado se crea ya restaurado. */
    fun restoreNow(rot: Int = 0) = request(0, rot)

    fun markRestored() { synchronized(lock) { if (!pending) applied = 0 } }
    fun markUnknown() { synchronized(lock) { if (!pending) applied = -1 } }

    private fun request(t: Int, rot: Int) {
        synchronized(lock) {
            wantT = t
            wantRot = rot
            applied = t
            appliedRot = rot
            if (pending) return
            pending = true
        }
        exec.execute { drain() }
    }

    private fun drain() {
        while (true) {
            val t: Int
            val rot: Int
            synchronized(lock) { t = wantT; rot = wantRot }
            val ok = doApply(t, rot)
            synchronized(lock) {
                if (t == wantT) {
                    if (!ok) { applied = -1; failAt = System.currentTimeMillis() }
                    pending = false
                    return
                }
            }
        }
    }

    private fun doApply(t: Int, rot: Int): Boolean {
        val s = svc ?: run { lastError = "Sin conexión con Shizuku"; return false }
        if (t > 0 && nativeW == 0) { lastError = "Panel no detectado"; return false }
        val r = try {
            if (t == 0) s.projectRestore(rot) else s.projectStretch(t, rot)
        } catch (e: Throwable) { "error: ${e.message}" }
        lastError = if (r == "ok") "" else r
        return r == "ok"
    }

    /** Latido: 0 original, 1 estirada, 2 emergencia (Volumen +), -1 sin servicio. El resultado llega al hilo principal. */
    fun beat(cb: (Int) -> Unit) {
        exec.execute {
            val r = try { svc?.beat() ?: -1 } catch (_: Throwable) { -1 }
            main.post { cb(r) }
        }
    }

    fun probe(): String = try { svc?.probe() ?: "" } catch (_: Throwable) { "" }

    /** Restaura y cierra el servicio, en orden tras cualquier orden pendiente. */
    fun shutdown(rot: Int = 0) {
        request(0, rot)
        exec.execute {
            try {
                val a = args
                val c = conn
                if (a != null && c != null) Shizuku.unbindUserService(a, c, true)
            } catch (_: Throwable) {}
            svc = null
            conn = null
            args = null
            applied = -1
        }
    }
}
