package com.simplehorizon.app

import android.content.Context
import android.graphics.Rect
import android.os.IBinder
import android.os.Parcel
import java.util.concurrent.TimeUnit

/**
 * Servicio de Shizuku (uid shell). Modo Pro en dos etapas, igual que Cat Resolution Pro:
 *  1) `wm size` deja la pantalla lógica más corta (el sistema la dibuja pequeña, con franjas negras a los lados).
 *  2) La proyección de SurfaceFlinger la estira a todo el panel.
 *  3) El táctil se reinyecta (captura exclusiva + uinput) para compensar las franjas.
 * Seguridad: destroy() restaura; un perro guardián restaura si la app deja de dar latidos; Volumen + restaura al instante.
 */
class HorizonService() : IHorizonService.Stub() {
    private var baseCtx: Context? = null
    constructor(context: Context) : this() { baseCtx = context }

    private companion object {
        val WM_ARG = Regex("^(reset|\\d{3,5}x\\d{3,5})?$")
        const val WATCHDOG_MS = 8_000L
    }

    @Volatile private var wmOn = false
    @Volatile private var projActive = false
    private val overridden get() = wmOn || projActive
    @Volatile private var emergencyFlag = false
    @Volatile private var lastBeat = System.currentTimeMillis()
    @Volatile private var started = false
    private var lastEmergency = 0L
    private var lastRot = 0
    private var lastWmArg = ""
    private var projToken: IBinder? = null
    private var remapProc: Process? = null
    private var remapKey = ""

    private fun sh(script: String): Pair<Int, String> = try {
        val p = ProcessBuilder("sh", "-c", script).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText().trim()
        if (!p.waitFor(8, TimeUnit.SECONDS)) { p.destroyForcibly(); -1 to out } else p.exitValue() to out
    } catch (_: Exception) {
        -1 to ""
    }

    /** "" = consultar; "reset"; "WxH". */
    override fun wm(arg: String): String {
        if (!WM_ARG.matches(arg)) return "error: argumento no válido"
        lastBeat = System.currentTimeMillis()
        if (arg.isEmpty()) return sh("wm size 2>&1").second
        val (code, out) = sh("wm size $arg 2>&1")
        if (code != 0) return "error: " + out.ifEmpty { "código $code" }
        wmOn = arg != "reset"
        if (arg == "reset") lastWmArg = ""
        return "ok"
    }

    /** Latido de la app. 0 = pantalla original, 1 = estirada, 2 = el usuario pulsó Volumen + (ya restaurado). */
    override fun beat(): Int {
        lastBeat = System.currentTimeMillis()
        if (emergencyFlag) { emergencyFlag = false; return 2 }
        return if (overridden) 1 else 0
    }

    // ---------- Pantalla y proyección ----------
    private fun physicalSize(): Pair<Int, Int>? {
        val m = Regex("Physical size: (\\d+)x(\\d+)").find(sh("wm size 2>&1").second) ?: return null
        return m.groupValues[1].toInt() to m.groupValues[2].toInt()
    }

    private fun sfToken(): String {
        if (projToken != null) return "ok"
        val did = Regex("Display (\\d+) \\(HWC").find(sh("dumpsys SurfaceFlinger --display-id 2>&1").second)?.groupValues?.get(1)
            ?: return "ID de pantalla no encontrado"
        val sf = Class.forName("android.os.ServiceManager")
            .getMethod("getService", String::class.java).invoke(null, "SurfaceFlinger") as? IBinder
            ?: return "SurfaceFlinger no encontrado"
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        try {
            data.writeInterfaceToken("android.gui.ISurfaceComposer")
            data.writeLong(did.toLong())
            sf.transact(7, data, reply, 0)
            reply.readException()
            projToken = reply.readStrongBinder() ?: return "token NULL"
            return "ok"
        } finally {
            data.recycle()
            reply.recycle()
        }
    }

    /** layer = región del espacio lógico; display = panel completo; ambos en el espacio ya rotado. */
    private fun setProjection(layer: Rect, display: Rect, rot: Int) {
        val token = projToken ?: throw IllegalStateException("sin token")
        val txCls = Class.forName("android.view.SurfaceControl\$Transaction")
        val tx = txCls.getConstructor().newInstance()
        txCls.getMethod("setDisplayProjection", IBinder::class.java, Int::class.javaPrimitiveType, Rect::class.java, Rect::class.java)
            .invoke(tx, token, rot, layer, display)
        txCls.getMethod("apply").invoke(tx)
    }

    private fun isLandscapeRot(natPortrait: Boolean, rot: Int) = if (natPortrait) rot % 2 == 1 else rot % 2 == 0

    /** Quita el táctil remapeado, el tamaño y la proyección; deja la pantalla como estaba. */
    private fun restoreAll(rot: Int) {
        stopRemap()
        sh("wm size reset")
        wmOn = false
        lastWmArg = ""
        if (projActive) {
            projActive = false
            try {
                Thread.sleep(250)
                val (pw, ph) = physicalSize() ?: return
                val l = maxOf(pw, ph)
                val s = minOf(pw, ph)
                val (w, h) = if (isLandscapeRot(pw < ph, rot)) l to s else s to l
                if (sfToken() == "ok") setProjection(Rect(0, 0, w, h), Rect(0, 0, w, h), rot)
            } catch (_: Throwable) {
            }
        }
    }

    /** Rectángulo (espacio horizontal ya rotado) donde el sistema dibuja la pantalla lógica dentro del panel, si se puede leer. */
    private fun viewportFrame(l: Int, s: Int): IntArray? {
        val out = sh("dumpsys display 2>&1 | grep -m3 'DisplayViewport{type=INTERNAL'").second
        val m = Regex("physicalFrame=Rect\\((\\d+), (\\d+) - (\\d+), (\\d+)\\)").find(out) ?: return null
        val f = intArrayOf(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt(), m.groupValues[4].toInt())
        return if (f[2] - f[0] in 1..l && f[3] - f[1] in 1..s) f else null
    }

    /**
     * `target` es el ancho equivalente (p. ej. 3526 = 2712 × 1,30). El largo lógico es 2712 / 1,30 = 2086: la pantalla
     * queda pequeña con franjas a los lados y la proyección la estira a todo el panel.
     */
    override fun projectStretch(target: Int, rotation: Int): String {
        val rot = rotation and 3
        return try {
            val (pw, ph) = physicalSize() ?: return "error: tamaño físico no leído"
            val l = maxOf(pw, ph)
            val s = minOf(pw, ph)
            val natp = pw < ph
            if (!isLandscapeRot(natp, rot)) return "error: la pantalla no está en horizontal"
            val t = target.coerceIn(l, l * 2)
            val lg = (l.toLong() * l / t).toInt() / 2 * 2
            val tk = sfToken()
            if (tk != "ok") return "error: $tk"
            lastBeat = System.currentTimeMillis()
            val arg = if (natp) "${pw}x$lg" else "${lg}x$ph"
            var changed = false
            if (!wmOn || arg != lastWmArg) {
                val (code, out) = sh("wm size $arg 2>&1")
                if (code != 0) return "error: wm size: $out"
                wmOn = true
                lastWmArg = arg
                changed = true
                Thread.sleep(500) // el sistema recalcula la pantalla lógica
            }
            setProjection(Rect(0, 0, lg, s), Rect(0, 0, l, s), rot)
            // Rectángulo de la etapa 1: lo leído del sistema o, si no se puede, centrado
            var f: IntArray? = null
            var tries = if (changed) 4 else 1
            while (tries-- > 0) {
                f = viewportFrame(l, s)
                if (f == null || f[2] - f[0] < l || f[3] - f[1] < s) break
                if (tries > 0) Thread.sleep(250)
            }
            val left = f?.get(0) ?: (l - lg) / 2
            val right = f?.get(2) ?: (left + lg)
            val top = f?.get(1) ?: 0
            val bottom = f?.get(3) ?: s
            val r = startRemap(rot, natp, left, right, l, top, bottom, s)
            if (r != "ok") {
                restoreAll(rot)
                return "error: táctil: $r"
            }
            projActive = true
            lastRot = rot
            "ok"
        } catch (e: Throwable) {
            restoreAll(rot)
            "error: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    override fun projectRestore(rotation: Int): String = try {
        restoreAll(rotation and 3)
        "ok"
    } catch (e: Throwable) {
        "error: ${e.javaClass.simpleName}: ${e.message}"
    }

    // ---------- Táctil ----------
    private fun helperPath(): String? = baseCtx?.applicationInfo?.nativeLibraryDir?.let { "$it/libtouchremap.so" }

    /** Primer dispositivo con ABS_MT_POSITION_X e INPUT_PROP_DIRECT (el touchscreen). */
    private fun findTouchDev(): String? {
        val script = "for d in /dev/input/event*; do " +
            "if getevent -p \$d 2>/dev/null | grep -q ABS_MT_POSITION_X && " +
            "getevent -p \$d 2>/dev/null | grep -q INPUT_PROP_DIRECT; then echo \$d; break; fi; done"
        return sh(script).second.trim().ifEmpty { null }
    }

    private fun stopRemap() {
        val p = remapProc ?: return
        remapProc = null
        remapKey = ""
        try { p.outputStream.close() } catch (_: Throwable) {}
        try { p.destroy() } catch (_: Throwable) {}
    }

    private fun startRemap(rot: Int, natp: Boolean, left: Int, right: Int, lspan: Int, top: Int, bottom: Int, sspan: Int): String {
        val key = "$rot/$natp/$left/$right/$lspan/$top/$bottom/$sspan"
        val cur = remapProc
        if (cur != null && cur.isAlive && key == remapKey) return "ok"
        stopRemap()
        val exe = helperPath() ?: return "ruta del helper no encontrada"
        if (!java.io.File(exe).exists()) return "helper no incluido en el APK (libtouchremap.so)"
        val dev = findTouchDev() ?: return "touchscreen no encontrado"
        return try {
            val p = ProcessBuilder(exe, dev, rot.toString(), if (natp) "1" else "0", left.toString(), right.toString(), lspan.toString(),
                top.toString(), bottom.toString(), sspan.toString()).redirectErrorStream(true).start()
            val log = StringBuilder()
            Thread({ try { p.inputStream.bufferedReader().forEachLine { log.append(it).append('\n') } } catch (_: Throwable) {} }, "remap-log")
                .apply { isDaemon = true }.start()
            Thread.sleep(400)
            if (!p.isAlive) "el helper terminó (${p.exitValue()}): ${log.toString().trim()}" else {
                remapProc = p
                remapKey = key
                "ok"
            }
        } catch (e: Throwable) {
            "${e.javaClass.simpleName}: ${e.message}"
        }
    }

    // ---------- Seguridad ----------
    override fun startEmergency(): String {
        if (started) return "ok"
        started = true
        // Perro guardián: sin latidos de la app, restaura
        Thread({
            while (true) {
                try { Thread.sleep(1000) } catch (_: InterruptedException) { return@Thread }
                if (overridden && System.currentTimeMillis() - lastBeat > WATCHDOG_MS) restoreAll(lastRot)
            }
        }, "horizon-watchdog").apply { isDaemon = true }.start()
        // Volumen +
        Thread({
            try {
                val p = ProcessBuilder("sh", "-c", "getevent -l 2>&1").redirectErrorStream(true).start()
                p.inputStream.bufferedReader().forEachLine { line ->
                    if (line.contains("KEY_VOLUMEUP") && line.contains("DOWN")) {
                        val now = System.currentTimeMillis()
                        if (now - lastEmergency > 1500) {
                            lastEmergency = now
                            restoreAll(lastRot)
                            emergencyFlag = true
                        }
                    }
                }
            } catch (_: Throwable) {
            }
        }, "horizon-emergency").apply { isDaemon = true }.start()
        return "ok"
    }

    override fun probe(): String {
        val sb = StringBuilder()
        fun add(t: String, s: String) { sb.append("## ").append(t).append('\n').append(s.trim().take(900)).append("\n\n") }
        add("shell", sh("id").second)
        add("android", sh("getprop ro.build.version.release; getprop ro.build.version.sdk; getprop ro.product.manufacturer; getprop ro.product.model").second)
        add("wm", sh("wm size 2>&1; wm density 2>&1").second)
        add("rotación", sh("dumpsys window 2>&1 | grep -m3 -E 'mCurrentRotation|mRotation='").second)
        add("uinput", sh("ls -l /dev/uinput /dev/input/uinput 2>&1").second)
        add("táctil", findTouchDev() ?: "no encontrado")
        add("viewport", sh("dumpsys display 2>&1 | grep -m1 -o 'DisplayViewport{type=INTERNAL[^}]*}'").second)
        add("helper", helperPath().let { h -> if (h == null) "sin ruta" else sh("ls -l $h 2>&1").second })
        add("token SurfaceFlinger", try { val t = sfToken(); if (t == "ok") "ok" else "FALLA: $t" } catch (e: Throwable) { "FALLA: ${e.javaClass.simpleName}: ${e.message}" })
        add("setDisplayProjection", try {
            Class.forName("android.view.SurfaceControl\$Transaction").declaredMethods.filter { it.name == "setDisplayProjection" }
                .joinToString("\n") { m -> m.name + m.parameterTypes.joinToString(",", "(", ")") { it.simpleName } }.ifEmpty { "(no existe)" }
        } catch (e: Throwable) { "FALLA: ${e.javaClass.simpleName}" })
        add("estado", "wm=$wmOn proyeccion=$projActive rot=$lastRot")
        return sb.toString()
    }

    override fun destroy() {
        restoreAll(lastRot)
        System.exit(0)
    }
}
