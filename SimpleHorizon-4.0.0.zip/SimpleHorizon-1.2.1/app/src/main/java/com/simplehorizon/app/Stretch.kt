package com.simplehorizon.app

import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** Único juego soportado. */
object Game {
    const val NAME = "Blood Strike"
    const val PKG = "com.netease.newspike"
}

/**
 * El valor que eliges es el ancho equivalente (largo del panel × multiplicador, p. ej. 2712 × 1,30 = 3526).
 * Internamente el largo lógico del modo Pro es largo / multiplicador (2086), y el lado corto no cambia.
 */
object Stretch {
    private fun even(v: Int) = v / 2 * 2
    fun clamp(target: Int, nl: Int) = even(target.coerceIn(nl, nl * 2))
    fun default(nl: Int) = clamp(nl * 129 / 100, nl)
    fun pct(target: Int, nl: Int) = if (nl <= 0) 0.0 else (target - nl) * 100.0 / nl
    fun logical(target: Int, nl: Int): Int = if (target <= 0) nl else (nl.toLong() * nl / clamp(target, nl)).toInt() / 2 * 2
}

/** Ajustes compartidos entre la pantalla, el menú flotante y el servicio. */
object Cfg {
    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("horizon", Context.MODE_PRIVATE)
    fun nl(p: SharedPreferences) = maxOf(p.getInt("natW", 0), p.getInt("natH", 0))
    fun ns(p: SharedPreferences) = minOf(p.getInt("natW", 0), p.getInt("natH", 0))
    fun on(p: SharedPreferences) = p.getBoolean("on", true)

    fun target(p: SharedPreferences): Int {
        val n = nl(p)
        if (n == 0) return 0
        val t = p.getInt("tw", 0)
        return if (t == 0) Stretch.default(n) else Stretch.clamp(t, n)
    }

    fun setTarget(p: SharedPreferences, t: Int) {
        val n = nl(p)
        if (n > 0) p.edit().putInt("tw", Stretch.clamp(t, n)).apply()
    }

    /** Rotación actual de la pantalla (0..3). */
    fun rotation(c: Context): Int = try {
        c.getSystemService(android.hardware.display.DisplayManager::class.java)
            .getDisplay(android.view.Display.DEFAULT_DISPLAY).rotation
    } catch (_: Throwable) { 0 }
}

object HorizonBridge {
    private const val REQ = 4243
    private const val VERSION = 12
    enum class State { NOT_RUNNING, NO_PERMISSION, READY, UNSUPPORTED }

    fun state(): State = try {
        when {
            !Shizuku.pingBinder() -> State.NOT_RUNNING
            Shizuku.isPreV11() -> State.UNSUPPORTED
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> State.READY
            else -> State.NO_PERMISSION
        }
    } catch (_: Throwable) {
        State.NOT_RUNNING
    }

    fun requestPermission() {
        try { Shizuku.requestPermission(REQ) } catch (_: Throwable) {}
    }

    fun serviceArgs(ctx: Context): Shizuku.UserServiceArgs =
        Shizuku.UserServiceArgs(ComponentName(ctx.packageName, HorizonService::class.java.name))
            .daemon(false).processNameSuffix("horizon").version(VERSION)
}
