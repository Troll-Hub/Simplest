# SimpleHorizon 4.0

Estiramiento **solo horizontal** para Blood Strike (`com.netease.newspike`), con el mismo modo Pro en dos etapas que usa Cat Resolution Pro:

1. `wm size` deja la pantalla lógica más corta (p. ej. 2712 → 2086 con ×1,30): el sistema la dibuja pequeña, con franjas negras a los lados.
2. `setDisplayProjection` de SurfaceFlinger la estira a todo el panel (rectángulo lógico → panel completo).
3. El táctil se reinyecta (captura exclusiva + uinput, `libtouchremap.so`) para compensar las franjas.

Solo se aplica con el juego en primer plano y en horizontal; al salir, en vertical, al cerrar o con Volumen + se restaura.
Seguridad: watchdog con latidos en el servicio de Shizuku, reconexión y restauración si la app muere.
