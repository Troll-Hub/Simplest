package com.simplehorizon.app

import android.app.Activity
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private lateinit var permBtn: Button
    private lateinit var lblL: TextView
    private lateinit var lblV: TextView
    private lateinit var sbL: SeekBar
    private lateinit var sbV: SeekBar
    private val listener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("horizon", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }

        fun text(s: String, size: Float = 14f) = TextView(this).apply { text = s; textSize = size; setPadding(0, pad / 2, 0, pad / 4) }
        fun bar(key: String) = SeekBar(this).apply {
            max = Stretch.MAX - Stretch.MIN
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) prefs.edit().putInt(key, Stretch.MIN + p).apply()
                    showValues()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }

        col.addView(text(getString(R.string.app_name), 28f))
        col.addView(text(Game.NAME, 18f))
        status = text("")
        col.addView(status)
        permBtn = Button(this).apply { text = getString(R.string.dar_permiso); setOnClickListener { HorizonBridge.requestPermission() } }
        col.addView(permBtn)
        lblL = text("")
        col.addView(lblL)
        sbL = bar("l")
        col.addView(sbL)
        lblV = text("")
        col.addView(lblV)
        sbV = bar("v")
        col.addView(sbV)
        col.addView(Button(this).apply { text = getString(R.string.iniciar); setOnClickListener { start() } })
        col.addView(text(getString(R.string.nota)))
        setContentView(ScrollView(this).apply { addView(col) })

        sbL.progress = prefs.getInt("l", 150) - Stretch.MIN
        sbV.progress = prefs.getInt("v", 100) - Stretch.MIN
        showValues()
        try { Shizuku.addRequestPermissionResultListener(listener) } catch (_: Throwable) {}
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { Shizuku.removeRequestPermissionResultListener(listener) } catch (_: Throwable) {}
    }

    private fun installed(): Boolean = try { packageManager.getPackageInfo(Game.PKG, 0); true } catch (_: Exception) { false }

    private fun refresh() {
        val st = HorizonBridge.state()
        status.text = if (!installed()) getString(R.string.no_instalado, Game.NAME) else getString(
            when (st) {
                HorizonBridge.State.READY -> R.string.shizuku_ok
                HorizonBridge.State.NO_PERMISSION -> R.string.shizuku_permiso
                HorizonBridge.State.NOT_RUNNING -> R.string.shizuku_off
                HorizonBridge.State.UNSUPPORTED -> R.string.shizuku_viejo
            }
        )
        permBtn.visibility = if (st == HorizonBridge.State.NO_PERMISSION) View.VISIBLE else View.GONE
    }

    private fun showValues() {
        lblL.text = getString(R.string.horizontal, Stretch.MIN + sbL.progress)
        lblV.text = getString(R.string.vertical, Stretch.MIN + sbV.progress)
    }

    private fun start() {
        when {
            !installed() -> Toast.makeText(this, getString(R.string.no_instalado, Game.NAME), Toast.LENGTH_LONG).show()
            HorizonBridge.state() != HorizonBridge.State.READY -> Toast.makeText(this, R.string.h_shizuku_off, Toast.LENGTH_LONG).show()
            else -> HorizonActivity.start(this, Game.PKG, Stretch.MIN + sbL.progress, Stretch.MIN + sbV.progress)
        }
    }
}
