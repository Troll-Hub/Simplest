package com.simplehorizon.app;

import android.view.MotionEvent;
import android.view.Surface;

interface IHorizonService {
    void destroy() = 16777114;
    boolean forceStop(String pkg) = 1;
    int startDisplay(in Surface surface, int width, int height, int dpi, IBinder token) = 2;
    boolean launchOnDisplay(String pkg, String activity, int displayId) = 3;
    oneway void injectTouch(in MotionEvent event, int displayId) = 4;
    boolean injectKey(int keyCode, int displayId) = 5;
    void setSurface(in Surface surface) = 6;
    void resize(int width, int height, int dpi) = 7;
    void stopDisplay() = 8;
    String lastError() = 9;
}
