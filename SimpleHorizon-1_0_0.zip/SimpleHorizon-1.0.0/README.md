# SimpleHorizon

Stretch de pantalla por juego, sin `wm size`: el juego corre en una pantalla virtual (Shizuku) que Android escala para llenar el panel. Perfil propio por juego y porcentaje distinto en horizontal y vertical.
