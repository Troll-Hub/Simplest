package com.simplehorizon.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private lateinit var permBtn: Button
    private lateinit var gameBtn: Button
    private lateinit var lblL: TextView
    private lateinit var lblV: TextView
    private lateinit var sbL: SeekBar
    private lateinit var sbV: SeekBar
    private var pkg = ""
    private val listener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }

    private data class App(val label: String, val pkg: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("horizon", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }

        fun text(s: String, size: Float = 14f) = TextView(this).apply { text = s; textSize = size; setPadding(0, pad / 2, 0, pad / 4) }
        fun bar(onChange: (Int) -> Unit) = SeekBar(this).apply {
            max = Stretch.MAX - Stretch.MIN
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) onChange(Stretch.MIN + p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }

        col.addView(text(getString(R.string.app_name), 28f))
        status = text("")
        col.addView(status)
        permBtn = Button(this).apply { text = getString(R.string.dar_permiso); setOnClickListener { HorizonBridge.requestPermission() } }
        col.addView(permBtn)
        col.addView(text(getString(R.string.juego), 16f))
        gameBtn = Button(this).apply { setOnClickListener { pickGame() } }
        col.addView(gameBtn)
        lblL = text("")
        col.addView(lblL)
        sbL = bar { v -> if (pkg.isNotEmpty()) prefs.edit().putInt("l_$pkg", v).apply(); showValues() }
        col.addView(sbL)
        lblV = text("")
        col.addView(lblV)
        sbV = bar { v -> if (pkg.isNotEmpty()) prefs.edit().putInt("v_$pkg", v).apply(); showValues() }
        col.addView(sbV)
        col.addView(Button(this).apply { text = getString(R.string.iniciar); setOnClickListener { start() } })
        col.addView(text(getString(R.string.nota)))
        setContentView(ScrollView(this).apply { addView(col) })

        pkg = prefs.getString("pkg", "") ?: ""
        loadGame()
        try { Shizuku.addRequestPermissionResultListener(listener) } catch (_: Throwable) {}
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { Shizuku.removeRequestPermissionResultListener(listener) } catch (_: Throwable) {}
    }

    private fun refresh() {
        val st = HorizonBridge.state()
        status.text = getString(
            when (st) {
                HorizonBridge.State.READY -> R.string.shizuku_ok
                HorizonBridge.State.NO_PERMISSION -> R.string.shizuku_permiso
                HorizonBridge.State.NOT_RUNNING -> R.string.shizuku_off
                HorizonBridge.State.UNSUPPORTED -> R.string.shizuku_viejo
            }
        )
        permBtn.visibility = if (st == HorizonBridge.State.NO_PERMISSION) View.VISIBLE else View.GONE
    }

    private fun pickGame() {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(i, 0)
            .map { App(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
        AlertDialog.Builder(this)
            .setTitle(R.string.juego)
            .setItems(apps.map { it.label }.toTypedArray()) { _, which ->
                pkg = apps[which].pkg
                prefs.edit().putString("pkg", pkg).putString("label", apps[which].label).apply()
                loadGame()
            }
            .show()
    }

    /** Carga los valores guardados de este juego (cada juego tiene su propio perfil). */
    private fun loadGame() {
        gameBtn.text = if (pkg.isEmpty()) getString(R.string.elegir) else (prefs.getString("label", pkg) ?: pkg)
        sbL.progress = prefs.getInt("l_$pkg", 150) - Stretch.MIN
        sbV.progress = prefs.getInt("v_$pkg", 100) - Stretch.MIN
        showValues()
    }

    private fun showValues() {
        lblL.text = getString(R.string.horizontal, Stretch.MIN + sbL.progress)
        lblV.text = getString(R.string.vertical, Stretch.MIN + sbV.progress)
    }

    private fun start() {
        when {
            pkg.isEmpty() -> Toast.makeText(this, R.string.elegir, Toast.LENGTH_SHORT).show()
            HorizonBridge.state() != HorizonBridge.State.READY -> Toast.makeText(this, R.string.h_shizuku_off, Toast.LENGTH_LONG).show()
            else -> HorizonActivity.start(this, pkg, Stretch.MIN + sbL.progress, Stretch.MIN + sbV.progress)
        }
    }
}
