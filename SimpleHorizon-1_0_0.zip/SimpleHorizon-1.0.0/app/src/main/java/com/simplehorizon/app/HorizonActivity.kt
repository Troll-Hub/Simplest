package com.simplehorizon.app

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.content.ServiceConnection
import android.graphics.Color
import android.os.Binder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import rikka.shizuku.Shizuku

/**
 * Stretch solo para Roblox, sin wm size.
 *
 * Shizuku crea una pantalla virtual con el tamaño estirado (p. ej. 4:3) y Roblox se abre en ella.
 * La imagen de esa pantalla va a un SurfaceView a pantalla completa y Android la escala para llenar
 * el panel: ese escalado es el estiramiento. Los toques se reescalan y se inyectan en la pantalla
 * virtual. No cambia ningún ajuste del sistema: al salir, la pantalla virtual desaparece y listo.
 */
class HorizonActivity : Activity(), SurfaceHolder.Callback {
    companion object {
        private const val EXTRA_PKG = "pkg"
        private const val EXTRA_L = "pctL"
        private const val EXTRA_V = "pctV"

        fun start(ctx: Context, pkg: String, pctL: Int, pctV: Int) {
            val i = Intent(ctx, HorizonActivity::class.java)
                .putExtra(EXTRA_PKG, pkg)
                .putExtra(EXTRA_L, pctL)
                .putExtra(EXTRA_V, pctV)
            if (ctx !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val token = Binder()
    private lateinit var status: TextView

    private var pkg = ""
    private var pctL = 100   // % de stretch en horizontal
    private var pctV = 100   // % de stretch en vertical
    private lateinit var surfaceView: SurfaceView
    @Volatile private var vw = 0   // tamaño actual de la pantalla virtual
    @Volatile private var vh = 0
    private var dpi = 0

    @Volatile private var svc: IHorizonService? = null
    @Volatile private var displayId = -1
    @Volatile private var pendingSurface: Surface? = null
    private var starting = false
    private var cleaned = false
    private var args: Shizuku.UserServiceArgs? = null
    private var conn: ServiceConnection? = null
    private var lastBack = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val p = intent.getStringExtra(EXTRA_PKG)
        if (p == null) {
            finish()
            return
        }
        pkg = p
        pctL = Stretch.clamp(intent.getIntExtra(EXTRA_L, 100))
        pctV = Stretch.clamp(intent.getIntExtra(EXTRA_V, 100))

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideSystemBars()

        // Vertical: sin estirar (menú de Roblox). Horizontal: estirado según el porcentaje.
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(dm)
        dpi = dm.densityDpi
        val (sw, sh) = targetSize()
        vw = sw
        vh = sh

        val d = resources.displayMetrics.density
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        val sv = SurfaceView(this)
        surfaceView = sv
        // Buffer del tamaño estirado: el compositor lo escala a toda la pantalla
        sv.holder.setFixedSize(vw, vh)
        sv.holder.addCallback(this)
        sv.setOnTouchListener { v, e -> forwardTouch(v, e); true }
        root.addView(sv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        status = TextView(this)
        status.setTextColor(Color.WHITE)
        status.setBackgroundColor(0x99000000.toInt())
        status.textSize = 13f
        status.setPadding((12 * d).toInt(), (6 * d).toInt(), (12 * d).toInt(), (6 * d).toInt())
        val slp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        slp.topMargin = (16 * d).toInt()
        root.addView(status, slp)
        setContentView(root)

        showStatus(getString(R.string.h_iniciando), false)
        bind()
    }

    /** Tamaño de la pantalla virtual según la orientación actual del teléfono. */
    private fun targetSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(dm)
        val w = dm.widthPixels
        val h = dm.heightPixels
        return Stretch.size(w, h, if (w > h) pctL else pctV)
    }

    /** Al girar el teléfono: horizontal = estirado, vertical = tamaño normal. */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!::surfaceView.isInitialized) return
        val (nw, nh) = targetSize()
        if (nw == vw && nh == vh) return
        vw = nw
        vh = nh
        surfaceView.holder.setFixedSize(nw, nh)
        val service = svc
        if (service != null && displayId >= 0) {
            Thread({ try { service.resize(nw, nh, dpi) } catch (_: Throwable) {} }, "simplehorizon-resize").start()
        }
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun showStatus(text: String, persistent: Boolean) {
        status.text = text
        status.visibility = View.VISIBLE
        main.removeCallbacksAndMessages(STATUS_TAG)
        if (!persistent) main.postAtTime({ status.visibility = View.GONE }, STATUS_TAG, SystemClock.uptimeMillis() + 4000)
    }

    private val STATUS_TAG = Any()

    private fun fail(msg: String?) {
        main.post {
            showStatus(getString(R.string.h_error, msg ?: "?"), true)
            main.postDelayed({ if (!isFinishing) finish() }, 6000)
        }
    }

    // ---------- Conexión con el servicio de Shizuku (se mantiene mientras dure el stretch) ----------
    private fun bind() {
        if (HorizonBridge.state() != HorizonBridge.State.READY) {
            fail(getString(R.string.h_shizuku_off))
            return
        }
        val a = HorizonBridge.serviceArgs(this)
        val c = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                val service = if (binder != null && binder.pingBinder()) IHorizonService.Stub.asInterface(binder) else null
                if (service == null) {
                    fail(getString(R.string.h_sin_servicio))
                } else {
                    svc = service
                    tryStart()
                }
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                svc = null
            }
        }
        args = a
        conn = c
        try {
            Shizuku.bindUserService(a, c)
        } catch (e: Throwable) {
            fail(getString(R.string.h_conexion, e.message))
        }
    }

    // ---------- Superficie ----------
    override fun surfaceCreated(holder: SurfaceHolder) {
        pendingSurface = holder.surface
        tryStart()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        pendingSurface = null
        // En segundo plano la pantalla virtual se queda sin superficie; al volver se reengancha
        try { svc?.setSurface(null) } catch (_: Throwable) {}
    }

    /** Arranca (una sola vez) o reengancha la superficie cuando hay servicio y superficie. */
    private fun tryStart() {
        val service = svc ?: return
        val surf = pendingSurface ?: return
        if (!surf.isValid) return
        if (displayId >= 0) {
            try { service.setSurface(surf) } catch (_: Throwable) {}
            return
        }
        if (starting) return
        starting = true
        Thread({
            try {
                service.forceStop(pkg) // que Roblox arranque limpio y lea los flags
                val id = service.startDisplay(surf, vw, vh, dpi, token)
                if (id < 0) {
                    fail(service.lastError())
                } else {
                    displayId = id
                    if (service.launchOnDisplay(pkg, id)) {
                        main.post { showStatus(getString(R.string.h_salir), false) }
                    } else {
                        fail(service.lastError())
                    }
                }
            } catch (e: Throwable) {
                fail(e.message)
            }
        }, "simplehorizon-stretch").start()
    }

    // ---------- Entrada ----------
    /** Reescala el toque del panel a la pantalla virtual y lo manda a inyectar (uid shell). */
    private fun forwardTouch(v: View, e: MotionEvent) {
        val service = svc ?: return
        val id = displayId
        if (id < 0 || v.width <= 0 || v.height <= 0) return
        val sx = vw.toFloat() / v.width
        val sy = vh.toFloat() / v.height
        val n = e.pointerCount
        val props = Array(n) { i -> MotionEvent.PointerProperties().also { e.getPointerProperties(i, it) } }
        val coords = Array(n) { i ->
            MotionEvent.PointerCoords().also {
                e.getPointerCoords(i, it)
                it.x *= sx
                it.y *= sy
            }
        }
        val ev = MotionEvent.obtain(
            e.downTime, e.eventTime, e.action, n, props, coords,
            e.metaState, e.buttonState, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0
        )
        try {
            service.injectTouch(ev, id)
        } catch (_: Throwable) {
        } finally {
            ev.recycle()
        }
    }

    /** Atrás una vez va a Roblox; dos veces seguidas sale del modo stretch. */
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        val now = SystemClock.uptimeMillis()
        if (now - lastBack < 700) {
            finish()
            return
        }
        lastBack = now
        val service = svc
        val id = displayId
        if (service != null && id >= 0) {
            Thread({ try { service.injectKey(KeyEvent.KEYCODE_BACK, id) } catch (_: Throwable) {} }, "simplehorizon-back").start()
        } else {
            finish()
        }
    }

    // ---------- Limpieza ----------
    override fun onDestroy() {
        super.onDestroy()
        main.removeCallbacksAndMessages(null)
        if (cleaned) return
        cleaned = true
        val service = svc
        val a = args
        val c = conn
        val p = pkg
        Thread({
            try { service?.stopDisplay() } catch (_: Throwable) {}
            try { if (p.isNotEmpty()) service?.forceStop(p) } catch (_: Throwable) {}
            try { if (a != null && c != null) Shizuku.unbindUserService(a, c, true) } catch (_: Throwable) {}
        }, "simplehorizon-stretch-cleanup").start()
    }
}
