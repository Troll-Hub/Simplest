package com.simplehorizon.app

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object Stretch {
    const val MIN = 100
    const val MAX = 300
    fun clamp(p: Int) = p.coerceIn(MIN, MAX)

    /** Tamaño de la pantalla virtual: recorta el eje largo según el porcentaje (100 = sin estirar). */
    fun size(w: Int, h: Int, pct: Int): Pair<Int, Int> {
        val p = clamp(pct)
        fun cut(v: Int) = ((v * 100 / p) / 2 * 2).coerceAtLeast(64)
        return if (w > h) cut(w) to h else w to cut(h)
    }
}

object HorizonBridge {
    private const val REQ = 4243
    private const val VERSION = 1
    enum class State { NOT_RUNNING, NO_PERMISSION, READY, UNSUPPORTED }

    fun state(): State = try {
        when {
            !Shizuku.pingBinder() -> State.NOT_RUNNING
            Shizuku.isPreV11() -> State.UNSUPPORTED
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> State.READY
            else -> State.NO_PERMISSION
        }
    } catch (_: Throwable) {
        State.NOT_RUNNING
    }

    fun requestPermission() {
        try { Shizuku.requestPermission(REQ) } catch (_: Throwable) {}
    }

    /** No daemon: el servicio (y la pantalla virtual) mueren con la app. */
    fun serviceArgs(ctx: Context): Shizuku.UserServiceArgs =
        Shizuku.UserServiceArgs(ComponentName(ctx.packageName, HorizonService::class.java.name))
            .daemon(false).processNameSuffix("horizon").version(VERSION)
}
