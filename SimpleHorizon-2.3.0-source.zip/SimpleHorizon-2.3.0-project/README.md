# SimpleHorizon 2.3

Estiramiento **solo horizontal** para Blood Strike (`com.netease.newspike`) con `wm size` vía Shizuku.
El lado largo del panel crece y el corto no cambia (2400×1080 → 2740×1080). Solo se aplica con el juego en primer plano
y la pantalla en horizontal; en vertical o al salir del juego se restaura. Menú flotante en tiempo real, tema negro y blanco.
Seguridad: restaura al cerrar, perro guardián en el servicio Shizuku y Volumen + como emergencia.

Método por defecto (estilo Pro): `wm size` + proyección de SurfaceFlinger + remapeo táctil mediante `libtouchremap.so`. Hay dos geometrías: **estirar toda la imagen** (deforma horizontalmente) y **recorte lateral** (conserva proporciones y corta ambos bordes). La geometría se puede cambiar desde la app o el menú flotante y necesita la opción de proyección activa. Alternativa: solo `wm size`.

El modo de recorte ajusta también la región táctil horizontal; el modo de estiramiento conserva el ajuste vertical del viewport. Si el controlador táctil no puede iniciar, el servicio restaura el tamaño antes de informar del error.
