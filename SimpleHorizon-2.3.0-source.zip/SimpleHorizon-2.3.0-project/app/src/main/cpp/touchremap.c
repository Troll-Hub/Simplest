/*
 * touchremap <dev> <rot> <natPortrait> <xStartPpm> <xEndPpm> <yStartPpm> <yEndPpm>
 *
 * Toma el touchscreen en exclusiva (EVIOCGRAB), crea un dispositivo uinput idéntico en rango y reinyecta los toques.
 * Los rangos x/y (en partes por millón) transforman coordenadas normalizadas del panel a la zona activa
 * de la imagen lógica. En full stretch se corrige principalmente Y; en side crop se corrige X.
 * rot = rotación de la pantalla (0..3); natPortrait = 1 si el panel es vertical de fábrica.
 * Si el proceso termina (stdin cerrado, SIGTERM, error) el kernel suelta el grab y el dispositivo virtual desaparece.
 */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <linux/input.h>
#include <linux/uinput.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>

#define MAXS 16

static int touch_fd = -1;
static int uin_fd = -1;
static volatile sig_atomic_t quit_flag = 0;

static void on_signal(int s) { (void)s; quit_flag = 1; }

static void cleanup(void) {
    if (uin_fd >= 0) { ioctl(uin_fd, UI_DEV_DESTROY); close(uin_fd); uin_fd = -1; }
    if (touch_fd >= 0) { ioctl(touch_fd, EVIOCGRAB, 0); close(touch_fd); touch_fd = -1; }
}

static int emit(int type, int code, int value) {
    struct input_event ev;
    memset(&ev, 0, sizeof ev);
    ev.type = (__u16)type;
    ev.code = (__u16)code;
    ev.value = value;
    return write(uin_fd, &ev, sizeof ev) == (ssize_t)sizeof ev ? 0 : -1;
}

/* Convierte coordenadas naturales a espacio horizontal, adapta la región activa y vuelve a orientación natural. */
static void xform(double nx, double ny, int rot, int natp, double x0, double x1, double y0, double y1, double *ox, double *oy) {
    double lx, ly;
    int r = rot & 3;
    if (natp) {
        if (r == 1) { lx = ny; ly = 1.0 - nx; }
        else if (r == 3) { lx = 1.0 - ny; ly = nx; }
        else { lx = nx; ly = ny; }
    } else {
        if (r == 2) { lx = 1.0 - nx; ly = 1.0 - ny; }
        else { lx = nx; ly = ny; }
    }
    lx = x0 + lx * (x1 - x0);
    ly = y0 + ly * (y1 - y0);
    if (lx > 1.0) lx = 1.0;
    if (lx < 0.0) lx = 0.0;
    if (ly > 1.0) ly = 1.0;
    if (ly < 0.0) ly = 0.0;
    if (natp) {
        if (r == 1) { *ox = 1.0 - ly; *oy = lx; }
        else if (r == 3) { *ox = ly; *oy = 1.0 - lx; }
        else { *ox = lx; *oy = ly; }
    } else {
        if (r == 2) { *ox = 1.0 - lx; *oy = 1.0 - ly; }
        else { *ox = lx; *oy = ly; }
    }
}

static int getmax(int code, int def) {
    struct input_absinfo a;
    if (ioctl(touch_fd, EVIOCGABS(code), &a) < 0 || a.maximum <= 0) return def;
    return a.maximum;
}

int main(int argc, char **argv) {
    if (argc < 8) { fprintf(stderr, "uso: touchremap <dev> <rot> <natp> <x0ppm> <x1ppm> <y0ppm> <y1ppm>\n"); return 2; }
    const char *dev = argv[1];
    int rot = atoi(argv[2]);
    int natp = atoi(argv[3]) != 0;
    int x0ppm = atoi(argv[4]);
    int x1ppm = atoi(argv[5]);
    int y0ppm = atoi(argv[6]);
    int y1ppm = atoi(argv[7]);
    if (x0ppm < 0 || x1ppm > 1000000 || x1ppm <= x0ppm || y0ppm < 0 || y1ppm > 1000000 || y1ppm <= y0ppm) { fprintf(stderr, "región táctil no válida\n"); return 2; }
    double x0 = (double)x0ppm / 1000000.0, x1 = (double)x1ppm / 1000000.0;
    double y0 = (double)y0ppm / 1000000.0, y1 = (double)y1ppm / 1000000.0;

    signal(SIGTERM, on_signal);
    signal(SIGINT, on_signal);
    signal(SIGHUP, on_signal);
    signal(SIGPIPE, SIG_IGN);

    touch_fd = open(dev, O_RDONLY | O_CLOEXEC);
    if (touch_fd < 0) { perror("open touch"); return 1; }

    struct input_absinfo ax, ay;
    if (ioctl(touch_fd, EVIOCGABS(ABS_MT_POSITION_X), &ax) < 0 ||
        ioctl(touch_fd, EVIOCGABS(ABS_MT_POSITION_Y), &ay) < 0 || ax.maximum <= 0 || ay.maximum <= 0) {
        perror("EVIOCGABS");
        cleanup();
        return 1;
    }
    int slotmax = getmax(ABS_MT_SLOT, 9);
    if (slotmax >= MAXS) slotmax = MAXS - 1;

    uin_fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK | O_CLOEXEC);
    if (uin_fd < 0) { perror("open uinput"); cleanup(); return 1; }

    ioctl(uin_fd, UI_SET_EVBIT, EV_ABS);
    ioctl(uin_fd, UI_SET_EVBIT, EV_KEY);
    ioctl(uin_fd, UI_SET_EVBIT, EV_SYN);
    ioctl(uin_fd, UI_SET_KEYBIT, BTN_TOUCH);
    static const int abs_codes[] = {
        ABS_MT_SLOT, ABS_MT_TRACKING_ID, ABS_MT_POSITION_X, ABS_MT_POSITION_Y,
        ABS_MT_TOUCH_MAJOR, ABS_MT_TOUCH_MINOR, ABS_MT_PRESSURE
    };
    for (size_t i = 0; i < sizeof abs_codes / sizeof abs_codes[0]; i++) ioctl(uin_fd, UI_SET_ABSBIT, abs_codes[i]);
    ioctl(uin_fd, UI_SET_PROPBIT, INPUT_PROP_DIRECT);

    struct uinput_user_dev ud;
    memset(&ud, 0, sizeof ud);
    snprintf(ud.name, UINPUT_MAX_NAME_SIZE, "SimpleHorizon touch remap");
    ud.id.bustype = BUS_VIRTUAL;
    ud.id.vendor = 0x1;
    ud.id.product = 0x2;
    ud.id.version = 1;
    ud.absmax[ABS_MT_POSITION_X] = ax.maximum;
    ud.absmax[ABS_MT_POSITION_Y] = ay.maximum;
    ud.absmax[ABS_MT_SLOT] = slotmax;
    ud.absmax[ABS_MT_TRACKING_ID] = 65535;
    ud.absmax[ABS_MT_TOUCH_MAJOR] = getmax(ABS_MT_TOUCH_MAJOR, 255);
    ud.absmax[ABS_MT_TOUCH_MINOR] = getmax(ABS_MT_TOUCH_MINOR, 255);
    ud.absmax[ABS_MT_PRESSURE] = getmax(ABS_MT_PRESSURE, 255);
    if (write(uin_fd, &ud, sizeof ud) != (ssize_t)sizeof ud) { perror("uinput setup"); cleanup(); return 1; }
    if (ioctl(uin_fd, UI_DEV_CREATE) < 0) { perror("UI_DEV_CREATE"); cleanup(); return 1; }

    /* El grab va después de crear el dispositivo virtual: el táctil nunca queda sin reemplazo. */
    if (ioctl(touch_fd, EVIOCGRAB, 1) < 0) { perror("EVIOCGRAB"); cleanup(); return 1; }

    struct pollfd pfd[2];
    pfd[0].fd = touch_fd;
    pfd[0].events = POLLIN;
    pfd[1].fd = 0; /* stdin: si el servicio que nos lanzó muere, se cierra y salimos */
    pfd[1].events = 0;

    int cur = 0, last_emit = -1;
    int rawx[MAXS], rawy[MAXS];
    unsigned dirty = 0, seenx = 0, seeny = 0;
    memset(rawx, 0, sizeof rawx);
    memset(rawy, 0, sizeof rawy);

    struct input_event buf[64];
    while (!quit_flag) {
        int r = poll(pfd, 2, 500);
        if (r < 0) { if (errno == EINTR) continue; break; }
        if (pfd[1].revents & (POLLHUP | POLLERR | POLLNVAL)) break;
        if (!(pfd[0].revents & POLLIN)) continue;

        ssize_t n = read(touch_fd, buf, sizeof buf);
        if (n <= 0) break;
        size_t count = (size_t)n / sizeof buf[0];
        int failed = 0;
        for (size_t i = 0; i < count && !failed; i++) {
            struct input_event *ev = &buf[i];
            if (ev->type == EV_ABS) {
                switch (ev->code) {
                case ABS_MT_SLOT:
                    cur = ev->value < 0 ? 0 : (ev->value > slotmax ? slotmax : ev->value);
                    failed = emit(EV_ABS, ABS_MT_SLOT, cur) < 0;
                    last_emit = cur;
                    break;
                case ABS_MT_POSITION_X:
                    rawx[cur] = ev->value; seenx |= 1u << cur; dirty |= 1u << cur;
                    break;
                case ABS_MT_POSITION_Y:
                    rawy[cur] = ev->value; seeny |= 1u << cur; dirty |= 1u << cur;
                    break;
                case ABS_MT_TRACKING_ID:
                    if (ev->value < 0) { seenx &= ~(1u << cur); seeny &= ~(1u << cur); dirty &= ~(1u << cur); }
                    failed = emit(EV_ABS, ev->code, ev->value) < 0;
                    break;
                case ABS_MT_TOUCH_MAJOR:
                case ABS_MT_TOUCH_MINOR:
                case ABS_MT_PRESSURE:
                    failed = emit(EV_ABS, ev->code, ev->value) < 0;
                    break;
                default:
                    break;
                }
            } else if (ev->type == EV_KEY) {
                failed = emit(EV_KEY, ev->code, ev->value) < 0;
            } else if (ev->type == EV_SYN && ev->code == SYN_REPORT) {
                for (int s = 0; s < MAXS && !failed; s++) {
                    unsigned b = 1u << s;
                    if (!(dirty & b) || !(seenx & b) || !(seeny & b)) continue;
                    double ox, oy;
                    xform((double)rawx[s] / ax.maximum, (double)rawy[s] / ay.maximum, rot, natp, x0, x1, y0, y1, &ox, &oy);
                    if (last_emit != s) { failed = emit(EV_ABS, ABS_MT_SLOT, s) < 0; last_emit = s; }
                    if (!failed) failed = emit(EV_ABS, ABS_MT_POSITION_X, (int)(ox * ax.maximum + 0.5)) < 0;
                    if (!failed) failed = emit(EV_ABS, ABS_MT_POSITION_Y, (int)(oy * ay.maximum + 0.5)) < 0;
                }
                dirty = 0;
                if (!failed && last_emit != cur) { failed = emit(EV_ABS, ABS_MT_SLOT, cur) < 0; last_emit = cur; }
                if (!failed) failed = emit(EV_SYN, SYN_REPORT, 0) < 0;
            }
        }
        if (failed) break;
    }

    cleanup();
    return 0;
}
