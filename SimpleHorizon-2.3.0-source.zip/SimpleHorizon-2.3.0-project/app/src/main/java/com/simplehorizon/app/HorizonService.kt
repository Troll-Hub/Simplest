package com.simplehorizon.app

import android.content.Context
import android.graphics.Rect
import android.os.IBinder
import android.os.Parcel
import java.util.concurrent.TimeUnit

/**
 * Servicio de Shizuku (uid shell): controla wm size, proyección SurfaceFlinger y remapeo táctil.
 *  - destroy(): restaura al cerrarse.
 *  - perro guardián: si la app deja de dar latidos (beat) con el estiramiento activo, restaura.
 *  - Volumen +: restaura al instante (emergencia).
 */
class HorizonService() : IHorizonService.Stub() {
    @Suppress("unused") private var baseCtx: Context? = null
    constructor(context: Context) : this() { baseCtx = context }

    private companion object {
        val WM_ARG = Regex("^(reset|\\d{3,5}x\\d{3,5})?$")
        const val WATCHDOG_MS = 12_000L
    }

    @Volatile private var wmOn = false
    @Volatile private var projActive = false
    private val overridden get() = wmOn || projActive
    private var lastRot = 0
    private var projToken: IBinder? = null
    private var remapProc: Process? = null
    private var remapKey = ""
    private var lastWmArg = ""
    @Volatile private var emergencyFlag = false
    @Volatile private var lastBeat = System.currentTimeMillis()
    @Volatile private var started = false
    private var lastEmergency = 0L

    private fun sh(script: String): Pair<Int, String> = try {
        val p = ProcessBuilder("sh", "-c", script).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText().trim()
        if (!p.waitFor(8, TimeUnit.SECONDS)) { p.destroyForcibly(); -1 to out } else p.exitValue() to out
    } catch (_: Exception) {
        -1 to ""
    }

    /** "" = consultar; "reset"; "WxH". Devuelve "ok" o "error: …" al cambiar; el texto de wm al consultar. */
    override fun wm(arg: String): String {
        if (!WM_ARG.matches(arg)) return "error: argumento no válido"
        lastBeat = System.currentTimeMillis()
        if (arg.isEmpty()) return sh("wm size 2>&1").second
        val (code, out) = sh("wm size $arg 2>&1")
        if (code != 0) return "error: " + out.ifEmpty { "código $code" }
        wmOn = arg != "reset"
        if (arg == "reset") lastWmArg = ""
        return "ok"
    }

    /** Latido de la app. 0 = pantalla original, 1 = estirada, 2 = el usuario pulsó Volumen + (ya restaurado). */
    override fun beat(): Int {
        lastBeat = System.currentTimeMillis()
        if (emergencyFlag) { emergencyFlag = false; return 2 }
        return if (overridden) 1 else 0
    }

    private fun restoreNow() {
        sh("wm size reset")
        wmOn = false
        lastWmArg = ""
        if (projActive) {
            try { rawRestore(lastRot) } catch (_: Throwable) { stopRemap() }
            projActive = false
        }
    }

    // ---------- Proyección de SurfaceFlinger + remapeo de táctil ----------
    private fun physicalSize(): Pair<Int, Int>? {
        val m = Regex("Physical size: (\\d+)x(\\d+)").find(sh("wm size 2>&1").second) ?: return null
        return m.groupValues[1].toInt() to m.groupValues[2].toInt()
    }

    private fun sfToken(): String {
        if (try { projToken?.isBinderAlive == true } catch (_: Throwable) { false }) return "ok"
        projToken = null
        val listed = sh("dumpsys SurfaceFlinger --display-id 2>&1").second
        val ids = Regex("Display\\s+(\\d+)\\s+\\(HWC").findAll(listed)
            .mapNotNull { it.groupValues.getOrNull(1)?.toLongOrNull() }.distinct().toList()
        if (ids.isEmpty()) return "ID de pantalla física no encontrado"

        // Android builds differ: try SurfaceControl's hidden token accessors first, then the
        // legacy SurfaceFlinger binder transaction. This keeps the implementation portable.
        try {
            val sc = Class.forName("android.view.SurfaceControl")
            val methods = sc.declaredMethods.filter {
                it.name in setOf("getPhysicalDisplayToken", "getInternalDisplayToken", "getBuiltInDisplay")
            }
            for (m in methods) {
                try {
                    m.isAccessible = true
                    val args: Array<Any?> = when {
                        m.parameterTypes.isEmpty() -> emptyArray<Any?>()
                        m.parameterTypes.size == 1 && m.parameterTypes[0] == java.lang.Long.TYPE -> arrayOf<Any?>(ids.first())
                        m.parameterTypes.size == 1 && m.parameterTypes[0] == java.lang.Integer.TYPE -> arrayOf<Any?>(0)
                        else -> continue
                    }
                    val token = m.invoke(null, *args) as? IBinder
                    if (token != null && token.isBinderAlive) { projToken = token; return "ok" }
                } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}

        val sf = try {
            Class.forName("android.os.ServiceManager")
                .getMethod("getService", String::class.java).invoke(null, "SurfaceFlinger") as? IBinder
        } catch (_: Throwable) { null } ?: return "SurfaceFlinger no encontrado"
        var lastError = "SurfaceFlinger no devolvió token"
        for (id in ids) {
            val data = Parcel.obtain()
            val reply = Parcel.obtain()
            try {
                data.writeInterfaceToken("android.gui.ISurfaceComposer")
                data.writeLong(id)
                if (sf.transact(7, data, reply, 0)) {
                    reply.readException()
                    val token = reply.readStrongBinder()
                    if (token != null && token.isBinderAlive) { projToken = token; return "ok" }
                }
            } catch (e: Throwable) { lastError = e.javaClass.simpleName + ": " + (e.message ?: "") }
            finally { data.recycle(); reply.recycle() }
        }
        return lastError
    }

    /** layer = región del espacio del juego; display = panel completo; ambos en el espacio ya rotado. */
    private fun setProjection(layer: Rect, display: Rect, rot: Int) {
        val token = projToken ?: throw IllegalStateException("sin token")
        val txCls = Class.forName("android.view.SurfaceControl\$Transaction")
        val tx = txCls.getConstructor().newInstance()
        txCls.getMethod("setDisplayProjection", IBinder::class.java, Int::class.javaPrimitiveType, Rect::class.java, Rect::class.java)
            .invoke(tx, token, rot, layer, display)
        txCls.getMethod("apply").invoke(tx)
    }

    private fun isLandscapeRot(natPortrait: Boolean, rot: Int) = if (natPortrait) rot % 2 == 1 else rot % 2 == 0

    private fun rawRestore(rot: Int) {
        stopRemap()
        val (pw, ph) = physicalSize() ?: return
        val l = maxOf(pw, ph)
        val sd = minOf(pw, ph)
        val (w, h) = if (isLandscapeRot(pw < ph, rot)) l to sd else sd to l
        if (sfToken() == "ok") setProjection(Rect(0, 0, w, h), Rect(0, 0, w, h), rot)
    }

    /** Rectángulo (en el espacio horizontal ya rotado) donde el sistema dibuja el juego dentro del panel, si se puede leer. */
    private fun viewportFrame(l: Int, s: Int): IntArray? {
        val out = sh("dumpsys display 2>&1 | grep -m3 'DisplayViewport{type=INTERNAL'").second
        val m = Regex("physicalFrame=Rect\\((\\d+), (\\d+) - (\\d+), (\\d+)\\)").find(out) ?: return null
        val f = intArrayOf(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt(), m.groupValues[4].toInt())
        return if (f[2] - f[0] == l && f[3] > f[1] && f[3] <= s) f else null
    }

    private fun failRestore(rot: Int) {
        sh("wm size reset")
        wmOn = false
        lastWmArg = ""
        try { rawRestore(rot) } catch (_: Throwable) { stopRemap() }
    }

    /**
     * Aplica una geometría al panel completo usando wm size + proyección SurfaceFlinger + remapeo táctil.
     * style=0 estira toda la imagen; style=1 recorta los laterales para conservar las proporciones.
     */
    override fun projectStretch(target: Int, rotation: Int, style: Int): String {
        val rot = rotation and 3
        return try {
            val (pw, ph) = physicalSize() ?: return "error: tamaño físico no leído"
            val l = maxOf(pw, ph)
            val s = minOf(pw, ph)
            val natp = pw < ph
            if (!isLandscapeRot(natp, rot)) return "error: la pantalla no está en horizontal"
            val t = target.coerceIn(l, l * 2)
            val tk = sfToken()
            if (tk != "ok") return "error: $tk"
            lastBeat = System.currentTimeMillis()
            val arg = if (natp) "${pw}x$t" else "${t}x$ph"
            if (!wmOn || arg != lastWmArg) {
                val (code, out) = sh("wm size $arg 2>&1")
                if (code != 0) return "error: wm size: $out"
                wmOn = true
                lastWmArg = arg
                Thread.sleep(600) // el sistema recalcula la pantalla lógica
            }
            val mode = style.coerceIn(0, 1)
            val layer: Rect
            val xStartPpm: Int
            val xEndPpm: Int
            var top = 0
            var bottom = s
            if (mode == 1) {
                // Center crop: preserve the source aspect ratio and clip equal amounts at both sides.
                val left = (t - l) / 2
                layer = Rect(left, 0, left + l, s)
                xStartPpm = ((left.toLong() * 1_000_000L) / t).toInt()
                xEndPpm = (((left + l).toLong() * 1_000_000L) / t).toInt()
            } else {
                // Full stretch: map the full logical surface to the physical panel.
                layer = Rect(0, 0, t, s)
                xStartPpm = 0
                xEndPpm = 1_000_000
                top = (s - (s.toLong() * l / t).toInt()) / 2
                bottom = s - top
                viewportFrame(l, s)?.let { top = it[1]; bottom = it[3] }
            }
            setProjection(layer, Rect(0, 0, l, s), rot)
            val r = startRemap(rot, natp, xStartPpm, xEndPpm, top, bottom, s)
            if (r != "ok") {
                failRestore(rot)
                return "error: táctil: $r"
            }
            projActive = true
            lastRot = rot
            "ok"
        } catch (e: Throwable) {
            failRestore(rot)
            "error: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    override fun projectRestore(rotation: Int): String {
        if (!projActive) return "ok"
        return try {
            rawRestore(rotation and 3)
            projActive = false
            "ok"
        } catch (e: Throwable) {
            projActive = false
            "error: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    private fun helperPath(): String? = baseCtx?.applicationInfo?.nativeLibraryDir?.let { "$it/libtouchremap.so" }

    /** Primer dispositivo con ABS_MT_POSITION_X e INPUT_PROP_DIRECT (el touchscreen). */
    private fun findTouchDev(): String? {
        val script = "for d in /dev/input/event*; do " +
            "if getevent -p \$d 2>/dev/null | grep -q ABS_MT_POSITION_X && " +
            "getevent -p \$d 2>/dev/null | grep -q INPUT_PROP_DIRECT; then echo \$d; break; fi; done"
        return sh(script).second.trim().ifEmpty { null }
    }

    private fun stopRemap() {
        val p = remapProc ?: return
        remapProc = null
        remapKey = ""
        try { p.outputStream.close() } catch (_: Throwable) {}
        try { p.destroy() } catch (_: Throwable) {}
    }

    private fun startRemap(rot: Int, natp: Boolean, xStartPpm: Int, xEndPpm: Int, top: Int, bottom: Int, span: Int): String {
        val yStartPpm = ((top.toLong() * 1_000_000L) / span).toInt()
        val yEndPpm = ((bottom.toLong() * 1_000_000L) / span).toInt()
        val key = "$rot/$natp/$xStartPpm/$xEndPpm/$yStartPpm/$yEndPpm"
        val cur = remapProc
        if (cur != null && cur.isAlive && key == remapKey) return "ok"
        stopRemap()
        val exe = helperPath() ?: return "ruta del helper no encontrada"
        if (!java.io.File(exe).exists()) return "helper no incluido en el APK (libtouchremap.so)"
        val dev = findTouchDev() ?: return "touchscreen no encontrado"
        return try {
            val p = ProcessBuilder(exe, dev, rot.toString(), if (natp) "1" else "0", xStartPpm.toString(), xEndPpm.toString(), yStartPpm.toString(), yEndPpm.toString())
                .redirectErrorStream(true).start()
            val log = StringBuilder()
            Thread({ try { p.inputStream.bufferedReader().forEachLine { log.append(it).append('\n') } } catch (_: Throwable) {} }, "remap-log")
                .apply { isDaemon = true }.start()
            Thread.sleep(400)
            if (!p.isAlive) "el helper terminó (${p.exitValue()}): ${log.toString().trim()}" else {
                remapProc = p
                remapKey = key
                "ok"
            }
        } catch (e: Throwable) {
            "${e.javaClass.simpleName}: ${e.message}"
        }
    }

    override fun startEmergency(): String {
        if (started) return "ok"
        started = true
        // Perro guardián
        Thread({
            while (true) {
                try { Thread.sleep(2000) } catch (_: InterruptedException) { return@Thread }
                if (overridden && System.currentTimeMillis() - lastBeat > WATCHDOG_MS) restoreNow()
            }
        }, "horizon-watchdog").apply { isDaemon = true }.start()
        // Volumen + (getevent no agarra dispositivos)
        Thread({
            try {
                val p = ProcessBuilder("sh", "-c", "getevent -l 2>&1").redirectErrorStream(true).start()
                p.inputStream.bufferedReader().forEachLine { line ->
                    if (line.contains("KEY_VOLUMEUP") && line.contains("DOWN")) {
                        val now = System.currentTimeMillis()
                        if (now - lastEmergency > 1500) {
                            lastEmergency = now
                            restoreNow()
                            emergencyFlag = true
                        }
                    }
                }
            } catch (_: Throwable) {
            }
        }, "horizon-emergency").apply { isDaemon = true }.start()
        return "ok"
    }

    override fun probe(): String {
        val sb = StringBuilder()
        fun add(t: String, s: String) { sb.append("## ").append(t).append('\n').append(s.trim().take(900)).append("\n\n") }
        add("shell", sh("id").second)
        add("android", sh("getprop ro.build.version.release; getprop ro.build.version.sdk; getprop ro.product.manufacturer; getprop ro.product.model").second)
        add("wm", sh("wm size 2>&1; wm density 2>&1").second)
        add("rotación", sh("dumpsys window 2>&1 | grep -m3 -E 'mCurrentRotation|mRotation='").second)
        add("uinput", sh("ls -l /dev/uinput /dev/input/uinput 2>&1").second)
        add("táctil", (findTouchDev() ?: "no encontrado"))
        add("helper", helperPath().let { h -> if (h == null) "sin ruta" else sh("ls -l $h 2>&1").second })
        add("token SurfaceFlinger", try { val t = sfToken(); if (t == "ok") "ok" else "FALLA: $t" } catch (e: Throwable) { "FALLA: ${e.javaClass.simpleName}: ${e.message}" })
        add("setDisplayProjection", try {
            Class.forName("android.view.SurfaceControl\$Transaction").declaredMethods.filter { it.name == "setDisplayProjection" }
                .joinToString("\n") { m -> m.name + m.parameterTypes.joinToString(",", "(", ")") { it.simpleName } }.ifEmpty { "(no existe)" }
        } catch (e: Throwable) { "FALLA: ${e.javaClass.simpleName}" })
        add("estado", "wm=$wmOn proyeccion=$projActive rot=$lastRot helper=${helperPath()}")
        return sb.toString()
    }

    override fun destroy() {
        restoreNow()
        System.exit(0)
    }
}
