package com.simplehorizon.app

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

/** Estilo compartido: negro y blanco, tarjetas con borde fino. */
object Ui {
    val BG = 0xFF000000.toInt()
    val CARD = 0xFF101010.toInt()
    val CHIP = 0xFF1E1E1E.toInt()
    val LINE = 0xFF2C2C2C.toInt()
    val ACCENT = 0xFFFFFFFF.toInt()
    val TXT = 0xFFFFFFFF.toInt()
    val MUTED = 0xFF8E8E8E.toInt()

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun round(c: Context, color: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(c, r).toFloat()
        if (stroke != 0) setStroke(dp(c, 1).coerceAtLeast(1), stroke)
    }

    fun text(c: Context, t: String, size: Float, color: Int = TXT, bold: Boolean = false) = TextView(c).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    fun card(c: Context) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
        background = round(c, CARD, 18, LINE)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { setMargins(dp(c, 12), dp(c, 6), dp(c, 12), dp(c, 6)) }
    }

    fun button(c: Context, t: String, primary: Boolean, onClick: () -> Unit) = TextView(c).apply {
        text = t
        textSize = 14f
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (primary) BG else TXT)
        background = round(c, if (primary) ACCENT else CHIP, 14)
        setPadding(dp(c, 12), dp(c, 13), dp(c, 12), dp(c, 13))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { setMargins(0, dp(c, 8), 0, 0) }
        setOnClickListener { onClick() }
    }

    fun chip(c: Context, t: String, selected: Boolean, padV: Int = 10, size: Float = 13f, onClick: () -> Unit) = TextView(c).apply {
        text = t
        textSize = size
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(c, 4), dp(c, padV), dp(c, 4), dp(c, padV))
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            .apply { setMargins(dp(c, 3), dp(c, 6), dp(c, 3), 0) }
        paintChip(c, this, selected)
        setOnClickListener { onClick() }
    }

    fun paintChip(c: Context, tv: TextView, selected: Boolean) {
        tv.setTextColor(if (selected) BG else TXT)
        tv.background = round(c, if (selected) ACCENT else CHIP, 12)
    }
}
