package com.simplehorizon.app

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale
import kotlin.math.abs

/**
 * Servicio en primer plano: vigila el juego y la orientación, aplica el estiramiento solo en horizontal
 * dentro de Blood Strike y muestra el menú flotante (burbuja + panel) para ajustarlo en tiempo real.
 */
class BubbleService : Service(), StretchBus.Listener {

    companion object {
        @Volatile var running = false
        private const val CHANNEL = "horizon_activo"
        private const val NOTIF_ID = 4242
        private const val ACTION_STOP = "com.simplehorizon.app.STOP"
        private const val WINDOW_MS = 600_000L
        private const val TICK_MS = 1000L
        private const val BUBBLE_DP = 52
        private const val PANEL_W_DP = 300
        private const val FADE_MS = 2500L
        private const val PANEL_IDLE_MS = 8000L

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, BubbleService::class.java))
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val prefs by lazy { Cfg.prefs(this) }
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var bubbleBg: GradientDrawable? = null
    private var bl: WindowManager.LayoutParams? = null
    private var panel: LinearLayout? = null
    private var pl: WindowManager.LayoutParams? = null
    private var readoutTxt: TextView? = null
    private var subTxt: TextView? = null
    private var stateBtn: TextView? = null
    private var methodBtn: TextView? = null
    private var styleBtn: TextView? = null
    private var seek: SeekBar? = null
    private var inGame = false
    private var panelOpen = false
    private var lastW = 0
    private var lastH = 0
    private var anim: ValueAnimator? = null

    private val collapse = Runnable { setPanel(false) }
    private val fade = Runnable { bubble?.animate()?.alpha(0.55f)?.setDuration(300)?.start() }
    private val tick = object : Runnable {
        override fun run() {
            watch()
            heartbeat()
            sync()
            updateBubble()
            ensureAttached()
            checkScreen()
            main.postDelayed(this, TICK_MS)
        }
    }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels
    private fun target() = Cfg.target(prefs)
    private fun on() = Cfg.on(prefs)

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        startForegroundCompat()
        StretchBus.add(this)
        try {
            addViews()
        } catch (_: Throwable) {
            shutdown()
            return
        }
        main.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) shutdown()
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        anim?.cancel()
        StretchBus.remove(this)
        removeViews()
        Stretcher.release(this)
        super.onDestroy()
    }

    override fun onStretchChanged() {
        updateLabels()
        sync()
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    // ---------- Lógica: solo en el juego, solo en horizontal ----------
    private var ticks = 0

    private fun sync() {
        if (Cfg.nl(prefs) == 0) return
        val proj = Cfg.proj(prefs)
        if (WmController.projMode != proj) {
            // Cambio de método: restaura el anterior y vuelve a aplicar con el nuevo
            WmController.restoreNow(Cfg.rotation(this))
            WmController.projMode = proj
        }
        WmController.projStyle = Cfg.stretchStyle(prefs)
        val want = if (on() && inGame && landscape()) target() else 0
        WmController.apply(want, Cfg.rotation(this))
        // La proyección se pierde si el sistema redibuja la pantalla: se reafirma cada 3 s
        if (want > 0 && proj && ++ticks % 3 == 0) WmController.reassert()
    }

    @Suppress("DEPRECATION")
    private fun landscape(): Boolean {
        val d = getSystemService(DisplayManager::class.java)?.getDisplay(Display.DEFAULT_DISPLAY) ?: return false
        val p = Point()
        d.getRealSize(p)
        return p.x > p.y
    }

    private fun heartbeat() {
        if (!WmController.alive()) {
            WmController.reconnectAsync(this)
            return
        }
        WmController.beat { r ->
            if (!running) return@beat
            when {
                r == 2 -> { // Volumen +: el servicio ya restauró; se pausa para no volver a estirar
                    prefs.edit().putBoolean("on", false).apply()
                    WmController.markRestored()
                    StretchBus.notifyChanged()
                }
                r == 0 && WmController.applied > 0 -> WmController.markUnknown()
            }
        }
    }

    private fun watch() {
        val pkg = lastForegroundPkg() ?: return
        if (pkg == packageName) return
        inGame = pkg == Game.PKG
    }

    @Suppress("DEPRECATION")
    private fun lastForegroundPkg(): String? {
        val usm = getSystemService(UsageStatsManager::class.java) ?: return null
        val now = System.currentTimeMillis()
        val events = try { usm.queryEvents(now - WINDOW_MS, now) } catch (_: Throwable) { return null }
        val e = UsageEvents.Event()
        var last: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last = e.packageName
        }
        return last
    }

    private fun updateBubble() {
        val show = inGame && prefs.getBoolean("bubble", true)
        bubble?.visibility = if (show) View.VISIBLE else View.GONE
        if (!show && panelOpen) setPanel(false)
    }

    /** Si el sistema quitó alguna ventana, la vuelve a añadir para que el control no desaparezca. */
    private fun ensureAttached() {
        val b = bubble
        val p = bl
        if (b != null && p != null && !b.isAttachedToWindow) {
            try { wm.addView(b, p) } catch (_: Throwable) {}
        }
        val pn = panel
        val q = pl
        if (pn != null && q != null && !pn.isAttachedToWindow) {
            try { wm.addView(pn, q) } catch (_: Throwable) {}
        }
    }

    /** Al cambiar el tamaño/orientación de la pantalla, pega de nuevo el control al borde. */
    private fun checkScreen() {
        val w = screenW()
        val h = screenH()
        if (w != lastW || h != lastH) {
            lastW = w
            lastH = h
            if (bl != null) snap()
        }
    }

    // ---------- Servicio en primer plano ----------
    private fun createChannel() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "Estiramiento activo", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun startForegroundCompat() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, BubbleService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Cfg.nl(prefs)
        val txt = if (n == 0) "Esperando el panel…" else
            "${target()} × ${Cfg.ns(prefs)} · +" + String.format(Locale.US, "%.1f", Stretch.pct(target(), n)) +
                "% · " + if (on()) "activo" else "pausado"
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("SimpleHorizon")
            .setContentText(txt)
            .setContentIntent(open)
            .addAction(0, "Restaurar y salir", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun shutdown() {
        removeViews()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun removeViews() {
        anim?.cancel()
        listOfNotNull(bubble, panel).forEach { v ->
            try { wm.removeView(v) } catch (_: Throwable) {}
        }
        bubble = null
        panel = null
    }

    // ---------- Vistas ----------
    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    )

    private fun chipRow(vararg items: Pair<String, () -> Unit>): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((t, f) in items) r.addView(Ui.chip(this, t, false, 8, 12f) { f(); scheduleCollapse() })
        return r
    }

    private fun bump(d: Int) {
        if (Cfg.nl(prefs) == 0) return
        Cfg.setTarget(prefs, target() + d)
        StretchBus.notifyChanged()
    }

    private fun pct(p: Int) {
        val n = Cfg.nl(prefs)
        if (n == 0) return
        Cfg.setTarget(prefs, n + n * p / 100)
        StretchBus.notifyChanged()
    }

    private fun addViews() {
        val size = dp(BUBBLE_DP)
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Ui.ACCENT)
            setStroke(dp(2), 0x66000000)
        }
        bubbleBg = bg
        val b = TextView(this).apply {
            text = "↔"
            textSize = 22f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Ui.BG)
            background = bg
            elevation = dp(8).toFloat()
        }
        val bLp = lp(size, size).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenW() - size - dp(6)
            y = dp(120)
        }
        b.setOnTouchListener(dragListener(b, bLp))
        wm.addView(b, bLp)
        bubble = b
        bl = bLp

        val rt = Ui.text(this, "", 24f, Ui.TXT, true)
        readoutTxt = rt
        val st = Ui.text(this, "", 11f, Ui.MUTED)
        subTxt = st

        val sb = SeekBar(this).apply {
            max = 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, pr: Int, fromUser: Boolean) {
                    val n = Cfg.nl(prefs)
                    if (fromUser && n > 0) readoutTxt?.text = "${Stretch.clamp(n + pr, n)} × ${Cfg.ns(prefs)}"
                }
                override fun onStartTrackingTouch(s: SeekBar?) { scheduleCollapse() }
                // Se aplica al soltar: cambiar la pantalla mientras se arrastra mueve el dedo respecto al control
                override fun onStopTrackingTouch(s: SeekBar?) {
                    val n = Cfg.nl(prefs)
                    if (n > 0) { Cfg.setTarget(prefs, n + (s?.progress ?: 0)); StretchBus.notifyChanged() }
                    scheduleCollapse()
                }
            })
        }
        seek = sb

        val method = Ui.chip(this, "", false, 9, 12f) {
            val enableProjection = !Cfg.proj(prefs)
            prefs.edit().putBoolean("proj", enableProjection)
                .apply { if (!enableProjection && Cfg.stretchStyle(prefs) == 1) putInt("stretchStyle", 0) }
                .apply()
            StretchBus.notifyChanged()
            scheduleCollapse()
        }
        method.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { setMargins(dp(3), dp(6), dp(3), 0) }
        methodBtn = method
        val style = Ui.chip(this, "", false, 9, 12f) {
            val cropMode = Cfg.stretchStyle(prefs) == 0
            prefs.edit().putInt("stretchStyle", if (cropMode) 1 else 0)
                .apply { if (cropMode) putBoolean("proj", true) }
                .apply()
            StretchBus.notifyChanged()
            scheduleCollapse()
        }
        style.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { setMargins(dp(3), dp(6), dp(3), 0) }
        styleBtn = style
        val state = Ui.chip(this, "", false, 9, 13f) { toggleOn(); scheduleCollapse() }
        state.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { setMargins(dp(3), dp(8), dp(3), 0) }
        stateBtn = state

        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(10))
            background = Ui.round(this@BubbleService, Ui.CARD, 18, Ui.LINE)
            elevation = dp(10).toFloat()
            visibility = View.GONE
            setOnTouchListener { _, _ -> scheduleCollapse(); false }
            addView(rt)
            addView(st)
            addView(sb)
            addView(chipRow("−50" to { bump(-50) }, "−10" to { bump(-10) }, "−1" to { bump(-1) },
                "+1" to { bump(1) }, "+10" to { bump(10) }, "+50" to { bump(50) }))
            addView(chipRow("+5%" to { pct(5) }, "+10%" to { pct(10) }, "+14%" to { pct(14) },
                "+20%" to { pct(20) }, "+30%" to { pct(30) }))
            addView(method)
            addView(style)
            addView(state)
            addView(chipRow("Ocultar" to { setPanel(false) }, "Salir" to { shutdown() }))
        }
        val plp = lp(dp(PANEL_W_DP), ViewGroup.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(p, plp)
        panel = p
        pl = plp
        updateLabels()
        scheduleFade()
    }

    private fun dragListener(v: View, p: WindowManager.LayoutParams): View.OnTouchListener {
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        return View.OnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    anim?.cancel()
                    sx = p.x
                    sy = p.y
                    tx = e.rawX
                    ty = e.rawY
                    moved = false
                    v.alpha = 1f
                    main.removeCallbacks(fade)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (!moved && abs(dx) + abs(dy) > dp(6)) moved = true
                    if (moved) {
                        p.x = (sx + dx).coerceIn(0, (screenW() - dp(BUBBLE_DP)).coerceAtLeast(0))
                        p.y = (sy + dy).coerceIn(0, (screenH() - dp(BUBBLE_DP)).coerceAtLeast(0))
                        try { wm.updateViewLayout(v, p) } catch (_: Throwable) {}
                        placePanel()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) snap() else { setPanel(!panelOpen); scheduleFade() }
                }
                MotionEvent.ACTION_CANCEL -> if (moved) snap()
            }
            true
        }
    }

    /** Pega el control al borde más cercano con una animación corta. */
    private fun snap() {
        val p = bl ?: return
        val b = bubble ?: return
        val size = dp(BUBBLE_DP)
        val margin = dp(6)
        p.y = p.y.coerceIn(0, (screenH() - size).coerceAtLeast(0))
        val target = if (p.x + size / 2 < screenW() / 2) margin else (screenW() - size - margin).coerceAtLeast(0)
        anim?.cancel()
        anim = ValueAnimator.ofInt(p.x, target).apply {
            duration = 180
            addUpdateListener {
                p.x = it.animatedValue as Int
                try { wm.updateViewLayout(b, p) } catch (_: Throwable) {}
                placePanel()
            }
            start()
        }
        placePanel()
        scheduleFade()
    }

    /** Coloca el panel junto al control, del mismo lado y sin salirse de la pantalla. */
    private fun placePanel() {
        val pn = panel ?: return
        val p = pl ?: return
        val b = bl ?: return
        val size = dp(BUBBLE_DP)
        val pw = dp(PANEL_W_DP)
        val margin = dp(6)
        val ph = if (pn.height > 0) pn.height else dp(290)
        val onRight = b.x + size / 2 > screenW() / 2
        p.x = if (onRight) (b.x + size - pw).coerceAtLeast(margin) else b.x.coerceAtMost((screenW() - pw - margin).coerceAtLeast(margin))
        var y = b.y + size + dp(8)
        if (y + ph > screenH() - dp(8)) y = b.y - ph - dp(8)
        p.y = y.coerceIn(dp(8), (screenH() - ph - dp(8)).coerceAtLeast(dp(8)))
        if (pn.isAttachedToWindow) try { wm.updateViewLayout(pn, p) } catch (_: Throwable) {}
    }

    private fun setPanel(open: Boolean) {
        panelOpen = open
        val pn = panel ?: return
        if (open) {
            updateLabels()
            placePanel()
            pn.visibility = View.VISIBLE
            pn.post { placePanel() }
            scheduleCollapse()
        } else {
            pn.visibility = View.GONE
            main.removeCallbacks(collapse)
            scheduleFade()
        }
    }

    private fun scheduleCollapse() {
        main.removeCallbacks(collapse)
        if (panelOpen) main.postDelayed(collapse, PANEL_IDLE_MS)
    }

    private fun scheduleFade() {
        bubble?.alpha = 1f
        main.removeCallbacks(fade)
        main.postDelayed(fade, FADE_MS)
    }

    private fun toggleOn() {
        prefs.edit().putBoolean("on", !on()).apply()
        StretchBus.notifyChanged()
    }

    private fun updateLabels() {
        val n = Cfg.nl(prefs)
        val t = target()
        readoutTxt?.text = if (n == 0) "—" else "$t × ${Cfg.ns(prefs)}"
        subTxt?.text = if (n == 0) "Panel no detectado" else
            "Panel $n × ${Cfg.ns(prefs)} · +" + String.format(Locale.US, "%.1f", Stretch.pct(t, n)) + "% · " + (if (Cfg.proj(prefs)) "proyección" else "wm size") + (if (Cfg.stretchStyle(prefs) == 0) " · estirar" else " · recorte")
        seek?.let { s ->
            if (n > 0) { s.max = n; s.progress = (t - n).coerceIn(0, n) }
        }
        methodBtn?.let { it.text = if (Cfg.proj(prefs)) "Método: proyección + táctil" else "Método: wm size"; Ui.paintChip(this, it, false) }
        styleBtn?.let {
            it.text = if (Cfg.stretchStyle(prefs) == 0) "Modo: estirar todo" else "Modo: recorte lateral"
            Ui.paintChip(this, it, false)
        }
        stateBtn?.let { it.text = if (on()) "ACTIVO" else "PAUSADO"; Ui.paintChip(this, it, on()) }
        bubbleBg?.setColor(if (on()) Ui.ACCENT else 0xFF6E6E6E.toInt())
    }
}
