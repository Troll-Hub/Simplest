package com.simplehorizon.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast

/** Arranque y liberación: permisos → Shizuku → control flotante → juego. */
object Stretcher {
    private const val KEY_APPLIED = "applied"

    fun start(act: Activity) {
        if (!Permisos.listo(act)) return
        if (!Permisos.instalado(act)) {
            Toast.makeText(act, "${Game.NAME} no está instalado", Toast.LENGTH_LONG).show()
            return
        }
        val app = act.applicationContext
        Thread({
            val ok = WmController.connect(app)
            Handler(Looper.getMainLooper()).post {
                if (!ok) {
                    Toast.makeText(act, "Shizuku no está activo o no tiene permiso", Toast.LENGTH_LONG).show()
                    return@post
                }
                Cfg.prefs(act).edit().putBoolean(KEY_APPLIED, true).putBoolean("on", true).apply()
                BubbleService.start(act)
                StretchBus.notifyChanged()
                try {
                    act.startActivity(Intent().setClassName(Game.PKG, Game.ACTIVITY))
                } catch (_: ActivityNotFoundException) {
                    Toast.makeText(act, "No se pudo abrir ${Game.NAME}", Toast.LENGTH_LONG).show()
                }
            }
        }, "stretch-start").start()
    }

    /** Detiene el servicio; su onDestroy restaura el tamaño original. */
    fun stop(ctx: Context) {
        ctx.stopService(Intent(ctx, BubbleService::class.java))
    }

    fun release(ctx: Context) {
        WmController.shutdown(Cfg.rotation(ctx))
        Cfg.prefs(ctx).edit().putBoolean(KEY_APPLIED, false).apply()
    }

    /** Si la app murió con el estiramiento activo (o se fuerza), restaura el tamaño. */
    fun restore(ctx: Context, force: Boolean = false) {
        if (BubbleService.running) return
        if (!force && !Cfg.prefs(ctx).getBoolean(KEY_APPLIED, false)) return
        val app = ctx.applicationContext
        Thread({
            if (WmController.connect(app)) release(app)
        }, "stretch-restore").start()
    }
}
