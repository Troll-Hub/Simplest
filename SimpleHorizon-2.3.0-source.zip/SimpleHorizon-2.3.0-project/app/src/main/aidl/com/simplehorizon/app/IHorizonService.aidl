package com.simplehorizon.app;

interface IHorizonService {
    void destroy() = 16777114;
    String wm(String arg) = 1;
    int beat() = 2;
    String probe() = 3;
    String startEmergency() = 4;
    String projectStretch(int target, int rotation, int style) = 5;
    String projectRestore(int rotation) = 6;
}
