# Shizuku crea el servicio por nombre de clase en otro proceso: no se puede renombrar ni eliminar
-keep class com.simplehorizon.app.HorizonService { *; }
-keep class com.simplehorizon.app.IHorizonService { *; }
-keep class com.simplehorizon.app.IHorizonService$Stub { *; }
-keep class com.simplehorizon.app.IHorizonService$Stub$Proxy { *; }
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }
-dontwarn rikka.**
-dontwarn moe.shizuku.**
-dontwarn android.**
