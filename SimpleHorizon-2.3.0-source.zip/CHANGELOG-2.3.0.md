# SimpleHorizon 2.3.0

## Funciones integradas

- **Estirar toda la imagen:** conserva la proyección existente a pantalla completa.
- **Recorte lateral:** usa un recorte centrado para conservar la proporción de la imagen en lugar de deformarla horizontalmente.
- **Táctil adaptado al modo:** la región táctil se ajusta en Y para estiramiento completo y en X para recorte lateral.
- **Selección desde la app y el menú flotante.** El modo de recorte habilita automáticamente la proyección SurfaceFlinger; si se deshabilita esa proyección, el modo vuelve a estiramiento completo.
- **Resolución de token SurfaceFlinger más tolerante:** intenta métodos de token de SurfaceControl disponibles y conserva la vía heredada como alternativa.
- **Contrato Shizuku actualizado** para transmitir el modo de geometría.

## Validación realizada

- `touchremap.c` pasó comprobación de sintaxis con GCC usando `-Wall -Wextra -Werror`.
- Se comprobaron estáticamente los puntos de integración AIDL, Kotlin y UI.
- No se generó el APK en este entorno porque no hay instalación de Gradle ni Android SDK disponible aquí. El proyecto conserva el workflow de GitHub Actions para producir el APK.

## Nota de seguridad

La proyección y el controlador de entrada usan permisos de Shizuku. Prueba primero con un valor de estiramiento moderado y mantén disponible la acción de restaurar pantalla. El remapeo táctil es experimental y puede variar según el dispositivo y el juego.
