package com.stretchlab.app

data class ResPreset(
    val id: String,
    val title: String,
    val desc: String,
    /** null = reset a nativo */
    val width: Int?,
    val height: Int?,
)

object Presets {
    /**
     * Presets inspirados en el uso competitivo de stretch en PC:
     * reducir el ancho lógico estira la imagen en pantallas anchas (más FOV vertical percibido / sensación de velocidad).
     * Los valores se calculan al vuelo según el tamaño físico del panel.
     */
    fun forPanel(physW: Int, physH: Int): List<ResPreset> {
        if (physW <= 0 || physH <= 0) return listOf(native())
        val h = physH
        fun wFor(ratioW: Float, ratioH: Float): Int {
            // ancho objetivo para que height quede fijo y el aspect sea ratioW:ratioH
            return (h * ratioW / ratioH).toInt().coerceAtLeast(720)
        }
        return listOf(
            native(),
            ResPreset("169", "16:9 clásico", "Estirado moderado en paneles 20:9 / 21:9", wFor(16f, 9f), h),
            ResPreset("1610", "16:10", "Un poco menos agresivo", wFor(16f, 10f), h),
            ResPreset("43", "4:3 fuerte", "Estilo competitive PC muy estirado", wFor(4f, 3f), h),
            ResPreset("32", "3:2", "Intermedio", wFor(3f, 2f), h),
            ResPreset("custom", "Personalizado", "Elige ancho y alto abajo", null, null),
        )
    }

    fun native() = ResPreset("native", "Nativo (restaurar)", "Vuelve al tamaño de fábrica del panel", null, null)
}

data class DisplayInfo(
    val physicalWidth: Int,
    val physicalHeight: Int,
    val densityDpi: Int,
    val currentSize: String,
)
