package com.stretchlab.app

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.TypedValue
import android.view.*
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat

/**
 * Painel flutuante ao estilo "Controle Tela Esticada":
 * cabeçalho, status, 2 presets, APLICAR / RESTAURAR.
 * Código aberto — implementación propia.
 */
class SafetyService : Service() {
    private var windowManager: WindowManager? = null
    private var panel: View? = null
    private var bubbleVisible = true
    private val main = Handler(Looper.getMainLooper())
    private var applying = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF_ID, buildNotification())
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Store(this).showBubble) showPanel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE_BUBBLE -> if (bubbleVisible) hidePanel() else showPanel()
            ACTION_REFRESH_PANEL -> { hidePanel(); showPanel() }
            ACTION_STOP -> stopSelf()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        hidePanel()
        if (Store(this).sessionActive) {
            SafetyActions.emergencyRestore(applicationContext, "service-destroy")
        }
        super.onDestroy()
    }

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private fun roundedBg(color: Int, radiusDp: Float = 12f): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp.toInt()).toFloat()
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(): Notification {
        val restore = PendingIntent.getBroadcast(
            this, 1,
            Intent(this, RestoreReceiver::class.java).setAction(RestoreReceiver.ACTION_EMERGENCY_RESTORE),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_revert)
            .setContentTitle("Tela Esticada ativa")
            .setContentText("Vol + restaura · toque APLICAR no flutuante")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "RESTAURAR TELA", restore)
            .build()
    }

    private fun makeBtn(text: String, bg: Int, weight: Float = 1f, onClick: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            background = roundedBg(bg, 10f)
            textSize = 11f
            isAllCaps = true
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8), dp(10), dp(8), dp(10))
            setOnClickListener { onClick() }
            minimumHeight = dp(40)
            stateListAnimator = null
        }
    }

    private fun showPanel() {
        if (panel != null) return
        if (Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.canDrawOverlays(this)) return

        val store = Store(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = roundedBg(0xF0141418.toInt(), 16f)
            elevation = dp(10).toFloat()
        }

        // Header row
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "Controle Tela Esticada"
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val close = TextView(this).apply {
            text = "—"
            setTextColor(0xFF9E9E9E.toInt())
            textSize = 16f
            setPadding(dp(8), 0, 0, 0)
            setOnClickListener { hidePanel() }
        }
        header.addView(title)
        header.addView(close)
        root.addView(header)

        val status = TextView(this).apply {
            text = statusLine()
            setTextColor(0xFFB0B0B0.toInt())
            textSize = 10f
            setPadding(0, dp(4), 0, dp(8))
        }
        root.addView(status)

        // Divider
        root.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).apply {
                bottomMargin = dp(8)
            }
            setBackgroundColor(0x33FFFFFF)
        })

        // Presets row
        val labelP = TextView(this).apply {
            text = "Presets do flutuante"
            setTextColor(0xFF9E9E9E.toInt())
            textSize = 10f
            setPadding(0, 0, 0, dp(6))
        }
        root.addView(labelP)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val p1 = store.floatPreset1
        val p2 = store.floatPreset2
        fun chip(label: String, w: Int, h: Int) {
            val b = makeBtn(label, 0xFF2A2A32.toInt()) {
                safeApplySize(w, h, status)
            }
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.marginEnd = dp(6)
            row.addView(b, lp)
        }
        if (p1.w > 0) chip(p1.label, p1.w, p1.h)
        if (p2.w > 0) chip(p2.label, p2.w, p2.h)
        root.addView(row)

        // Main actions
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, 0)
        }
        val apply = makeBtn("APLICAR", 0xFFE53935.toInt()) {
            val w = store.appliedW.takeIf { it > 0 } ?: store.customW
            val h = store.appliedH.takeIf { it > 0 } ?: store.customH
            safeApplySize(w, h, status)
        }
        val rest = makeBtn("RESTAURAR", 0xFF3A3A42.toInt()) {
            SafetyActions.emergencyRestore(applicationContext, "float-panel")
            status.text = "Nativo · tela restaurada"
        }
        val lpA = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6) }
        actions.addView(apply, lpA)
        actions.addView(rest, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(actions)

        val hint = TextView(this).apply {
            text = "Vol + restaura · Vol − oculta · open-source"
            setTextColor(0xFF6E6E6E.toInt())
            textSize = 9f
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(hint)

        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            dp(280),
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.END
        params.x = dp(12)
        params.y = dp(160)

        root.setOnTouchListener(dragListener(params, root))
        try {
            windowManager?.addView(root, params)
            panel = root
            bubbleVisible = true
        } catch (_: Exception) {
        }
    }

    private fun statusLine(): String = try {
        if (Shell.state() == Shell.State.READY) Shell.readSize().replace("\n", " · ")
        else "Shizuku não pronto"
    } catch (_: Exception) { "—" }

    private fun safeApplySize(w: Int, h: Int, statusView: TextView) {
        if (applying) {
            Toast.makeText(this, "Aguarde…", Toast.LENGTH_SHORT).show()
            return
        }
        if (w < 720 || h < 720) {
            Toast.makeText(this, "Resolução inválida", Toast.LENGTH_SHORT).show()
            return
        }
        if (Shell.state() != Shell.State.READY) {
            Toast.makeText(this, "Ative o Shizuku", Toast.LENGTH_SHORT).show()
            return
        }
        applying = true
        statusView.text = "Aplicando ${w}×${h}…"
        Thread {
            val store = Store(this)
            if (store.sessionActive) {
                Shell.resetSize()
                try { Thread.sleep(120) } catch (_: Exception) {}
            }
            val r = Shell.applySize(w, h)
            val ok = r.code == 0
            if (!ok) {
                Shell.resetSize()
                Shell.resetDensity()
                store.sessionActive = false
            } else {
                store.sessionActive = true
                store.appliedW = w
                store.appliedH = h
                store.customW = w
                store.customH = h
            }
            main.post {
                applying = false
                statusView.text = if (ok) statusLine() else "Falhou · restaurado"
                Toast.makeText(
                    this,
                    if (ok) "Tela esticada ${w}×${h}" else "Erro — tela restaurada",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }.start()
    }

    private fun dragListener(params: WindowManager.LayoutParams, view: View) =
        object : View.OnTouchListener {
            private var lx = 0
            private var ly = 0
            private var px = 0
            private var py = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        lx = e.rawX.toInt(); ly = e.rawY.toInt()
                        px = params.x; py = params.y
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = px + (lx - e.rawX.toInt())
                        params.y = py + (e.rawY.toInt() - ly)
                        windowManager?.updateViewLayout(view, params)
                        return true
                    }
                }
                return false
            }
        }

    private fun hidePanel() {
        try { panel?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        panel = null
        bubbleVisible = false
    }

    companion object {
        const val CHANNEL = "stretchlab_session"
        const val NOTIF_ID = 42
        const val ACTION_TOGGLE_BUBBLE = "com.stretchlab.app.TOGGLE_BUBBLE"
        const val ACTION_REFRESH_PANEL = "com.stretchlab.app.REFRESH_PANEL"
        const val ACTION_STOP = "com.stretchlab.app.STOP_SAFETY"
    }
}
