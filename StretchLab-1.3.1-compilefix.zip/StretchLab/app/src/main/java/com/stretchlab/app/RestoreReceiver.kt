package com.stretchlab.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class RestoreReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            ACTION_EMERGENCY_RESTORE -> {
                SafetyActions.emergencyRestore(context.applicationContext, "notification")
            }
            ACTION_TOGGLE_BUBBLE -> {
                context.startService(
                    Intent(context, SafetyService::class.java)
                        .setAction(SafetyService.ACTION_TOGGLE_BUBBLE)
                )
            }
        }
    }

    companion object {
        const val ACTION_EMERGENCY_RESTORE = "com.stretchlab.app.ACTION_EMERGENCY_RESTORE"
        const val ACTION_TOGGLE_BUBBLE = "com.stretchlab.app.ACTION_TOGGLE_BUBBLE"
    }
}
