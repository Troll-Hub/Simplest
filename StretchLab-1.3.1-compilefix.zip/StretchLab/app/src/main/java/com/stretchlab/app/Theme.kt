package com.stretchlab.app

import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color

/** Paleta oscura tipo apps de resolución gaming (rojo / negro / gris). */
object CatStyle {
    val Bg = Color(0xFF0B0B0D)
    val Surface = Color(0xFF16161A)
    val SurfaceSoft = Color(0xFF1E1E24)
    val Primary = Color(0xFFE53935)
    val PrimaryDim = Color(0xFFB71C1C)
    val OnPrimary = Color(0xFFFFFFFF)
    val Text = Color(0xFFF2F2F2)
    val Muted = Color(0xFF9E9E9E)
    val Ok = Color(0xFF66BB6A)
    val Warn = Color(0xFFFFB74D)

    fun colors() = darkColorScheme(
        primary = Primary,
        onPrimary = OnPrimary,
        primaryContainer = PrimaryDim,
        secondary = Color(0xFFEF5350),
        background = Bg,
        surface = Surface,
        surfaceVariant = SurfaceSoft,
        onSurface = Text,
        onSurfaceVariant = Muted,
        error = Color(0xFFEF5350),
    )
}
