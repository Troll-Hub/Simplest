package com.stretchlab.app

import android.content.Context

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("stretchlab", Context.MODE_PRIVATE)

    var lastPresetId: String
        get() = p.getString("preset", "native") ?: "native"
        set(v) { p.edit().putString("preset", v).apply() }

    var customW: Int
        get() = p.getInt("cw", 1080)
        set(v) { p.edit().putInt("cw", v.coerceIn(720, 4096)).apply() }

    var customH: Int
        get() = p.getInt("ch", 1920)
        set(v) { p.edit().putInt("ch", v.coerceIn(720, 4096)).apply() }

    var customDpi: Int
        get() = p.getInt("dpi", 0)
        set(v) { p.edit().putInt("dpi", v.coerceIn(0, 600)).apply() }

    var lastPackage: String
        get() = p.getString("pkg", "") ?: ""
        set(v) { p.edit().putString("pkg", v).apply() }

    /** Sesión Pro: estirado aplicado y aún no restaurado */
    var sessionActive: Boolean
        get() = p.getBoolean("session", false)
        set(v) { p.edit().putBoolean("session", v).apply() }

    var proMode: Boolean
        get() = p.getBoolean("pro", true)
        set(v) { p.edit().putBoolean("pro", v).apply() }

    var volumeEmergency: Boolean
        get() = p.getBoolean("vol_em", true)
        set(v) { p.edit().putBoolean("vol_em", v).apply() }

    var hideBubbleWithVolDown: Boolean
        get() = p.getBoolean("hide_vol_down", true)
        set(v) { p.edit().putBoolean("hide_vol_down", v).apply() }

    var showBubble: Boolean
        get() = p.getBoolean("bubble", true)
        set(v) { p.edit().putBoolean("bubble", v).apply() }

    var requireConfirm: Boolean
        get() = p.getBoolean("confirm", true)
        set(v) { p.edit().putBoolean("confirm", v).apply() }

    /** Última resolución aplicada (para mostrar zonas muertas) */
    var appliedW: Int
        get() = p.getInt("aw", 0)
        set(v) { p.edit().putInt("aw", v).apply() }

    var appliedH: Int
        get() = p.getInt("ah", 0)
        set(v) { p.edit().putInt("ah", v).apply() }

    var panelW: Int
        get() = p.getInt("pw", 0)
        set(v) { p.edit().putInt("pw", v).apply() }

    var panelH: Int
        get() = p.getInt("ph", 0)
        set(v) { p.edit().putInt("ph", v).apply() }

    data class FloatPreset(val label: String, val w: Int, val h: Int)

    /** Presets del menú flotante (como Cat: 2 slots rápidos). */
    var floatPreset1: FloatPreset
        get() = FloatPreset(p.getString("fp1l", "16:9") ?: "16:9", p.getInt("fp1w", 1080), p.getInt("fp1h", 1920))
        set(v) { p.edit().putString("fp1l", v.label).putInt("fp1w", v.w).putInt("fp1h", v.h).apply() }

    var floatPreset2: FloatPreset
        get() = FloatPreset(p.getString("fp2l", "4:3") ?: "4:3", p.getInt("fp2w", 1440), p.getInt("fp2h", 1920))
        set(v) { p.edit().putString("fp2l", v.label).putInt("fp2w", v.w).putInt("fp2h", v.h).apply() }
}

