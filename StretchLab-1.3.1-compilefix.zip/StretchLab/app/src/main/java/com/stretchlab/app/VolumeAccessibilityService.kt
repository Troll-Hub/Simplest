package com.stretchlab.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * Volume + → restauración de emergencia (si hay sesión activa).
 * Volume - → ocultar/mostrar burbuja (opcional).
 */
class VolumeAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return false
        val store = Store(this)
        if (!store.sessionActive) return false

        when (event.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> {
                if (store.volumeEmergency) {
                    SafetyActions.emergencyRestore(applicationContext, "volume+")
                    return true
                }
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                if (store.hideBubbleWithVolDown) {
                    startService(
                        Intent(this, SafetyService::class.java)
                            .setAction(SafetyService.ACTION_TOGGLE_BUBBLE)
                    )
                    return true
                }
            }
        }
        return false
    }
}
