package com.stretchlab.app

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Ejecuta comandos de pantalla vía Shizuku (uid shell), equivalente a:
 *   adb shell wm size WxH
 *   adb shell wm size reset
 *   adb shell wm density N
 *   adb shell wm density reset
 *
 * Misma idea de fondo que apps de resolución en Android; implementación propia.
 */
object Shell {
    enum class State { NOT_RUNNING, NO_PERMISSION, READY, UNSUPPORTED }

    fun state(): State = try {
        when {
            !Shizuku.pingBinder() -> State.NOT_RUNNING
            Shizuku.isPreV11() -> State.UNSUPPORTED
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> State.READY
            else -> State.NO_PERMISSION
        }
    } catch (_: Throwable) {
        State.NOT_RUNNING
    }

    fun requestPermission(code: Int = 4401) {
        try {
            Shizuku.requestPermission(code)
        } catch (_: Throwable) {
        }
    }

    data class Result(val code: Int, val out: String)

    fun exec(command: String): Result {
        return try {
            // API Shizuku: newProcess
            val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
            val out = BufferedReader(InputStreamReader(process.inputStream)).readText().trim()
            val err = BufferedReader(InputStreamReader(process.errorStream)).readText().trim()
            val code = process.waitFor()
            Result(code, listOf(out, err).filter { it.isNotBlank() }.joinToString("\n"))
        } catch (e: Exception) {
            Result(-1, e.message ?: "error")
        }
    }

    fun readSize(): String {
        val r = exec("wm size")
        // Physical size: 1080x2400 Override size: 1080x1920
        return r.out.ifBlank { "desconocido" }
    }

    fun applySize(width: Int, height: Int): Result =
        exec("wm size ${width}x${height}")

    fun resetSize(): Result = exec("wm size reset")

    fun applyDensity(dpi: Int): Result = exec("wm density $dpi")

    fun resetDensity(): Result = exec("wm density reset")
}
