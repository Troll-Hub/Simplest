package com.stretchlab.app

import android.Manifest
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.RocketLaunch
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
            }
        }
        setContent { MaterialTheme(colorScheme = CatStyle.colors()) { App() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val scope = rememberCoroutineScope()
    val dm = ctx.resources.displayMetrics
    val physW = dm.widthPixels.coerceAtLeast(720)
    val physH = dm.heightPixels.coerceAtLeast(1280)
    val presets = remember(physW, physH) { Presets.forPanel(physW, physH) }

    var presetId by remember { mutableStateOf(store.lastPresetId) }
    var customW by remember { mutableIntStateOf(store.customW) }
    var customH by remember { mutableIntStateOf(store.customH) }
    var customDpi by remember { mutableIntStateOf(store.customDpi) }
    var status by remember { mutableStateOf(Shell.state()) }
    var sizeLine by remember { mutableStateOf("—") }
    var busy by remember { mutableStateOf(false) }
    var log by remember { mutableStateOf("") }
    var pkg by remember { mutableStateOf(store.lastPackage) }
    var games by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var session by remember { mutableStateOf(store.sessionActive) }
    var proMode by remember { mutableStateOf(store.proMode) }
    var volEm by remember { mutableStateOf(store.volumeEmergency) }
    var showBubble by remember { mutableStateOf(store.showBubble) }
    var requireConfirm by remember { mutableStateOf(store.requireConfirm) }
    var confirmOpen by remember { mutableStateOf(false) }
    var pendingLaunch by remember { mutableStateOf(false) }

    fun refresh() {
        status = Shell.state()
        session = store.sessionActive
        if (status == Shell.State.READY) sizeLine = Shell.readSize()
    }

    LaunchedEffect(Unit) {
        refresh()
        withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val list = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 }
                .map { it.packageName to pm.getApplicationLabel(it).toString() }
                .sortedBy { it.second.lowercase() }
            withContext(Dispatchers.Main) { games = list }
        }
    }

    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()

    fun targetSize(): Pair<Int, Int>? {
        val preset = presets.firstOrNull { it.id == presetId } ?: return null
        return when {
            preset.id == "native" -> null
            preset.id == "custom" -> customW to customH
            preset.width != null && preset.height != null -> preset.width to preset.height
            else -> null
        }
    }

    fun startSafetySession() {
        if (!proMode) return
        val i = Intent(ctx, SafetyService::class.java)
        ContextCompat.startForegroundService(ctx, i)
    }

    fun doApply(thenLaunch: Boolean) {
        if (status != Shell.State.READY) {
            toast("Activa Shizuku y concede permiso")
            return
        }
        // Seguridad: no apilar sesiones
        if (store.sessionActive && targetSize() != null) {
            toast("Hay una sesión activa. Restaura antes de aplicar otra.")
            return
        }
        busy = true
        scope.launch(Dispatchers.IO) {
            val target = targetSize()
            val result = buildString {
                if (target == null) {
                    appendLine(Shell.resetSize().out.ifBlank { "wm size reset" })
                    appendLine(Shell.resetDensity().out.ifBlank { "wm density reset" })
                    store.sessionActive = false
                    store.appliedW = 0
                    store.appliedH = 0
                } else {
                    val (w, h) = target
                    val r = Shell.applySize(w, h)
                    appendLine("wm size ${w}x${h} → ${r.code} ${r.out}")
                    store.customW = w
                    store.customH = h
                    store.appliedW = w
                    store.appliedH = h
                    store.panelW = physW
                    store.panelH = physH
                    store.sessionActive = true
                    store.lastPresetId = presetId
                    // Actualiza slot flotante 1 con lo último aplicado
                    val label = presets.firstOrNull { it.id == presetId }?.title?.take(8) ?: "${w}x${h}"
                    store.floatPreset1 = Store.FloatPreset(label, w, h)
                    if (customDpi > 0) {
                        val d = Shell.applyDensity(customDpi)
                        appendLine("wm density $customDpi → ${d.code} ${d.out}")
                    }
                }
            }
            withContext(Dispatchers.Main) {
                log = result.trim()
                sizeLine = Shell.readSize()
                session = store.sessionActive
                busy = false
                if (store.sessionActive) {
                    startSafetySession()
                    toast("Estirado aplicado · Vol + restaura")
                } else {
                    toast("Pantalla en nativo")
                    ctx.stopService(Intent(ctx, SafetyService::class.java))
                }
                if (thenLaunch && pkg.isNotBlank()) {
                    store.lastPackage = pkg
                    ctx.packageManager.getLaunchIntentForPackage(pkg)?.let {
                        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        ctx.startActivity(it)
                    } ?: toast("No se pudo abrir el paquete")
                }
            }
        }
    }

    fun requestApply(thenLaunch: Boolean) {
        pendingLaunch = thenLaunch
        val target = targetSize()
        if (target != null && requireConfirm) {
            confirmOpen = true
        } else {
            doApply(thenLaunch)
        }
    }

    val dead = remember(store.appliedW, store.appliedH, session, physW, physH) {
        if (session && store.appliedW > 0) DeadZones.analyze(physW, physH, store.appliedW, store.appliedH)
        else DeadZones.analyze(physW, physH, physW, physH)
    }

    if (confirmOpen) {
        val t = targetSize()
        AlertDialog(
            onDismissRequest = { confirmOpen = false },
            title = { Text("Confirmar alongamento") },
            text = {
                Text(
                    "Será aplicado ${t?.first}×${t?.second}.\n\n" +
                        "Medidas de seguridad:\n" +
                        "• Volume + restaura (con servicio de accesibilidad)\n" +
                        "• Notificación con botón Restaurar\n" +
                        "• Burbuja flotante (si diste permiso de overlay)\n" +
                        "• Si el servicio cae, intenta restaurar solo\n\n" +
                        "Si los toques fallan, Volume + o Restaurar."
                )
            },
            confirmButton = {
                TextButton(onClick = { confirmOpen = false; doApply(pendingLaunch) }) { Text("Aplicar") }
            },
            dismissButton = {
                TextButton(onClick = { confirmOpen = false }) { Text("Cancelar") }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Tela Esticada") },
                actions = {
                    IconButton(onClick = { refresh() }) {
                        Icon(Icons.Rounded.Refresh, contentDescription = "Actualizar")
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Estado sesión
            if (session) {
                ElevatedCard(Modifier.fillMaxWidth(), colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF4A1515))) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Warning, contentDescription = null, tint = Color(0xFFFFAB91))
                            Spacer(Modifier.width(8.dp))
                            Text("Tela Esticada ativa", color = Color(0xFFFFAB91))
                        }
                        Text("Vol + restaura · notificação · flutuante APLICAR / RESTAURAR")
                        Button(
                            onClick = {
                                SafetyActions.emergencyRestore(ctx, "ui")
                                refresh()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("RESTAURAR TELA AGORA") }
                    }
                }
            }

            // Shizuku
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Shizuku", style = MaterialTheme.typography.titleMedium)
                    Text(
                        when (status) {
                            Shell.State.READY -> "Listo"
                            Shell.State.NOT_RUNNING -> "No activo"
                            Shell.State.NO_PERMISSION -> "Sin permiso"
                            Shell.State.UNSUPPORTED -> "No soportado"
                        }
                    )
                    Text("wm size → $sizeLine", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (status == Shell.State.NO_PERMISSION) {
                            Button(onClick = { Shell.requestPermission(); refresh() }) { Text("Conceder") }
                        }
                        OutlinedButton(onClick = { refresh() }) { Text("Revisar") }
                    }
                }
            }

            // Modo Pro / seguridad
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Modo Pro", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Inspirado en utilidades estables de resolución: sesión vigilada, " +
                            "restauración de emergencia y aviso de zonas de toque.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    RowToggle("Sessão Pro ao aplicar", proMode) {
                        proMode = it; store.proMode = it
                    }
                    RowToggle("Volume + restaura a tela", volEm) {
                        volEm = it; store.volumeEmergency = it
                    }
                    RowToggle("Controle flutuante", showBubble) {
                        showBubble = it; store.showBubble = it
                    }
                    RowToggle("Confirmar antes de aplicar", requireConfirm) {
                        requireConfirm = it; store.requireConfirm = it
                    }
                    OutlinedButton(
                        onClick = {
                            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Ativar acessibilidade (Volume +)") }

                    OutlinedButton(
                        onClick = {
                            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(ctx)) {
                                ctx.startActivity(
                                    Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:${ctx.packageName}")
                                    )
                                )
                            } else toast("Permiso de superposición OK")
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Permissão do flutuante (overlay)") }
                }
            }

            // Zonas muertas
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Áreas de toque / faixas", style = MaterialTheme.typography.titleMedium)
                    Text(dead.message, style = MaterialTheme.typography.bodySmall)
                    Canvas(Modifier.fillMaxWidth().height(120.dp)) {
                        val w = size.width
                        val h = size.height
                        // panel
                        drawRect(Color(0xFF222222), size = Size(w, h))
                        val side = if (dead.panelW > 0) dead.sideBarPx.toFloat() / dead.panelW * w else 0f
                        if (side > 0) {
                            drawRect(Color(0xFFB71C1C), topLeft = Offset(0f, 0f), size = Size(side, h))
                            drawRect(Color(0xFFB71C1C), topLeft = Offset(w - side, 0f), size = Size(side, h))
                        }
                        drawRect(
                            Color(0xFF1B5E20),
                            topLeft = Offset(side, 0f),
                            size = Size((w - 2 * side).coerceAtLeast(0f), h)
                        )
                    }
                    Text(
                        "Rojo = posibles bandas / toques raros · Verde = área útil estimada",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Text("Presets de alongamento", style = MaterialTheme.typography.titleMedium)
            presets.forEach { pr ->
                ElevatedCard(
                    Modifier
                        .fillMaxWidth()
                        .selectable(selected = presetId == pr.id, onClick = { presetId = pr.id })
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = presetId == pr.id, onClick = { presetId = pr.id })
                        Column {
                            Text(pr.title, style = MaterialTheme.typography.titleSmall)
                            Text(
                                buildString {
                                    append(pr.desc)
                                    if (pr.width != null) append(" · ${pr.width}×${pr.height}")
                                },
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }

            if (presetId == "custom") {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = customW.toString(),
                            onValueChange = { customW = it.filter(Char::isDigit).toIntOrNull() ?: customW },
                            label = { Text("Ancho") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = customH.toString(),
                            onValueChange = { customH = it.filter(Char::isDigit).toIntOrNull() ?: customH },
                            label = { Text("Alto") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = if (customDpi == 0) "" else customDpi.toString(),
                            onValueChange = {
                                customDpi = it.filter(Char::isDigit).toIntOrNull() ?: 0
                                store.customDpi = customDpi
                            },
                            label = { Text("DPI opcional") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            Text("Juego (opcional)", style = MaterialTheme.typography.titleMedium)
            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                OutlinedTextField(
                    value = games.firstOrNull { it.first == pkg }?.second ?: pkg.ifBlank { "Elegir app" },
                    onValueChange = {},
                    readOnly = true,
                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                    label = { Text("Abrir después") }
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    DropdownMenuItem(text = { Text("(Ninguno)") }, onClick = { pkg = ""; expanded = false })
                    games.take(80).forEach { (p, label) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = { pkg = p; expanded = false })
                    }
                }
            }

            Button(
                onClick = { requestApply(thenLaunch = true) },
                enabled = !busy && status == Shell.State.READY,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Rounded.RocketLaunch, null)
                Spacer(Modifier.width(8.dp))
                Text(if (pkg.isBlank()) "Aplicar alongamento" else "Aplicar e abrir jogo")
            }

            OutlinedButton(
                onClick = {
                    SafetyActions.emergencyRestore(ctx, "button")
                    refresh()
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Rounded.PhoneAndroid, null)
                Spacer(Modifier.width(8.dp))
                Text("Restaurar tela agora")
            }

            if (log.isNotBlank()) {
                Text("Log", style = MaterialTheme.typography.titleSmall)
                Text(log, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun RowToggle(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = value, onCheckedChange = onChange)
    }
}
