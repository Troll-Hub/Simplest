package com.stretchlab.app

import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast

object SafetyActions {
    private const val TAG = "StretchLab"

    /**
     * Restauración de emergencia: siempre intenta wm size/density reset.
     * Se puede llamar desde notificación, Volume+, burbuja o al morir el servicio.
     */
    fun emergencyRestore(ctx: Context, source: String) {
        val store = Store(ctx)
        Log.i(TAG, "emergencyRestore source=$source session=${store.sessionActive}")
        val ok = try {
            if (Shell.state() == Shell.State.READY) {
                Shell.resetSize()
                Shell.resetDensity()
                true
            } else false
        } catch (e: Exception) {
            Log.e(TAG, "restore failed", e)
            false
        }
        store.sessionActive = false
        store.appliedW = 0
        store.appliedH = 0
        try {
            ctx.stopService(Intent(ctx, SafetyService::class.java))
        } catch (_: Exception) {
        }
        try {
            Toast.makeText(
                ctx,
                if (ok) "Pantalla restaurada ($source)" else "No se pudo restaurar: activa Shizuku",
                Toast.LENGTH_LONG
            ).show()
        } catch (_: Exception) {
        }
    }
}
