package com.stretchlab.app

/**
 * Calcula franjas donde el contenido estirado puede dejar
 * barras negras o toques desalineados (referencia visual).
 *
 * Si el buffer lógico es más "estrecho" que el panel (mismo alto, menos ancho),
 * el sistema suele escalar y pueden aparecer bandas o zonas de toque raras a los lados.
 */
data class DeadZoneReport(
    val panelW: Int,
    val panelH: Int,
    val logicalW: Int,
    val logicalH: Int,
    val sideBarPx: Int,
    val topBarPx: Int,
    val message: String,
)

object DeadZones {
    fun analyze(panelW: Int, panelH: Int, logicalW: Int, logicalH: Int): DeadZoneReport {
        if (panelW <= 0 || panelH <= 0 || logicalW <= 0 || logicalH <= 0) {
            return DeadZoneReport(panelW, panelH, logicalW, logicalH, 0, 0, "Sin datos de panel/lógico.")
        }
        val panelRatio = panelW.toFloat() / panelH
        val logRatio = logicalW.toFloat() / logicalH

        // Escala para cubrir alto del panel
        val scale = panelH.toFloat() / logicalH
        val drawnW = (logicalW * scale).toInt()
        val side = ((panelW - drawnW) / 2).coerceAtLeast(0)

        val scaleW = panelW.toFloat() / logicalW
        val drawnH = (logicalH * scaleW).toInt()
        val top = ((panelH - drawnH) / 2).coerceAtLeast(0)

        val msg = buildString {
            append("Panel ${panelW}×${panelH} → lógico ${logicalW}×${logicalH}. ")
            if (side > 0) append("Posibles bandas laterales ~${side}px por lado. ")
            if (top > 0 && side == 0) append("Posibles bandas arriba/abajo ~${top}px. ")
            if (side == 0 && top == 0) append("Escala a pantalla completa (toques suelen alinearse mejor). ")
            append("Si los toques fallan en bordes, usa Restaurar (Vol +).")
        }
        return DeadZoneReport(panelW, panelH, logicalW, logicalH, side, top, msg)
    }
}
