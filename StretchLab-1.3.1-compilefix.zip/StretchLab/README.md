# Tela Esticada (StretchLab)

**Open source (MIT)** — utilitário Android para alongar a resolução do sistema (`wm size` / `wm density`) via Shizuku.

Inspirado no fluxo de apps de resolução (presets, flutuante, emergência), com código próprio.

## Funcionalidades

- Presets 16:9, 16:10, 4:3, 3:2, personalizado
- **Controle flutuante**: presets, APLICAR, RESTAURAR
- Volume + restaura (acessibilidade)
- Notificação persistente com RESTAURAR TELA
- Sessão Pro (não empilha alongamentos; restaura se o serviço cair)
- Mapa de zonas de toque / faixas
- Confirmação antes de aplicar

## Build

```bash
gradle :app:assembleDebug
```

## Licença

MIT — ver `LICENSE`.
