package com.opentrace.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.google.android.material.slider.Slider
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var overlay: TraceOverlayView
    private lateinit var btnLock: Button

    private var camera: Camera? = null
    private var torchOn = false
    private var original: Bitmap? = null
    private var filterMode = FilterMode.ORIGINAL

    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var jobId = 0

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            uri?.let(::loadImage)
        }

    private val askCamera =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else toast(R.string.camera_denied)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        overlay = findViewById(R.id.overlay)
        btnLock = findViewById(R.id.btnLock)

        overlay.opacity = 0.5f
        findViewById<Slider>(R.id.opacitySlider).addOnChangeListener { _, value, _ ->
            overlay.opacity = value / 100f
        }

        findViewById<Button>(R.id.btnPick).setOnClickListener { pickImage.launch("image/*") }

        findViewById<Button>(R.id.btnFilter).setOnClickListener {
            if (original == null) return@setOnClickListener
            filterMode = filterMode.next()
            Toast.makeText(this, filterMode.labelRes, Toast.LENGTH_SHORT).show()
            applyFilter(reset = false)
        }

        findViewById<Button>(R.id.btnFlip).setOnClickListener { overlay.flipHorizontal() }

        btnLock.setOnClickListener {
            overlay.locked = !overlay.locked
            btnLock.setText(if (overlay.locked) R.string.unlock else R.string.lock)
        }

        findViewById<Button>(R.id.btnTorch).setOnClickListener {
            val cam = camera
            if (cam == null || !cam.cameraInfo.hasFlashUnit()) {
                toast(R.string.no_torch)
            } else {
                torchOn = !torchOn
                cam.cameraControl.enableTorch(torchOn)
            }
        }

        findViewById<Button>(R.id.btnCenter).setOnClickListener { overlay.resetTransform() }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) startCamera() else askCamera.launch(Manifest.permission.CAMERA)

        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        intent ?: return
        val uri: Uri? = when (intent.action) {
            Intent.ACTION_SEND ->
                IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
            Intent.ACTION_VIEW -> intent.data
            else -> null
        }
        uri?.let(::loadImage)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
                provider.unbindAll()
                camera = provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview
                )
            } catch (e: Exception) {
                toast(R.string.camera_denied)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun loadImage(uri: Uri) {
        worker.execute {
            val bmp = ImageLoader.load(this, uri)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (bmp == null) {
                    toast(R.string.image_error)
                } else {
                    original = bmp
                    filterMode = FilterMode.ORIGINAL
                    applyFilter(reset = true)
                }
            }
        }
    }

    private fun applyFilter(reset: Boolean) {
        val src = original ?: return
        val mode = filterMode
        val id = ++jobId
        worker.execute {
            val out = ImageFilters.apply(src, mode)
            runOnUiThread {
                if (id == jobId && !isDestroyed) overlay.setBitmap(out, reset)
            }
        }
    }

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        super.onDestroy()
        worker.shutdown()
    }
}
