package com.opentrace.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.net.Uri
import android.os.Bundle
import android.util.Range
import android.util.Size
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.google.android.material.slider.Slider
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.hypot

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var overlay: TraceOverlayView
    private lateinit var panel: View
    private lateinit var btnShow: View
    private lateinit var btnLock: Button
    private lateinit var btnFps: Button
    private lateinit var rowSensitivity: View
    private lateinit var prefs: SharedPreferences

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var torchOn = false
    private var highFps = true
    private var currentFps = 30

    private var original: Bitmap? = null
    private var filterMode = FilterMode.ORIGINAL
    private var sensitivity = 80
    private var gridIndex = 0
    private val gridSteps = intArrayOf(0, 3, 4, 6, 8)

    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var jobId = 0

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            uri?.let(::loadImage)
        }

    private val askCamera =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else toast(R.string.camera_denied)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("opentrace", Context.MODE_PRIVATE)

        previewView = findViewById(R.id.previewView)
        overlay = findViewById(R.id.overlay)
        panel = findViewById(R.id.panel)
        btnShow = findViewById(R.id.btnShow)
        btnLock = findViewById(R.id.btnLock)
        btnFps = findViewById(R.id.btnFps)
        rowSensitivity = findViewById(R.id.rowSensitivity)

        previewView.implementationMode = PreviewView.ImplementationMode.PERFORMANCE

        // Ajustes guardados
        val opacity = prefs.getFloat("opacity", 0.5f).coerceIn(0f, 1f)
        highFps = prefs.getBoolean("fps60", true)
        gridIndex = prefs.getInt("grid", 0).coerceIn(0, gridSteps.lastIndex)
        filterMode = FilterMode.values().getOrElse(prefs.getInt("filter", 0)) { FilterMode.ORIGINAL }
        sensitivity = prefs.getInt("sens", 80).coerceIn(0, 100)

        overlay.opacity = opacity
        overlay.gridDivisions = gridSteps[gridIndex]
        updateSensitivityRow()

        val opacitySlider = findViewById<Slider>(R.id.opacitySlider)
        opacitySlider.value = opacity * 100f
        opacitySlider.addOnChangeListener { _, value, _ -> overlay.opacity = value / 100f }

        val sensSlider = findViewById<Slider>(R.id.sensitivitySlider)
        sensSlider.value = sensitivity.toFloat()
        sensSlider.addOnChangeListener { _, value, fromUser ->
            if (fromUser) {
                sensitivity = value.toInt()
                applyFilter(reset = false)
            }
        }

        findViewById<Button>(R.id.btnPick).setOnClickListener { pickImage.launch("image/*") }

        findViewById<Button>(R.id.btnFilter).setOnClickListener {
            filterMode = filterMode.next()
            Toast.makeText(this, filterMode.labelRes, Toast.LENGTH_SHORT).show()
            updateSensitivityRow()
            applyFilter(reset = false)
        }

        findViewById<Button>(R.id.btnRotate).setOnClickListener { overlay.rotate90() }
        findViewById<Button>(R.id.btnFlip).setOnClickListener { overlay.flipHorizontal() }

        findViewById<Button>(R.id.btnGrid).setOnClickListener {
            gridIndex = (gridIndex + 1) % gridSteps.size
            val n = gridSteps[gridIndex]
            overlay.gridDivisions = n
            Toast.makeText(
                this,
                if (n == 0) getString(R.string.grid_off) else getString(R.string.grid_fmt, n),
                Toast.LENGTH_SHORT
            ).show()
        }

        btnLock.setOnClickListener {
            overlay.locked = !overlay.locked
            btnLock.setText(if (overlay.locked) R.string.unlock else R.string.lock)
        }

        findViewById<Button>(R.id.btnTorch).setOnClickListener {
            val cam = camera
            if (cam == null || !cam.cameraInfo.hasFlashUnit()) {
                toast(R.string.no_torch)
            } else {
                torchOn = !torchOn
                cam.cameraControl.enableTorch(torchOn)
            }
        }

        btnFps.setOnClickListener {
            highFps = !highFps
            bindCamera()
            if (highFps && currentFps < 60) toast(R.string.fps_unsupported)
        }

        findViewById<Button>(R.id.btnCenter).setOnClickListener { overlay.resetTransform() }

        findViewById<Button>(R.id.btnHide).setOnClickListener { setControlsVisible(false) }
        btnShow.setOnClickListener { setControlsVisible(true) }

        setupPreviewGestures()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) startCamera() else askCamera.launch(Manifest.permission.CAMERA)

        if (!handleIntent(intent)) restoreLastImage()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onPause() {
        super.onPause()
        prefs.edit()
            .putFloat("opacity", overlay.opacity)
            .putBoolean("fps60", highFps)
            .putInt("grid", gridIndex)
            .putInt("filter", filterMode.ordinal)
            .putInt("sens", sensitivity)
            .putString("matrix", overlay.getTransform().joinToString(","))
            .apply()
    }

    override fun onDestroy() {
        super.onDestroy()
        worker.shutdown()
    }

    // ---------- Entrada de imágenes ----------

    private fun handleIntent(intent: Intent?): Boolean {
        intent ?: return false
        val uri: Uri? = when (intent.action) {
            Intent.ACTION_SEND ->
                IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
            Intent.ACTION_VIEW -> intent.data
            else -> null
        }
        if (uri == null) return false
        loadImage(uri)
        return true
    }

    private fun loadImage(uri: Uri) {
        worker.execute {
            val bmp = ImageLoader.load(this, uri)
            if (bmp != null) saveLastImage(bmp)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (bmp == null) {
                    toast(R.string.image_error)
                } else {
                    original = bmp
                    applyFilter(reset = true)
                }
            }
        }
    }

    private fun saveLastImage(bmp: Bitmap) {
        try {
            FileOutputStream(File(filesDir, LAST_IMAGE)).use {
                bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
            }
        } catch (_: Exception) {
        }
    }

    private fun restoreLastImage() {
        val file = File(filesDir, LAST_IMAGE)
        if (!file.exists()) return
        worker.execute {
            val bmp = BitmapFactory.decodeFile(file.path) ?: return@execute
            runOnUiThread {
                if (isDestroyed || original != null) return@runOnUiThread
                original = bmp
                applyFilter(reset = false, restoreTransform = true)
            }
        }
    }

    private fun loadSavedMatrix(): FloatArray? =
        prefs.getString("matrix", null)
            ?.split(",")
            ?.mapNotNull { it.toFloatOrNull() }
            ?.takeIf { it.size == 9 }
            ?.toFloatArray()

    // ---------- Filtros ----------

    private fun updateSensitivityRow() {
        rowSensitivity.visibility = if (filterMode.usesSensitivity) View.VISIBLE else View.GONE
    }

    private fun applyFilter(reset: Boolean, restoreTransform: Boolean = false) {
        val src = original ?: return
        val mode = filterMode
        val sens = sensitivity
        val id = ++jobId
        worker.execute {
            if (id != jobId) return@execute // ya hay un trabajo más nuevo: no gastar CPU
            val out = ImageFilters.apply(src, mode, sens)
            runOnUiThread {
                if (id != jobId || isDestroyed) return@runOnUiThread
                overlay.setBitmap(out, reset)
                if (restoreTransform) loadSavedMatrix()?.let { overlay.setTransform(it) }
            }
        }
    }

    // ---------- Cámara ----------

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                cameraProvider = future.get()
                bindCamera()
            } catch (e: Exception) {
                toast(R.string.camera_denied)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    /** Elige el rango de FPS de la cámara trasera más cercano a 60 (o 30). */
    private fun chooseFpsRange(high: Boolean): Range<Int>? {
        try {
            val mgr = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = mgr.cameraIdList.firstOrNull {
                mgr.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) ==
                        CameraCharacteristics.LENS_FACING_BACK
            } ?: return null
            val ranges = mgr.getCameraCharacteristics(id)
                .get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            if (ranges.isNullOrEmpty()) return null

            val target = if (high) 60 else 30
            val bestUpper = ranges.map { it.upper }.filter { it <= target }.maxOrNull() ?: return null
            // Entre los rangos con ese máximo, el de mínimo ~mitad (p. ej. 30-60): fluido sin
            // oscurecer la imagen cuando hay poca luz.
            return ranges.filter { it.upper == bestUpper }
                .minByOrNull { abs(it.lower - bestUpper / 2) }
        } catch (e: Exception) {
            return null
        }
    }

    @androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
    private fun bindCamera() {
        val provider = cameraProvider ?: return
        try {
            val selector = ResolutionSelector.Builder()
                .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
                .setResolutionStrategy(
                    ResolutionStrategy(
                        Size(1920, 1080),
                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                    )
                )
                .build()

            val builder = Preview.Builder().setResolutionSelector(selector)
            val range = chooseFpsRange(highFps)
            if (range != null) {
                Camera2Interop.Extender(builder)
                    .setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, range)
            }
            val preview = builder.build()
            preview.setSurfaceProvider(previewView.surfaceProvider)

            provider.unbindAll()
            camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview)
            if (torchOn) camera?.cameraControl?.enableTorch(true)

            currentFps = range?.upper ?: 30
            btnFps.text = getString(R.string.fps_fmt, currentFps)
        } catch (e: Exception) {
            toast(R.string.camera_denied)
        }
    }

    /** Con la imagen bloqueada el toque llega a la cámara: pellizcar = zoom, tocar = enfocar. */
    private fun setupPreviewGestures() {
        val scaleDetector = ScaleGestureDetector(this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    val cam = camera ?: return true
                    val zoom = cam.cameraInfo.zoomState.value ?: return true
                    cam.cameraControl.setZoomRatio(
                        (zoom.zoomRatio * detector.scaleFactor)
                            .coerceIn(zoom.minZoomRatio, zoom.maxZoomRatio)
                    )
                    return true
                }
            })

        var downX = 0f
        var downY = 0f
        var downTime = 0L
        var multi = false

        previewView.setOnTouchListener { v, ev ->
            scaleDetector.onTouchEvent(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.x
                    downY = ev.y
                    downTime = ev.eventTime
                    multi = false
                }
                MotionEvent.ACTION_POINTER_DOWN -> multi = true
                MotionEvent.ACTION_UP -> {
                    if (!multi && ev.eventTime - downTime < 300 &&
                        hypot(ev.x - downX, ev.y - downY) < 24f
                    ) {
                        focusAt(ev.x, ev.y)
                        v.performClick()
                    }
                }
            }
            true
        }
    }

    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        val point = previewView.meteringPointFactory.createPoint(x, y)
        cam.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(point).build())
    }

    // ---------- Interfaz ----------

    private fun setControlsVisible(visible: Boolean) {
        panel.visibility = if (visible) View.VISIBLE else View.GONE
        btnShow.visibility = if (visible) View.GONE else View.VISIBLE
    }

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()

    private companion object {
        const val LAST_IMAGE = "last_image.png"
    }
}
