package com.opentrace.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import kotlin.math.abs

enum class FilterMode(val labelRes: Int, val usesSensitivity: Boolean) {
    ORIGINAL(R.string.filter_original, false),
    GRAYSCALE(R.string.filter_gray, false),
    LINES_DARK(R.string.filter_lines_dark, true),
    LINES_LIGHT(R.string.filter_lines_light, true),
    LINES_RED(R.string.filter_lines_red, true),
    SILHOUETTE(R.string.filter_silhouette, true);

    fun next(): FilterMode = values()[(ordinal + 1) % values().size]
}

/**
 * Filtros pensados para calcar. Mantienen el tamaño de la imagen.
 * El análisis pesado (luminancia + bordes Sobel) se calcula una sola vez por imagen
 * y se reutiliza al mover el control de detalle, así que ajustarlo es casi instantáneo.
 */
object ImageFilters {

    private class Analysis(val w: Int, val h: Int, val lum: ByteArray, val mag: ByteArray)

    private var cachedSrc: Bitmap? = null
    private var cached: Analysis? = null

    @Synchronized
    fun apply(src: Bitmap, mode: FilterMode, sensitivity: Int): Bitmap = when (mode) {
        FilterMode.ORIGINAL -> src
        FilterMode.GRAYSCALE -> grayscale(src)
        FilterMode.LINES_DARK -> lines(analysis(src), 0x000000, sensitivity)
        FilterMode.LINES_LIGHT -> lines(analysis(src), 0xFFFFFF, sensitivity)
        FilterMode.LINES_RED -> lines(analysis(src), 0xFF1744, sensitivity)
        FilterMode.SILHOUETTE -> silhouette(analysis(src), sensitivity)
    }

    private fun grayscale(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val paint = Paint().apply {
            colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
        }
        Canvas(out).drawBitmap(src, 0f, 0f, paint)
        return out
    }

    private fun analysis(src: Bitmap): Analysis {
        val c = cached
        if (c != null && cachedSrc === src) return c

        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)

        val lumInt = IntArray(w * h)
        val lum = ByteArray(w * h)
        for (i in px.indices) {
            val p = px[i]
            val a = p ushr 24
            val l = (77 * ((p shr 16) and 0xFF) + 150 * ((p shr 8) and 0xFF) + 29 * (p and 0xFF)) shr 8
            val v = (l * a + 255 * (255 - a)) / 255 // transparente = blanco
            lumInt[i] = v
            lum[i] = v.toByte()
        }

        val mag = ByteArray(w * h)
        for (y in 1 until h - 1) {
            val row = y * w
            for (x in 1 until w - 1) {
                val i = row + x
                val tl = lumInt[i - w - 1]; val t = lumInt[i - w]; val tr = lumInt[i - w + 1]
                val l = lumInt[i - 1]; val r = lumInt[i + 1]
                val bl = lumInt[i + w - 1]; val b = lumInt[i + w]; val br = lumInt[i + w + 1]
                val gx = -tl - 2 * l - bl + tr + 2 * r + br
                val gy = -tl - 2 * t - tr + bl + 2 * b + br
                mag[i] = (abs(gx) + abs(gy)).coerceAtMost(255).toByte()
            }
        }

        return Analysis(w, h, lum, mag).also {
            cachedSrc = src
            cached = it
        }
    }

    /** Líneas (bordes) sobre fondo transparente. sensitivity 0..100: más alto = más detalle. */
    private fun lines(a: Analysis, rgb: Int, sensitivity: Int): Bitmap {
        val threshold = 120 - sensitivity.coerceIn(0, 100)
        val out = IntArray(a.w * a.h)
        for (i in out.indices) {
            val m = a.mag[i].toInt() and 0xFF
            val alpha = ((m - threshold) * 2).coerceIn(0, 255)
            out[i] = (alpha shl 24) or rgb
        }
        return toBitmap(out, a.w, a.h)
    }

    /** Zonas oscuras en negro sólido, zonas claras transparentes. */
    private fun silhouette(a: Analysis, sensitivity: Int): Bitmap {
        val t = 30 + (sensitivity.coerceIn(0, 100) * 3) / 2
        val out = IntArray(a.w * a.h)
        for (i in out.indices) {
            val l = a.lum[i].toInt() and 0xFF
            val alpha = ((t - l) * 8).coerceIn(0, 255)
            out[i] = alpha shl 24
        }
        return toBitmap(out, a.w, a.h)
    }

    private fun toBitmap(pixels: IntArray, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(pixels, 0, w, 0, 0, w, h)
        return bmp
    }
}
