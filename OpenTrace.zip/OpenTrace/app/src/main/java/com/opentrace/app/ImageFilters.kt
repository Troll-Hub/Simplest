package com.opentrace.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import kotlin.math.abs

enum class FilterMode(val labelRes: Int) {
    ORIGINAL(R.string.filter_original),
    GRAYSCALE(R.string.filter_gray),
    LINES_DARK(R.string.filter_lines_dark),
    LINES_LIGHT(R.string.filter_lines_light);

    fun next(): FilterMode = values()[(ordinal + 1) % values().size]
}

/** Filtros pensados para calcar. Mantienen siempre el tamaño de la imagen original. */
object ImageFilters {

    fun apply(src: Bitmap, mode: FilterMode): Bitmap = when (mode) {
        FilterMode.ORIGINAL -> src
        FilterMode.GRAYSCALE -> grayscale(src)
        FilterMode.LINES_DARK -> lines(src, 0x000000)
        FilterMode.LINES_LIGHT -> lines(src, 0xFFFFFF)
    }

    private fun grayscale(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val paint = Paint().apply {
            colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
        }
        Canvas(out).drawBitmap(src, 0f, 0f, paint)
        return out
    }

    /** Detección de bordes Sobel; el resultado es solo líneas sobre fondo transparente. */
    private fun lines(src: Bitmap, rgb: Int): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)

        val lum = IntArray(w * h)
        for (i in px.indices) {
            val c = px[i]
            val a = c ushr 24
            val l = (0.299 * ((c shr 16) and 0xFF) +
                    0.587 * ((c shr 8) and 0xFF) +
                    0.114 * (c and 0xFF)).toInt()
            lum[i] = (l * a + 255 * (255 - a)) / 255 // transparente = blanco
        }

        val out = IntArray(w * h)
        for (y in 1 until h - 1) {
            val row = y * w
            for (x in 1 until w - 1) {
                val i = row + x
                val tl = lum[i - w - 1]; val t = lum[i - w]; val tr = lum[i - w + 1]
                val l = lum[i - 1]; val r = lum[i + 1]
                val bl = lum[i + w - 1]; val b = lum[i + w]; val br = lum[i + w + 1]
                val gx = -tl - 2 * l - bl + tr + 2 * r + br
                val gy = -tl - 2 * t - tr + bl + 2 * b + br
                val mag = abs(gx) + abs(gy)
                val alpha = ((mag - 40) * 2).coerceIn(0, 255)
                out[i] = (alpha shl 24) or rgb
            }
        }
        val result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        result.setPixels(out, 0, w, 0, 0, w, h)
        return result
    }
}
