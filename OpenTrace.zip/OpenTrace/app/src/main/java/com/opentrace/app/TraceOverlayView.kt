package com.opentrace.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.min

/** Dibuja la imagen de calco sobre la cámara y gestiona mover / escalar / rotar. */
class TraceOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var bitmap: Bitmap? = null
    private val imgMatrix = Matrix()
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xCC00E5FF.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * resources.displayMetrics.density
    }
    private var pendingReset = false

    // Cuadrícula (en coordenadas de la imagen) y su versión en pantalla, sin reservar memoria al dibujar
    private var gridSrc = FloatArray(0)
    private var gridDst = FloatArray(0)

    var locked = false

    var opacity = 0.5f
        set(value) {
            field = value.coerceIn(0f, 1f)
            paint.alpha = (field * 255).toInt()
            invalidate()
        }

    /** 0 = sin cuadrícula; n = n×n celdas sobre la imagen. */
    var gridDivisions = 0
        set(value) {
            field = value
            rebuildGrid()
            invalidate()
        }

    private var lastX = 0f
    private var lastY = 0f
    private var prevMidX = 0f
    private var prevMidY = 0f
    private var prevDist = 1f
    private var prevAngle = 0f

    init {
        paint.alpha = 128
    }

    fun setBitmap(bmp: Bitmap, reset: Boolean) {
        val first = bitmap == null || reset
        bitmap = bmp
        rebuildGrid()
        if (first) {
            if (width > 0 && height > 0) resetTransform() else pendingReset = true
        }
        invalidate()
    }

    fun resetTransform() {
        val b = bitmap ?: return
        if (width == 0 || height == 0) return
        imgMatrix.reset()
        val s = min(width.toFloat() / b.width, height.toFloat() / b.height) * 0.9f
        imgMatrix.postScale(s, s)
        imgMatrix.postTranslate((width - b.width * s) / 2f, (height - b.height * s) / 2f)
        invalidate()
    }

    fun flipHorizontal() {
        val b = bitmap ?: return
        imgMatrix.preScale(-1f, 1f, b.width / 2f, b.height / 2f)
        invalidate()
    }

    fun rotate90() {
        val b = bitmap ?: return
        imgMatrix.preRotate(90f, b.width / 2f, b.height / 2f)
        invalidate()
    }

    fun getTransform(): FloatArray = FloatArray(9).also { imgMatrix.getValues(it) }

    fun setTransform(values: FloatArray) {
        if (values.size != 9) return
        imgMatrix.setValues(values)
        pendingReset = false
        invalidate()
    }

    private fun rebuildGrid() {
        val b = bitmap
        val n = gridDivisions
        if (b == null || n < 2) {
            gridSrc = FloatArray(0)
            gridDst = FloatArray(0)
            return
        }
        val w = b.width.toFloat()
        val h = b.height.toFloat()
        val a = FloatArray((n + 1) * 2 * 4)
        var k = 0
        for (i in 0..n) {
            val x = w * i / n
            a[k++] = x; a[k++] = 0f; a[k++] = x; a[k++] = h
            val y = h * i / n
            a[k++] = 0f; a[k++] = y; a[k++] = w; a[k++] = y
        }
        gridSrc = a
        gridDst = FloatArray(a.size)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (pendingReset && w > 0 && h > 0) {
            pendingReset = false
            resetTransform()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val b = bitmap ?: return
        canvas.drawBitmap(b, imgMatrix, paint)
        if (gridSrc.isNotEmpty()) {
            imgMatrix.mapPoints(gridDst, gridSrc)
            canvas.drawLines(gridDst, gridPaint)
        }
    }

    private fun captureTwoFingers(e: MotionEvent) {
        val dx = e.getX(1) - e.getX(0)
        val dy = e.getY(1) - e.getY(0)
        prevMidX = (e.getX(0) + e.getX(1)) / 2f
        prevMidY = (e.getY(0) + e.getY(1)) / 2f
        prevDist = hypot(dx, dy).coerceAtLeast(1f)
        prevAngle = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        // Con la imagen bloqueada el toque pasa a la cámara (zoom y enfoque)
        if (locked || bitmap == null) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x
                lastY = e.y
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.pointerCount >= 2) captureTwoFingers(e)
            }
            MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount == 1) {
                    imgMatrix.postTranslate(e.x - lastX, e.y - lastY)
                    lastX = e.x
                    lastY = e.y
                } else {
                    val dx = e.getX(1) - e.getX(0)
                    val dy = e.getY(1) - e.getY(0)
                    val midX = (e.getX(0) + e.getX(1)) / 2f
                    val midY = (e.getY(0) + e.getY(1)) / 2f
                    val dist = hypot(dx, dy).coerceAtLeast(1f)
                    val angle = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()

                    val scale = dist / prevDist
                    imgMatrix.postScale(scale, scale, prevMidX, prevMidY)
                    imgMatrix.postRotate(angle - prevAngle, prevMidX, prevMidY)
                    imgMatrix.postTranslate(midX - prevMidX, midY - prevMidY)

                    prevMidX = midX
                    prevMidY = midY
                    prevDist = dist
                    prevAngle = angle
                }
                invalidate()
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (e.pointerCount == 2) {
                    val remaining = if (e.actionIndex == 0) 1 else 0
                    lastX = e.getX(remaining)
                    lastY = e.getY(remaining)
                } else if (e.pointerCount > 2) {
                    captureTwoFingers(e)
                }
            }
        }
        return true
    }
}
