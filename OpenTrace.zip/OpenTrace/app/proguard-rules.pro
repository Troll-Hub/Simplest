# Reglas extra de R8 (las de CameraX y Material vienen incluidas en sus librerías).
