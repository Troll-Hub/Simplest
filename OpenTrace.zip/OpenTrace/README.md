# OpenTrace

App Android de código abierto (Kotlin) para calcar dibujos: superpone una imagen sobre la cámara y te deja moverla, escalarla, rotarla y bloquearla para trazar con precisión. Sin cuentas, sin anuncios, sin internet, sin servicios de terceros.

Open-source Android tracing app: overlay any image on the camera feed and trace it.

## Funciones
- Cualquier imagen que Android pueda decodificar: JPG, PNG, WebP, GIF, BMP, HEIC/HEIF, AVIF (Android 12+)... También desde "Compartir" / "Abrir con" de otras apps.
- Un dedo = mover; dos dedos = zoom, rotación y movimiento a la vez.
- Opacidad ajustable, voltear, bloquear (evita mover sin querer), linterna, centrar.
- Filtros: original, grises, líneas oscuras y líneas claras (contornos).
- 100 % offline. Sin permisos salvo la cámara.

## Compilar con GitHub
1. Sube este proyecto a un repositorio (rama `main`).
2. Pestaña **Actions** → **Build APK** (se ejecuta solo al hacer push, o con *Run workflow*).
3. Descarga el APK en **Artifacts** (`OpenTrace-debug-apk`).
4. Para publicar una release: `git tag v1.0.0 && git push --tags`.

## Compilar en local
`gradle assembleDebug` (Gradle 8.9, JDK 17) o ábrelo con Android Studio.

## Licencia
MIT.
