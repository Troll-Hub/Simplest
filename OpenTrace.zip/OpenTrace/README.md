# OpenTrace

App Android de código abierto (Kotlin) para calcar dibujos: superpone una imagen sobre la cámara y te deja moverla, escalarla, rotarla y bloquearla para trazar con precisión. Sin cuentas, sin anuncios, sin internet, sin servicios de terceros.

Open-source Android tracing app: overlay any image on the camera feed and trace it.

## Funciones
- **Cámara fluida**: vista previa a 60 fps cuando el móvil lo admite (botón de fps para alternar 30/60), 1080p.
- Cualquier imagen que Android pueda decodificar: JPG, PNG, WebP, GIF, BMP, HEIC/HEIF, AVIF (Android 12+)... También desde "Compartir" / "Abrir con" de otras apps.
- Un dedo = mover; dos dedos = zoom, rotación y movimiento a la vez. Botones para girar 90°, voltear y centrar.
- Opacidad ajustable y **cuadrícula** (3×3, 4×4, 6×6, 8×8) pegada a la imagen, para el método de cuadrícula.
- Filtros: original, grises, líneas oscuras / claras / rojas (contornos) y silueta, con control de **detalle** instantáneo.
- **Bloquear** imagen: entonces pellizcar hace zoom de cámara y tocar enfoca.
- Ocultar controles para ver la cámara completa.
- Recuerda la última imagen, su posición y tus ajustes.
- 100 % offline. Sin permisos salvo la cámara. APK optimizado con R8.

## Compilar con GitHub
1. Sube este proyecto a un repositorio (rama `main`).
2. Pestaña **Actions** → **Build APK** (se ejecuta solo al hacer push, o con *Run workflow*).
3. Descarga el APK en **Artifacts** (`OpenTrace-debug-apk`).
4. Para publicar una release: `git tag v1.0.0 && git push --tags`.

## Compilar en local
`gradle assembleDebug` (Gradle 8.9, JDK 17) o ábrelo con Android Studio.

## Licencia
MIT.
