# SimpleHorizon

Stretch de pantalla para Blood Strike (`com.netease.newspike`, actividad `com.netease.game.MessiahNativeActivity`) sin `wm size`: el juego corre en una pantalla virtual (Shizuku) que Android escala para llenar el panel.
