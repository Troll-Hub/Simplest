package com.simplehorizon.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.os.IBinder
import android.content.ServiceConnection
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private lateinit var permBtn: Button
    private lateinit var lbl: TextView
    private lateinit var bar: SeekBar
    private val listener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("horizon", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        fun text(s: String, size: Float = 14f) = TextView(this).apply { text = s; textSize = size; setPadding(0, pad / 2, 0, pad / 4) }

        col.addView(text(getString(R.string.app_name), 28f))
        col.addView(text(Game.NAME, 18f))
        status = text("")
        col.addView(status)
        permBtn = Button(this).apply { text = getString(R.string.dar_permiso); setOnClickListener { HorizonBridge.requestPermission() } }
        col.addView(permBtn)
        lbl = text("")
        col.addView(lbl)
        bar = SeekBar(this).apply {
            max = Stretch.MAX - Stretch.MIN
            progress = Stretch.clamp(prefs.getInt("r", 150)) - Stretch.MIN
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) prefs.edit().putInt("r", Stretch.MIN + p).apply()
                    show()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        col.addView(bar)
        col.addView(Button(this).apply { text = getString(R.string.iniciar); setOnClickListener { start() } })
        col.addView(Button(this).apply { text = getString(R.string.diagnostico); setOnClickListener { runProbe() } })
        col.addView(text(getString(R.string.nota)))
        setContentView(ScrollView(this).apply { addView(col) })
        show()
        try { Shizuku.addRequestPermissionResultListener(listener) } catch (_: Throwable) {}
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { Shizuku.removeRequestPermissionResultListener(listener) } catch (_: Throwable) {}
    }

    private fun installed(): Boolean = try { packageManager.getPackageInfo(Game.PKG, 0); true } catch (_: Exception) { false }

    private fun refresh() {
        val st = HorizonBridge.state()
        status.text = if (!installed()) getString(R.string.no_instalado, Game.NAME) else getString(
            when (st) {
                HorizonBridge.State.READY -> R.string.shizuku_ok
                HorizonBridge.State.NO_PERMISSION -> R.string.shizuku_permiso
                HorizonBridge.State.NOT_RUNNING -> R.string.shizuku_off
                HorizonBridge.State.UNSUPPORTED -> R.string.shizuku_viejo
            }
        )
        permBtn.visibility = if (st == HorizonBridge.State.NO_PERMISSION) View.VISIBLE else View.GONE
    }

    private fun show() {
        lbl.text = getString(R.string.ratio, String.format(Locale.US, "%.2f", (Stretch.MIN + bar.progress) / 100.0))
    }

    /** Lee del sistema qué se puede hacer a nivel de pantalla (sin cambiar nada) y permite copiarlo. */
    private fun runProbe() {
        if (HorizonBridge.state() != HorizonBridge.State.READY) {
            Toast.makeText(this, R.string.h_shizuku_off, Toast.LENGTH_LONG).show()
            return
        }
        val a = HorizonBridge.serviceArgs(this)
        var c: ServiceConnection? = null
        c = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                val s = if (binder != null) IHorizonService.Stub.asInterface(binder) else null
                Thread({
                    val r = try { s?.probe() ?: "Sin servicio" } catch (e: Throwable) { "Error: " + e.message }
                    runOnUiThread { showProbe(r) }
                    try { Shizuku.unbindUserService(a, c!!, true) } catch (_: Throwable) {}
                }, "simplehorizon-probe").start()
            }

            override fun onServiceDisconnected(name: ComponentName?) {}
        }
        try { Shizuku.bindUserService(a, c) } catch (e: Throwable) { showProbe("Error: " + e.message) }
    }

    private fun showProbe(r: String) {
        val d = AlertDialog.Builder(this)
            .setTitle(R.string.diagnostico)
            .setMessage(r)
            .setPositiveButton("Copiar") { _, _ ->
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("diagnostico", r))
            }
            .setNegativeButton("Cerrar", null)
            .create()
        d.show()
        d.findViewById<TextView>(android.R.id.message)?.apply { textSize = 11f; setTextIsSelectable(true) }
    }

    private fun start() {
        when {
            !installed() -> Toast.makeText(this, getString(R.string.no_instalado, Game.NAME), Toast.LENGTH_LONG).show()
            HorizonBridge.state() != HorizonBridge.State.READY -> Toast.makeText(this, R.string.h_shizuku_off, Toast.LENGTH_LONG).show()
            else -> if (Permisos.listo(this)) HorizonActivity.start(this, Game.PKG)
        }
    }
}
