package com.simplehorizon.app

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

/** Estilo visual compartido: fondo oscuro, tarjetas redondeadas y un acento naranja. */
object Ui {
    val BG = 0xFF0B0D12.toInt()
    val CARD = 0xFF161A22.toInt()
    val CHIP = 0xFF232938.toInt()
    val ACCENT = 0xFFFF7A2F.toInt()
    val TXT = 0xFFEDEFF3.toInt()
    val MUTED = 0xFF8A93A6.toInt()
    val OK = 0xFF3DDC97.toInt()
    val BAD = 0xFFFF5C5C.toInt()

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun round(c: Context, color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(c, r).toFloat()
    }

    fun text(c: Context, t: String, size: Float, color: Int = TXT, bold: Boolean = false) = TextView(c).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    fun card(c: Context) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
        background = round(c, CARD, 18)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { setMargins(dp(c, 12), dp(c, 6), dp(c, 12), dp(c, 6)) }
    }

    fun button(c: Context, t: String, primary: Boolean, onClick: () -> Unit) = TextView(c).apply {
        text = t
        textSize = 14f
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (primary) BG else TXT)
        background = round(c, if (primary) ACCENT else CHIP, 14)
        setPadding(dp(c, 12), dp(c, 12), dp(c, 12), dp(c, 12))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { setMargins(0, dp(c, 8), 0, 0) }
        setOnClickListener { onClick() }
    }

    fun chip(c: Context, t: String, selected: Boolean, onClick: () -> Unit) = TextView(c).apply {
        text = t
        textSize = 13f
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(c, 8), dp(c, 10), dp(c, 8), dp(c, 10))
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            .apply { setMargins(dp(c, 3), dp(c, 6), dp(c, 3), 0) }
        paintChip(c, this, selected)
        setOnClickListener { onClick() }
    }

    fun paintChip(c: Context, tv: TextView, selected: Boolean) {
        tv.setTextColor(if (selected) BG else TXT)
        tv.background = round(c, if (selected) ACCENT else CHIP, 12)
    }
}
