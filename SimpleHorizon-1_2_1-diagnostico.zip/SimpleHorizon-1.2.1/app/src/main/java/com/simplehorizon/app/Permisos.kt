package com.simplehorizon.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast

/** Permisos para quedarse activo: superposición, notificaciones y sin restricción de batería. */
object Permisos {
    private const val REQ_NOTIF = 77

    /** true cuando todo está listo; si falta algo, abre el ajuste correspondiente y devuelve false. */
    fun listo(act: Activity): Boolean {
        if (!Settings.canDrawOverlays(act)) {
            act.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${act.packageName}")))
            Toast.makeText(act, "Activa «Mostrar sobre otras apps» y vuelve a pulsar Iniciar", Toast.LENGTH_LONG).show()
            return false
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            act.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            act.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return false
        }
        val pm = act.getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(act.packageName)) {
            act.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${act.packageName}")))
            Toast.makeText(act, "Permite uso sin restricciones de batería y vuelve a pulsar Iniciar", Toast.LENGTH_LONG).show()
            return false
        }
        return true
    }
}
