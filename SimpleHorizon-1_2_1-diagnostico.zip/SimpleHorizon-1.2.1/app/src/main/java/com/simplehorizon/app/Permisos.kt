package com.simplehorizon.app

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.os.Process
import android.provider.Settings
import android.widget.Toast

/** Permisos para quedarse activo: superposición, notificaciones, acceso de uso y sin restricción de batería. */
object Permisos {
    private const val REQ_NOTIF = 77

    fun overlay(c: Context) = Settings.canDrawOverlays(c)

    fun notif(c: Context) = Build.VERSION.SDK_INT < 33 ||
        c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun bateria(c: Context) = c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)

    @Suppress("DEPRECATION")
    fun uso(c: Context): Boolean = c.getSystemService(AppOpsManager::class.java)
        .checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED

    fun instalado(c: Context) = try {
        c.packageManager.getPackageInfo(Game.PKG, 0)
        true
    } catch (_: Exception) {
        false
    }

    /** true cuando todo está listo; si falta algo, abre el ajuste correspondiente y devuelve false. */
    fun listo(act: Activity): Boolean {
        val pkg = Uri.parse("package:${act.packageName}")
        if (!overlay(act)) {
            act.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg))
            aviso(act, "Activa «Mostrar sobre otras apps»")
            return false
        }
        if (!notif(act)) {
            act.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return false
        }
        if (!uso(act)) {
            act.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            aviso(act, "Activa «Acceso de uso» para SimpleHorizon")
            return false
        }
        if (!bateria(act)) {
            act.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg))
            aviso(act, "Permite uso sin restricciones de batería")
            return false
        }
        return true
    }

    private fun aviso(c: Context, t: String) {
        Toast.makeText(c, "$t y vuelve a pulsar Aplicar", Toast.LENGTH_LONG).show()
    }
}
