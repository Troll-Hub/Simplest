package com.simplehorizon.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale
import kotlin.math.abs

/** Burbuja flotante con menú + servicio en primer plano (notificación) para que Android no lo cierre. */
class BubbleService : Service(), StretchBus.Listener {

    companion object {
        private const val CHANNEL = "horizon_activo"
        private const val NOTIF_ID = 4242
        private const val ACTION_STOP = "com.simplehorizon.app.STOP"

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, BubbleService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, BubbleService::class.java))
        }
    }

    private val prefs by lazy { getSharedPreferences("horizon", MODE_PRIVATE) }
    private lateinit var wm: WindowManager
    private var bubbleView: View? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var panelView: View? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var ratioLbl: TextView? = null
    private var axisBtn: Button? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun ratio() = Stretch.clamp(prefs.getInt("r", 150))
    private fun fmt(r: Int) = String.format(Locale.US, "%.2f", r / 100.0)

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        startForegroundCompat()
        StretchBus.add(this)
        try {
            addViews()
        } catch (_: Throwable) {
            // Sin permiso de superposición no hay burbuja: el servicio se cierra solo
            shutdown()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            StretchBus.requestExit()
            shutdown()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        StretchBus.remove(this)
        removeViews()
        super.onDestroy()
    }

    override fun onStretchChanged() {
        updateLabels()
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    // ---------- Servicio en primer plano ----------
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "Estiramiento activo", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun startForegroundCompat() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, BubbleService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val eje = if (prefs.getBoolean("axis", true)) "vertical" else "horizontal"
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_crop)
            .setContentTitle("SimpleHorizon activo")
            .setContentText("Estiramiento " + fmt(ratio()) + "× · eje " + eje)
            .setContentIntent(open)
            .addAction(0, "Salir", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun shutdown() {
        StretchBus.remove(this)
        removeViews()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun removeViews() {
        listOfNotNull(bubbleView, panelView).forEach { v ->
            try { wm.removeView(v) } catch (_: Throwable) {}
        }
        bubbleView = null
        panelView = null
    }

    // ---------- Vistas ----------
    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    )

    private fun addViews() {
        val bubble = TextView(this).apply {
            text = "⚙"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCC000000.toInt()) }
        }
        val bl = lp(dp(48), dp(48)).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(200) }
        bubble.setOnTouchListener(dragListener(bl))
        wm.addView(bubble, bl)
        bubbleView = bubble
        bubbleLp = bl

        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t
            textSize = 11f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { f() }
        }

        fun row(vararg items: Pair<String, () -> Unit>) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            items.forEach { addView(btn(it.first, it.second)) }
        }

        val lbl = TextView(this).apply { textSize = 12f; setTextColor(Color.WHITE) }
        ratioLbl = lbl
        val ax = btn("") { toggleAxis() }
        ax.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        axisBtn = ax

        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(0xE6101418.toInt()) }
            visibility = View.GONE
            addView(lbl)
            addView(row("−0.01" to { setRatio(ratio() - 1) }, "+0.01" to { setRatio(ratio() + 1) },
                "1.00" to { setRatio(100) }, "1.25" to { setRatio(125) }))
            addView(row("1.33" to { setRatio(133) }, "1.50" to { setRatio(150) },
                "1.77" to { setRatio(177) }, "1.99" to { setRatio(199) }))
            addView(ax)
            addView(row("Ocultar" to { togglePanel() }, "Salir" to { StretchBus.requestExit(); shutdown() }))
        }
        val pl = lp(dp(250), ViewGroup.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(p, pl)
        panelView = p
        panelLp = pl
        updateLabels()
    }

    private fun dragListener(bl: WindowManager.LayoutParams): View.OnTouchListener {
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        return View.OnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = bl.x; sy = bl.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (abs(dx) + abs(dy) > dp(4)) moved = true
                    bl.x = sx + dx
                    bl.y = sy + dy
                    wm.updateViewLayout(v, bl)
                }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel()
            }
            true
        }
    }

    private fun togglePanel() {
        val p = panelView ?: return
        val bl = bubbleLp ?: return
        val pl = panelLp ?: return
        val show = p.visibility != View.VISIBLE
        if (show) {
            pl.x = bl.x
            pl.y = bl.y + dp(56)
            wm.updateViewLayout(p, pl)
        }
        p.visibility = if (show) View.VISIBLE else View.GONE
    }

    // ---------- Acciones (se guardan y avisan a la ventana del juego) ----------
    private fun setRatio(r: Int) {
        prefs.edit().putInt("r", Stretch.clamp(r)).apply()
        StretchBus.notifyChanged()
    }

    private fun toggleAxis() {
        prefs.edit().putBoolean("axis", !prefs.getBoolean("axis", true)).apply()
        StretchBus.notifyChanged()
    }

    private fun updateLabels() {
        ratioLbl?.text = "Estiramiento: " + fmt(ratio()) + "×"
        axisBtn?.text = if (prefs.getBoolean("axis", true)) "Eje: vertical ↕" else "Eje: horizontal ↔"
    }
}
