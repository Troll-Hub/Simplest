package com.simplehorizon.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale
import kotlin.math.abs

/**
 * Servicio en primer plano: control flotante (solo durante la partida), vigilancia del juego
 * (restaura al salir y vuelve a aplicar al volver) y notificación para que Android no lo cierre.
 */
class BubbleService : Service(), StretchBus.Listener {

    companion object {
        @Volatile var running = false
        private const val CHANNEL = "horizon_activo"
        private const val NOTIF_ID = 4242
        private const val ACTION_STOP = "com.simplehorizon.app.STOP"
        private const val WINDOW_MS = 600_000L
        private const val TICK_MS = 1000L

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, BubbleService::class.java))
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("horizon", MODE_PRIVATE) }
    private lateinit var wm: WindowManager
    private var bubbleView: TextView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var panelView: View? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var ratioLbl: TextView? = null
    private var axisBtn: TextView? = null
    private var inGame = false

    private val tick = object : Runnable {
        override fun run() {
            watch()
            updateBubble()
            main.postDelayed(this, TICK_MS)
        }
    }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun ratio() = Stretch.clamp(prefs.getInt("r", 150))
    private fun axis() = prefs.getBoolean("axis", true)
    private fun fmt(r: Int) = String.format(Locale.US, "%.2f", r / 100.0)

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        startForegroundCompat()
        StretchBus.add(this)
        try {
            addViews()
        } catch (_: Throwable) {
            shutdown()
            return
        }
        main.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) shutdown()
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        StretchBus.remove(this)
        removeViews()
        Stretcher.release(this)
        super.onDestroy()
    }

    override fun onStretchChanged() {
        updateLabels()
        WmController.apply(ratio(), axis())
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    // ---------- Vigilancia del juego ----------
    private fun watch() {
        val pkg = lastForegroundPkg() ?: return
        if (pkg == packageName) return // mientras usas SimpleHorizon no cambia nada
        val g = pkg == Game.PKG
        if (g == inGame) return
        inGame = g
        if (g) {
            WmController.apply(ratio(), axis())
        } else if (prefs.getBoolean("autoRestore", true)) {
            WmController.reset()
        }
    }

    @Suppress("DEPRECATION")
    private fun lastForegroundPkg(): String? {
        val usm = getSystemService(UsageStatsManager::class.java) ?: return null
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(now - WINDOW_MS, now)
        val e = UsageEvents.Event()
        var last: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last = e.packageName
        }
        return last
    }

    private fun updateBubble() {
        val show = inGame && prefs.getBoolean("bubble", true)
        bubbleView?.visibility = if (show) View.VISIBLE else View.GONE
        if (!show) panelView?.visibility = View.GONE
    }

    // ---------- Servicio en primer plano ----------
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "Estiramiento activo", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun startForegroundCompat() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, BubbleService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val eje = if (axis()) "vertical" else "horizontal"
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_crop)
            .setContentTitle("SimpleHorizon activo")
            .setContentText("Estiramiento " + fmt(ratio()) + "× · eje " + eje)
            .setContentIntent(open)
            .addAction(0, "Restaurar", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun shutdown() {
        removeViews()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun removeViews() {
        listOfNotNull(bubbleView, panelView).forEach { v ->
            try { wm.removeView(v) } catch (_: Throwable) {}
        }
        bubbleView = null
        panelView = null
    }

    // ---------- Vistas ----------
    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    )

    private fun chipRow(vararg items: Pair<String, () -> Unit>): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((t, f) in items) r.addView(Ui.chip(this, t, false, f))
        return r
    }

    private fun addViews() {
        val bubble = TextView(this).apply {
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Ui.BG)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Ui.ACCENT) }
        }
        val bl = lp(dp(56), dp(56)).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(160) }
        bubble.setOnTouchListener(dragListener(bl))
        wm.addView(bubble, bl)
        bubbleView = bubble
        bubbleLp = bl

        val lbl = Ui.text(this, "", 14f, Ui.TXT, true)
        ratioLbl = lbl
        val ax = Ui.chip(this, "", false) { toggleAxis() }
        ax.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { setMargins(0, dp(6), 0, 0) }
        axisBtn = ax

        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = Ui.round(this@BubbleService, Ui.CARD, 18)
            visibility = View.GONE
            addView(lbl)
            addView(chipRow("1.00" to { setRatio(100) }, "1.25" to { setRatio(125) }, "1.33" to { setRatio(133) }))
            addView(chipRow("1.50" to { setRatio(150) }, "1.77" to { setRatio(177) }, "1.99" to { setRatio(199) }))
            addView(chipRow("−0.01" to { setRatio(ratio() - 1) }, "+0.01" to { setRatio(ratio() + 1) }))
            addView(ax)
            addView(chipRow("Ocultar" to { togglePanel() }, "Salir" to { shutdown() }))
        }
        val pl = lp(dp(260), ViewGroup.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(p, pl)
        panelView = p
        panelLp = pl
        updateLabels()
    }

    private fun dragListener(bl: WindowManager.LayoutParams): View.OnTouchListener {
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        return View.OnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = bl.x; sy = bl.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (abs(dx) + abs(dy) > dp(4)) moved = true
                    bl.x = sx + dx
                    bl.y = sy + dy
                    wm.updateViewLayout(v, bl)
                }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel()
            }
            true
        }
    }

    private fun togglePanel() {
        val p = panelView ?: return
        val bl = bubbleLp ?: return
        val pl = panelLp ?: return
        val show = p.visibility != View.VISIBLE
        if (show) {
            pl.x = bl.x
            pl.y = bl.y + dp(64)
            wm.updateViewLayout(p, pl)
        }
        p.visibility = if (show) View.VISIBLE else View.GONE
    }

    // ---------- Acciones (se guardan y avisan a la ventana y a la notificación) ----------
    private fun setRatio(r: Int) {
        prefs.edit().putInt("r", Stretch.clamp(r)).apply()
        StretchBus.notifyChanged()
    }

    private fun toggleAxis() {
        prefs.edit().putBoolean("axis", !axis()).apply()
        StretchBus.notifyChanged()
    }

    private fun updateLabels() {
        ratioLbl?.text = "Estiramiento " + fmt(ratio()) + "×"
        axisBtn?.text = if (axis()) "Eje vertical ↕" else "Eje horizontal ↔"
        bubbleView?.text = fmt(ratio())
    }
}
