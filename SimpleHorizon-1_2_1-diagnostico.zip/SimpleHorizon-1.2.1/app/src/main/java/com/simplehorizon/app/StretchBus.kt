package com.simplehorizon.app

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArraySet

/** Canal dentro del proceso entre el menú flotante, la ventana del juego y la notificación. */
object StretchBus {
    interface Listener {
        fun onStretchChanged() {}
        fun onExit() {}
    }

    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArraySet<Listener>()

    fun add(l: Listener) { listeners.add(l) }
    fun remove(l: Listener) { listeners.remove(l) }
    fun notifyChanged() { main.post { listeners.forEach { it.onStretchChanged() } } }
    fun requestExit() { main.post { listeners.forEach { it.onExit() } } }
}
