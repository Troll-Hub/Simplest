package com.simplehorizon.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast

/** Arranque y liberación: permisos → Shizuku → wm size → juego → control flotante. */
object Stretcher {
    private const val PREFS = "horizon"
    private const val KEY_APPLIED = "applied"

    fun start(act: Activity) {
        if (!Permisos.listo(act)) return
        val app = act.applicationContext
        Thread({
            val ok = WmController.connect(app)
            Handler(Looper.getMainLooper()).post {
                if (!ok) {
                    Toast.makeText(act, "Shizuku no está activo o no tiene permiso", Toast.LENGTH_LONG).show()
                    return@post
                }
                val prefs = act.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                prefs.edit().putBoolean(KEY_APPLIED, true).apply()
                WmController.apply(prefs.getInt("r", 150), prefs.getBoolean("axis", true))
                act.startActivity(Intent().setClassName(Game.PKG, Game.ACTIVITY))
                BubbleService.start(act)
            }
        }, "stretch-start").start()
    }

    /** Detiene el servicio; su onDestroy restaura el tamaño original. */
    fun stop(ctx: Context) {
        ctx.stopService(Intent(ctx, BubbleService::class.java))
    }

    fun release(ctx: Context) {
        WmController.reset()
        WmController.disconnect()
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_APPLIED, false).apply()
    }

    /** Si la app murió con el estiramiento activo (el servicio ya no existe), restaura el tamaño. */
    fun restore(ctx: Context) {
        if (BubbleService.running) return
        if (!ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_APPLIED, false)) return
        val app = ctx.applicationContext
        Thread({ if (WmController.connect(app)) release(app) }, "stretch-restore").start()
    }
}
