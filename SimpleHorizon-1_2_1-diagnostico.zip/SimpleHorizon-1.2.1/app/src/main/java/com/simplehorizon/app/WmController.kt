package com.simplehorizon.app

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.os.IBinder
import rikka.shizuku.Shizuku
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Estiramiento al estilo Cat Resolution Pro: cambia el tamaño físico con `wm size` (shell vía Shizuku).
 * El compositor escala la imagen al panel; no hay pantalla virtual, así que no se pierden fps.
 */
object WmController {
    private val exec = Executors.newSingleThreadExecutor()
    @Volatile private var svc: IHorizonService? = null
    private var args: Shizuku.UserServiceArgs? = null
    private var conn: ServiceConnection? = null
    @Volatile private var nativeW = 0
    @Volatile private var nativeH = 0

    /** Bloqueante: llamar desde un hilo de fondo. */
    fun connect(ctx: Context): Boolean {
        if (svc != null) return true
        if (HorizonBridge.state() != HorizonBridge.State.READY) return false
        val latch = CountDownLatch(1)
        val c = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                svc = if (binder != null && binder.pingBinder()) IHorizonService.Stub.asInterface(binder) else null
                latch.countDown()
            }
            override fun onServiceDisconnected(name: ComponentName?) { svc = null }
        }
        val a = HorizonBridge.serviceArgs(ctx)
        args = a
        conn = c
        try { Shizuku.bindUserService(a, c) } catch (_: Throwable) { return false }
        latch.await(10, TimeUnit.SECONDS)
        return svc != null && readNative()
    }

    /** Tamaño físico natural (vertical), leído de `wm size`; sigue siendo válido aunque haya override. */
    private fun readNative(): Boolean {
        val out = try { svc?.wm("") ?: "" } catch (_: Throwable) { "" }
        val m = Regex("Physical size: (\\d+)x(\\d+)").find(out) ?: return false
        nativeW = m.groupValues[1].toInt()
        nativeH = m.groupValues[2].toInt()
        return true
    }

    /**
     * Horizontal (juego en landscape): reduce la altura natural → la imagen se estira a lo ancho.
     * Vertical: reduce la anchura natural → se estira a lo alto. 1.00 = reset.
     */
    fun apply(ratio: Int, vertical: Boolean) {
        exec.execute {
            val s = svc ?: return@execute
            if (nativeW == 0 && !readNative()) return@execute
            val p = Stretch.clamp(ratio)
            fun cut(v: Int) = ((v * 100 / p) / 2 * 2).coerceAtLeast(64)
            val arg = when {
                p == 100 -> "reset"
                vertical -> "${cut(nativeW)}x$nativeH"
                else -> "${nativeW}x${cut(nativeH)}"
            }
            try { s.wm(arg) } catch (_: Throwable) {}
        }
    }

    fun nativeSize(): Pair<Int, Int>? = if (nativeW > 0) nativeW to nativeH else null

    /** Volcado de `wm size` y estado del sistema, para diagnóstico. */
    fun probe(): String = try { svc?.probe() ?: "" } catch (_: Throwable) { "" }

    fun proProbe(): String = try { svc?.proProbe() ?: "" } catch (_: Throwable) { "" }

    fun reset() {
        exec.execute { try { svc?.wm("reset") } catch (_: Throwable) {} }
    }

    fun disconnect() {
        exec.execute {
            try {
                val a = args
                val c = conn
                if (a != null && c != null) Shizuku.unbindUserService(a, c, true)
            } catch (_: Throwable) {}
            svc = null
            conn = null
            args = null
        }
    }
}
