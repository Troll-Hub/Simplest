package com.simplehorizon.app

import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** Único juego soportado. */
object Game {
    const val NAME = "Blood Strike"
    const val PKG = "com.netease.newspike"
    const val ACTIVITY = "com.netease.game.MessiahNativeActivity"
}

/**
 * Estiramiento solo horizontal: el lado largo de la pantalla crece (p. ej. 2400×1080 → 2740×1080)
 * y el lado corto no cambia. `wm size` se expresa en la orientación natural del panel.
 */
object Stretch {
    private fun even(v: Int) = v / 2 * 2
    fun clamp(target: Int, nl: Int) = even(target.coerceIn(nl, nl * 2))
    fun default(nl: Int) = clamp(nl * 114 / 100, nl)
    fun pct(target: Int, nl: Int) = if (nl <= 0) 0.0 else (target - nl) * 100.0 / nl

    /** Argumento de `wm size` con el lado largo = target y el corto intacto. */
    fun arg(nw: Int, nh: Int, target: Int): String {
        val t = clamp(target, maxOf(nw, nh))
        return if (nw < nh) "${nw}x$t" else "${t}x$nh"
    }
}

/** Ajustes compartidos entre la pantalla, el menú flotante y el servicio. */
object Cfg {
    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("horizon", Context.MODE_PRIVATE)
    fun nl(p: SharedPreferences) = maxOf(p.getInt("natW", 0), p.getInt("natH", 0))
    fun ns(p: SharedPreferences) = minOf(p.getInt("natW", 0), p.getInt("natH", 0))
    fun on(p: SharedPreferences) = p.getBoolean("on", true)
    fun proj(p: SharedPreferences) = p.getBoolean("proj", true)

    /** Rotación actual de la pantalla (0..3). */
    fun rotation(c: Context): Int = try {
        c.getSystemService(android.hardware.display.DisplayManager::class.java)
            .getDisplay(android.view.Display.DEFAULT_DISPLAY).rotation
    } catch (_: Throwable) { 0 }

    fun target(p: SharedPreferences): Int {
        val n = nl(p)
        if (n == 0) return 0
        val t = p.getInt("tw", 0)
        return if (t == 0) Stretch.default(n) else Stretch.clamp(t, n)
    }

    fun setTarget(p: SharedPreferences, t: Int) {
        val n = nl(p)
        if (n > 0) p.edit().putInt("tw", Stretch.clamp(t, n)).apply()
    }
}

object HorizonBridge {
    private const val REQ = 4243
    private const val VERSION = 10
    enum class State { NOT_RUNNING, NO_PERMISSION, READY, UNSUPPORTED }

    fun state(): State = try {
        when {
            !Shizuku.pingBinder() -> State.NOT_RUNNING
            Shizuku.isPreV11() -> State.UNSUPPORTED
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> State.READY
            else -> State.NO_PERMISSION
        }
    } catch (_: Throwable) {
        State.NOT_RUNNING
    }

    fun requestPermission() {
        try { Shizuku.requestPermission(REQ) } catch (_: Throwable) {}
    }

    fun serviceArgs(ctx: Context): Shizuku.UserServiceArgs =
        Shizuku.UserServiceArgs(ComponentName(ctx.packageName, HorizonService::class.java.name))
            .daemon(false).processNameSuffix("horizon").version(VERSION)
}
