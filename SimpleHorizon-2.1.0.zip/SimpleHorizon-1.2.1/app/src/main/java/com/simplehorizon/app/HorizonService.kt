package com.simplehorizon.app

import android.content.Context
import android.graphics.Rect
import android.os.IBinder
import android.os.Parcel
import java.util.concurrent.TimeUnit

/**
 * Servicio de Shizuku (uid shell). Solo ejecuta `wm size` y vigila que la pantalla nunca se quede estirada:
 *  - destroy(): restaura al cerrarse.
 *  - perro guardián: si la app deja de dar latidos (beat) con el estiramiento activo, restaura.
 *  - Volumen +: restaura al instante (emergencia).
 */
class HorizonService() : IHorizonService.Stub() {
    @Suppress("unused") private var baseCtx: Context? = null
    constructor(context: Context) : this() { baseCtx = context }

    private companion object {
        val WM_ARG = Regex("^(reset|\\d{3,5}x\\d{3,5})?$")
        const val WATCHDOG_MS = 12_000L
    }

    @Volatile private var wmOn = false
    @Volatile private var projActive = false
    private val overridden get() = wmOn || projActive
    private var lastRot = 0
    private var projToken: IBinder? = null
    private var remapProc: Process? = null
    private var remapKey = ""
    @Volatile private var emergencyFlag = false
    @Volatile private var lastBeat = System.currentTimeMillis()
    @Volatile private var started = false
    private var lastEmergency = 0L

    private fun sh(script: String): Pair<Int, String> = try {
        val p = ProcessBuilder("sh", "-c", script).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText().trim()
        if (!p.waitFor(8, TimeUnit.SECONDS)) { p.destroyForcibly(); -1 to out } else p.exitValue() to out
    } catch (_: Exception) {
        -1 to ""
    }

    /** "" = consultar; "reset"; "WxH". Devuelve "ok" o "error: …" al cambiar; el texto de wm al consultar. */
    override fun wm(arg: String): String {
        if (!WM_ARG.matches(arg)) return "error: argumento no válido"
        lastBeat = System.currentTimeMillis()
        if (arg.isEmpty()) return sh("wm size 2>&1").second
        val (code, out) = sh("wm size $arg 2>&1")
        if (code != 0) return "error: " + out.ifEmpty { "código $code" }
        wmOn = arg != "reset"
        return "ok"
    }

    /** Latido de la app. 0 = pantalla original, 1 = estirada, 2 = el usuario pulsó Volumen + (ya restaurado). */
    override fun beat(): Int {
        lastBeat = System.currentTimeMillis()
        if (emergencyFlag) { emergencyFlag = false; return 2 }
        return if (overridden) 1 else 0
    }

    private fun restoreNow() {
        sh("wm size reset")
        wmOn = false
        if (projActive) {
            try { rawRestore(lastRot) } catch (_: Throwable) { stopRemap() }
            projActive = false
        }
    }

    // ---------- Proyección de SurfaceFlinger + remapeo de táctil ----------
    private fun physicalSize(): Pair<Int, Int>? {
        val m = Regex("Physical size: (\\d+)x(\\d+)").find(sh("wm size 2>&1").second) ?: return null
        return m.groupValues[1].toInt() to m.groupValues[2].toInt()
    }

    private fun sfToken(): String {
        if (projToken != null) return "ok"
        val did = Regex("Display (\\d+) \\(HWC").find(sh("dumpsys SurfaceFlinger --display-id 2>&1").second)?.groupValues?.get(1)
            ?: return "ID de pantalla no encontrado"
        val sf = Class.forName("android.os.ServiceManager")
            .getMethod("getService", String::class.java).invoke(null, "SurfaceFlinger") as? IBinder
            ?: return "SurfaceFlinger no encontrado"
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        try {
            data.writeInterfaceToken("android.gui.ISurfaceComposer")
            data.writeLong(did.toLong())
            sf.transact(7, data, reply, 0)
            reply.readException()
            projToken = reply.readStrongBinder() ?: return "token NULL"
            return "ok"
        } finally {
            data.recycle()
            reply.recycle()
        }
    }

    /** layer = región del espacio del juego; display = panel completo; ambos en el espacio ya rotado. */
    private fun setProjection(layer: Rect, display: Rect, rot: Int) {
        val token = projToken ?: throw IllegalStateException("sin token")
        val txCls = Class.forName("android.view.SurfaceControl\$Transaction")
        val tx = txCls.getConstructor().newInstance()
        txCls.getMethod("setDisplayProjection", IBinder::class.java, Int::class.javaPrimitiveType, Rect::class.java, Rect::class.java)
            .invoke(tx, token, rot, layer, display)
        txCls.getMethod("apply").invoke(tx)
    }

    private fun isLandscapeRot(natPortrait: Boolean, rot: Int) = if (natPortrait) rot % 2 == 1 else rot % 2 == 0

    private fun rawRestore(rot: Int) {
        stopRemap()
        val (pw, ph) = physicalSize() ?: return
        val l = maxOf(pw, ph)
        val sd = minOf(pw, ph)
        val (w, h) = if (isLandscapeRot(pw < ph, rot)) l to sd else sd to l
        if (sfToken() == "ok") setProjection(Rect(0, 0, w, h), Rect(0, 0, w, h), rot)
    }

    override fun projectStretch(target: Int, rotation: Int): String = try {
        val rot = rotation and 3
        val (pw, ph) = physicalSize() ?: return "error: tamaño físico no leído"
        val l = maxOf(pw, ph)
        val s = minOf(pw, ph)
        val natp = pw < ph
        if (!isLandscapeRot(natp, rot)) return "error: la pantalla no está en horizontal"
        val t = target.coerceIn(l, l * 2)
        val tk = sfToken()
        if (tk != "ok") return "error: $tk"
        lastBeat = System.currentTimeMillis()
        setProjection(Rect(0, 0, t, s), Rect(0, 0, l, s), rot)
        val r = startRemap(rot, natp, t, l)
        if (r != "ok") {
            try { rawRestore(rot) } catch (_: Throwable) {}
            return "error: táctil: $r"
        }
        projActive = true
        lastRot = rot
        "ok"
    } catch (e: Throwable) {
        try { rawRestore(rotation and 3) } catch (_: Throwable) {}
        "error: ${e.javaClass.simpleName}: ${e.message}"
    }

    override fun projectRestore(rotation: Int): String {
        if (!projActive) return "ok"
        return try {
            rawRestore(rotation and 3)
            projActive = false
            "ok"
        } catch (e: Throwable) {
            projActive = false
            "error: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    private fun helperPath(): String? = baseCtx?.applicationInfo?.nativeLibraryDir?.let { "$it/libtouchremap.so" }

    /** Primer dispositivo con ABS_MT_POSITION_X e INPUT_PROP_DIRECT (el touchscreen). */
    private fun findTouchDev(): String? {
        val script = "for d in /dev/input/event*; do " +
            "if getevent -p \$d 2>/dev/null | grep -q ABS_MT_POSITION_X && " +
            "getevent -p \$d 2>/dev/null | grep -q INPUT_PROP_DIRECT; then echo \$d; break; fi; done"
        return sh(script).second.trim().ifEmpty { null }
    }

    private fun stopRemap() {
        val p = remapProc ?: return
        remapProc = null
        remapKey = ""
        try { p.outputStream.close() } catch (_: Throwable) {}
        try { p.destroy() } catch (_: Throwable) {}
    }

    private fun startRemap(rot: Int, natp: Boolean, num: Int, den: Int): String {
        val key = "$rot/$natp/$num/$den"
        val cur = remapProc
        if (cur != null && cur.isAlive && key == remapKey) return "ok"
        stopRemap()
        val exe = helperPath() ?: return "ruta del helper no encontrada"
        if (!java.io.File(exe).exists()) return "helper no incluido en el APK (libtouchremap.so)"
        val dev = findTouchDev() ?: return "touchscreen no encontrado"
        return try {
            val p = ProcessBuilder(exe, dev, rot.toString(), if (natp) "1" else "0", num.toString(), den.toString())
                .redirectErrorStream(true).start()
            val log = StringBuilder()
            Thread({ try { p.inputStream.bufferedReader().forEachLine { log.append(it).append('\n') } } catch (_: Throwable) {} }, "remap-log")
                .apply { isDaemon = true }.start()
            Thread.sleep(400)
            if (!p.isAlive) "el helper terminó (${p.exitValue()}): ${log.toString().trim()}" else {
                remapProc = p
                remapKey = key
                "ok"
            }
        } catch (e: Throwable) {
            "${e.javaClass.simpleName}: ${e.message}"
        }
    }

    override fun startEmergency(): String {
        if (started) return "ok"
        started = true
        // Perro guardián
        Thread({
            while (true) {
                try { Thread.sleep(2000) } catch (_: InterruptedException) { return@Thread }
                if (overridden && System.currentTimeMillis() - lastBeat > WATCHDOG_MS) restoreNow()
            }
        }, "horizon-watchdog").apply { isDaemon = true }.start()
        // Volumen + (getevent no agarra dispositivos)
        Thread({
            try {
                val p = ProcessBuilder("sh", "-c", "getevent -l 2>&1").redirectErrorStream(true).start()
                p.inputStream.bufferedReader().forEachLine { line ->
                    if (line.contains("KEY_VOLUMEUP") && line.contains("DOWN")) {
                        val now = System.currentTimeMillis()
                        if (now - lastEmergency > 1500) {
                            lastEmergency = now
                            restoreNow()
                            emergencyFlag = true
                        }
                    }
                }
            } catch (_: Throwable) {
            }
        }, "horizon-emergency").apply { isDaemon = true }.start()
        return "ok"
    }

    override fun probe(): String {
        val sb = StringBuilder()
        fun add(t: String, s: String) { sb.append("## ").append(t).append('\n').append(s.trim().take(900)).append("\n\n") }
        add("shell", sh("id").second)
        add("android", sh("getprop ro.build.version.release; getprop ro.build.version.sdk; getprop ro.product.manufacturer; getprop ro.product.model").second)
        add("wm", sh("wm size 2>&1; wm density 2>&1").second)
        add("rotación", sh("dumpsys display 2>&1 | grep -E 'mCurrentOrientation|rotation' | head -4").second)
        add("estado", "wm=$wmOn proyeccion=$projActive rot=$lastRot helper=${helperPath()}")
        return sb.toString()
    }

    override fun destroy() {
        restoreNow()
        System.exit(0)
    }
}
