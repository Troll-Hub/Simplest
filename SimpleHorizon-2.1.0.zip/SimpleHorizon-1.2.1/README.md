# SimpleHorizon 2.1

Estiramiento **solo horizontal** para Blood Strike (`com.netease.newspike`) con `wm size` vía Shizuku.
El lado largo del panel crece y el corto no cambia (2400×1080 → 2740×1080). Solo se aplica con el juego en primer plano
y la pantalla en horizontal; en vertical o al salir del juego se restaura. Menú flotante en tiempo real, tema negro y blanco.
Seguridad: restaura al cerrar, perro guardián en el servicio Shizuku y Volumen + como emergencia.

Método por defecto: proyección de SurfaceFlinger (`setDisplayProjection`) + remapeo de táctil con `libtouchremap.so`
(CMake, grab del touchscreen + uinput). Alternativa: `wm size`. Se cambia desde la app o el menú flotante.
