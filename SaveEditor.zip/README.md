# Save Editor (repo)

1. Sube este repo a GitHub.
2. El workflow se ejecuta al subir un zip a inbox/ o desde Actions > Run workflow.
3. Descarga el artefacto SaveEditor-debug (APK) y ejecútalo con Shizuku activo.
