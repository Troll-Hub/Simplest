package com.simplehorizon.app

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale
import kotlin.math.abs

/**
 * Servicio en primer plano con control flotante, vigilancia del juego y notificación.
 * Control: tocar abre/cierra el panel, arrastrar lo mueve y se pega al borde, se atenúa en reposo,
 * el panel se cierra solo tras unos segundos y se vuelve a colocar si cambia la orientación.
 */
class BubbleService : Service(), StretchBus.Listener {

    companion object {
        @Volatile var running = false
        private const val CHANNEL = "horizon_activo"
        private const val NOTIF_ID = 4242
        private const val ACTION_STOP = "com.simplehorizon.app.STOP"
        private const val WINDOW_MS = 600_000L
        private const val TICK_MS = 1000L
        private const val BUBBLE_DP = 52
        private const val PANEL_W_DP = 264
        private const val FADE_MS = 2500L
        private const val PANEL_IDLE_MS = 6000L

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, BubbleService::class.java))
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("horizon", MODE_PRIVATE) }
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var bl: WindowManager.LayoutParams? = null
    private var panel: LinearLayout? = null
    private var pl: WindowManager.LayoutParams? = null
    private var ratioTxt: TextView? = null
    private var axisBtn: TextView? = null
    private var seek: SeekBar? = null
    private var inGame = false
    private var panelOpen = false
    private var lastW = 0
    private var lastH = 0
    private var anim: ValueAnimator? = null

    private val collapse = Runnable { setPanel(false) }
    private val fade = Runnable { bubble?.animate()?.alpha(0.55f)?.setDuration(300)?.start() }
    private val tick = object : Runnable {
        override fun run() {
            watch()
            updateBubble()
            ensureAttached()
            checkScreen()
            main.postDelayed(this, TICK_MS)
        }
    }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun ratio() = Stretch.clamp(prefs.getInt("r", 150))
    private fun axis() = prefs.getBoolean("axis", true)
    private fun fmt(r: Int) = String.format(Locale.US, "%.2f", r / 100.0)
    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        startForegroundCompat()
        StretchBus.add(this)
        try {
            addViews()
        } catch (_: Throwable) {
            shutdown()
            return
        }
        main.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) shutdown()
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        anim?.cancel()
        StretchBus.remove(this)
        removeViews()
        Stretcher.release(this)
        super.onDestroy()
    }

    override fun onStretchChanged() {
        updateLabels()
        WmController.apply(ratio(), axis())
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    // ---------- Vigilancia del juego ----------
    private fun watch() {
        val pkg = lastForegroundPkg() ?: return
        if (pkg == packageName) return // mientras usas SimpleHorizon no cambia nada
        val g = pkg == Game.PKG
        if (g == inGame) return
        inGame = g
        if (g) {
            WmController.apply(ratio(), axis())
        } else if (prefs.getBoolean("autoRestore", true)) {
            WmController.reset()
        }
    }

    @Suppress("DEPRECATION")
    private fun lastForegroundPkg(): String? {
        val usm = getSystemService(UsageStatsManager::class.java) ?: return null
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(now - WINDOW_MS, now)
        val e = UsageEvents.Event()
        var last: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last = e.packageName
        }
        return last
    }

    private fun updateBubble() {
        val show = inGame && prefs.getBoolean("bubble", true)
        bubble?.visibility = if (show) View.VISIBLE else View.GONE
        if (!show && panelOpen) setPanel(false)
    }

    /** Si el sistema quitó alguna ventana, la vuelve a añadir para que el control no desaparezca. */
    private fun ensureAttached() {
        val b = bubble
        val p = bl
        if (b != null && p != null && !b.isAttachedToWindow) {
            try { wm.addView(b, p) } catch (_: Throwable) {}
        }
        val pn = panel
        val q = pl
        if (pn != null && q != null && !pn.isAttachedToWindow) {
            try { wm.addView(pn, q) } catch (_: Throwable) {}
        }
    }

    /** Al girar la pantalla, vuelve a pegar el control al borde y recoloca el panel. */
    private fun checkScreen() {
        val w = screenW()
        val h = screenH()
        if (w != lastW || h != lastH) {
            lastW = w
            lastH = h
            if (bl != null) snap()
        }
    }

    // ---------- Servicio en primer plano ----------
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "Estiramiento activo", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun startForegroundCompat() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, BubbleService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val eje = if (axis()) "vertical" else "horizontal"
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_crop)
            .setContentTitle("SimpleHorizon activo")
            .setContentText("Estiramiento " + fmt(ratio()) + "× · eje " + eje)
            .setContentIntent(open)
            .addAction(0, "Restaurar", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun shutdown() {
        removeViews()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun removeViews() {
        anim?.cancel()
        listOfNotNull(bubble, panel).forEach { v ->
            try { wm.removeView(v) } catch (_: Throwable) {}
        }
        bubble = null
        panel = null
    }

    // ---------- Vistas ----------
    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    )

    private fun chipRow(vararg items: Pair<String, () -> Unit>): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((t, f) in items) r.addView(Ui.chip(this, t, false) { f(); scheduleCollapse() })
        return r
    }

    private fun addViews() {
        val size = dp(BUBBLE_DP)
        val b = TextView(this).apply {
            textSize = 13f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Ui.BG)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Ui.ACCENT)
                setStroke(dp(2), 0x66FFFFFF)
            }
            elevation = dp(8).toFloat()
        }
        val bLp = lp(size, size).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenW() - size - dp(6)
            y = dp(200)
        }
        b.setOnTouchListener(dragListener(b, bLp))
        wm.addView(b, bLp)
        bubble = b
        bl = bLp

        val rt = Ui.text(this, "", 26f, Ui.TXT, true)
        ratioTxt = rt
        val ax = Ui.chip(this, "", false) { toggleAxis() }
        ax.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { setMargins(0, dp(8), 0, 0) }
        axisBtn = ax

        val sb = SeekBar(this).apply {
            max = Stretch.MAX - Stretch.MIN
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, pr: Int, fromUser: Boolean) {
                    if (fromUser) ratioTxt?.text = fmt(Stretch.MIN + pr) + "×"
                }
                override fun onStartTrackingTouch(s: SeekBar?) { scheduleCollapse() }
                override fun onStopTrackingTouch(s: SeekBar?) { setRatio(Stretch.MIN + (s?.progress ?: 50)) }
            })
        }
        seek = sb

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(rt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }

        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = Ui.round(this@BubbleService, Ui.CARD, 20)
            elevation = dp(10).toFloat()
            visibility = View.GONE
            setOnTouchListener { _, _ -> scheduleCollapse(); false }
            addView(header)
            addView(sb)
            addView(chipRow("−0.01" to { setRatio(ratio() - 1) }, "+0.01" to { setRatio(ratio() + 1) }))
            addView(chipRow("1.00" to { setRatio(100) }, "1.33" to { setRatio(133) },
                "1.50" to { setRatio(150) }, "1.77" to { setRatio(177) }))
            addView(chipRow("1.99" to { setRatio(199) }))
            addView(ax)
            addView(chipRow("Ocultar" to { setPanel(false) }, "Salir" to { shutdown() }))
        }
        val plp = lp(dp(PANEL_W_DP), ViewGroup.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(p, plp)
        panel = p
        pl = plp
        updateLabels()
        scheduleFade()
    }

    private fun dragListener(v: View, p: WindowManager.LayoutParams): View.OnTouchListener {
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        return View.OnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    anim?.cancel()
                    sx = p.x
                    sy = p.y
                    tx = e.rawX
                    ty = e.rawY
                    moved = false
                    v.alpha = 1f
                    main.removeCallbacks(fade)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (!moved && abs(dx) + abs(dy) > dp(6)) moved = true
                    if (moved) {
                        p.x = (sx + dx).coerceIn(0, screenW() - dp(BUBBLE_DP))
                        p.y = (sy + dy).coerceIn(0, screenH() - dp(BUBBLE_DP))
                        wm.updateViewLayout(v, p)
                        placePanel()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) snap() else { setPanel(!panelOpen); scheduleFade() }
                }
                MotionEvent.ACTION_CANCEL -> if (moved) snap()
            }
            true
        }
    }

    /** Pega el control al borde más cercano con una animación corta. */
    private fun snap() {
        val p = bl ?: return
        val b = bubble ?: return
        val size = dp(BUBBLE_DP)
        val margin = dp(6)
        p.y = p.y.coerceIn(0, screenH() - size)
        val target = if (p.x + size / 2 < screenW() / 2) margin else screenW() - size - margin
        anim?.cancel()
        anim = ValueAnimator.ofInt(p.x, target).apply {
            duration = 180
            addUpdateListener {
                p.x = it.animatedValue as Int
                wm.updateViewLayout(b, p)
                placePanel()
            }
            start()
        }
        placePanel()
        scheduleFade()
    }

    /** Coloca el panel junto al control, del mismo lado y sin salirse de la pantalla. */
    private fun placePanel() {
        val pn = panel ?: return
        val p = pl ?: return
        val b = bl ?: return
        val size = dp(BUBBLE_DP)
        val pw = dp(PANEL_W_DP)
        val margin = dp(6)
        val onRight = b.x + size / 2 > screenW() / 2
        p.x = if (onRight) (b.x + size - pw).coerceAtLeast(margin) else b.x.coerceAtMost(screenW() - pw - margin)
        p.y = (b.y + size + dp(8)).coerceIn(dp(40), (screenH() - dp(340)).coerceAtLeast(dp(40)))
        if (pn.isAttachedToWindow) wm.updateViewLayout(pn, p)
    }

    private fun setPanel(open: Boolean) {
        panelOpen = open
        val pn = panel ?: return
        if (open) {
            updateLabels()
            placePanel()
            pn.visibility = View.VISIBLE
            scheduleCollapse()
        } else {
            pn.visibility = View.GONE
            main.removeCallbacks(collapse)
            scheduleFade()
        }
    }

    private fun scheduleCollapse() {
        main.removeCallbacks(collapse)
        if (panelOpen) main.postDelayed(collapse, PANEL_IDLE_MS)
    }

    private fun scheduleFade() {
        bubble?.alpha = 1f
        main.removeCallbacks(fade)
        main.postDelayed(fade, FADE_MS)
    }

    // ---------- Acciones (se guardan y avisan a la ventana y a la notificación) ----------
    private fun setRatio(r: Int) {
        prefs.edit().putInt("r", Stretch.clamp(r)).apply()
        StretchBus.notifyChanged()
    }

    private fun toggleAxis() {
        prefs.edit().putBoolean("axis", !axis()).apply()
        StretchBus.notifyChanged()
    }

    private fun updateLabels() {
        ratioTxt?.text = fmt(ratio()) + "×"
        seek?.progress = ratio() - Stretch.MIN
        axisBtn?.text = if (axis()) "Eje vertical ↕" else "Eje horizontal ↔"
        bubble?.text = fmt(ratio())
    }
}
