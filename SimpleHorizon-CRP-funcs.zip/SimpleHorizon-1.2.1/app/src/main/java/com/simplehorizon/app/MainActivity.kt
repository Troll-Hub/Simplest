package com.simplehorizon.app

import android.app.Activity
import android.app.AlertDialog
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/** Pantalla principal: estado, estiramiento, juego, comportamiento y diagnóstico. */
class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private val main = Handler(Looper.getMainLooper())
    private lateinit var ratioTxt: TextView
    private lateinit var nativeTxt: TextView
    private lateinit var seek: SeekBar
    private lateinit var shizukuTxt: TextView
    private lateinit var permTxt: TextView
    private lateinit var gameTxt: TextView
    private lateinit var axisVert: TextView
    private lateinit var axisHorz: TextView
    private lateinit var applyBtn: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("horizon", MODE_PRIVATE)
        WmController.projMode = prefs.getBoolean("proj", false)
        Stretcher.restore(this)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun ratio() = Stretch.clamp(prefs.getInt("r", 150))
    private fun vertical() = prefs.getBoolean("axis", true)
    private fun fmt(r: Int) = String.format(Locale.US, "%.2f×", r / 100.0)

    private fun setRatio(r: Int) {
        prefs.edit().putInt("r", Stretch.clamp(r)).apply()
        StretchBus.notifyChanged()
        refresh()
    }

    private fun setAxis(v: Boolean) {
        prefs.edit().putBoolean("axis", v).apply()
        StretchBus.notifyChanged()
        refresh()
    }

    private fun buildUi(): View {
        val c = this
        val scroll = ScrollView(c).apply { setBackgroundColor(Ui.BG) }
        val col = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, Ui.dp(c, 24), 0, Ui.dp(c, 32))
        }
        scroll.addView(col)

        col.addView(Ui.text(c, "SimpleHorizon", 26f, Ui.TXT, true).apply {
            setPadding(Ui.dp(c, 20), 0, Ui.dp(c, 20), 0)
        })
        col.addView(Ui.text(c, "Estiramiento para ${Game.NAME}", 13f, Ui.MUTED).apply {
            setPadding(Ui.dp(c, 20), Ui.dp(c, 2), Ui.dp(c, 20), Ui.dp(c, 8))
        })

        // Estado del sistema
        val st = Ui.card(c)
        shizukuTxt = Ui.text(c, "", 14f, Ui.TXT, true)
        shizukuTxt.setOnClickListener {
            if (HorizonBridge.state() == HorizonBridge.State.NO_PERMISSION) HorizonBridge.requestPermission()
            refresh()
        }
        st.addView(shizukuTxt)
        permTxt = Ui.text(c, "", 12f, Ui.MUTED)
        st.addView(permTxt)
        st.addView(Ui.button(c, "Revisar permisos", false) { Permisos.listo(c); refresh() })
        col.addView(st)

        // Estiramiento
        val es = Ui.card(c)
        es.addView(Ui.text(c, "ESTIRAMIENTO", 12f, Ui.MUTED, true))
        ratioTxt = Ui.text(c, "", 44f, Ui.TXT, true)
        es.addView(ratioTxt)
        nativeTxt = Ui.text(c, "", 12f, Ui.MUTED)
        es.addView(nativeTxt)
        seek = SeekBar(c).apply {
            max = Stretch.MAX - Stretch.MIN
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) ratioTxt.text = fmt(Stretch.MIN + p)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { setRatio(Stretch.MIN + seek.progress) }
            })
        }
        es.addView(seek)
        es.addView(chipRow("1.00" to { setRatio(100) }, "1.25" to { setRatio(125) }, "1.33" to { setRatio(133) }))
        es.addView(chipRow("1.50" to { setRatio(150) }, "1.77" to { setRatio(177) }, "1.99" to { setRatio(199) }))
        val axes = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        axisVert = Ui.chip(c, "Vertical ↕", false) { setAxis(true) }
        axisHorz = Ui.chip(c, "Horizontal ↔", false) { setAxis(false) }
        axes.addView(axisVert)
        axes.addView(axisHorz)
        es.addView(axes)
        col.addView(es)

        // Juego
        val jg = Ui.card(c)
        jg.addView(Ui.text(c, "JUEGO", 12f, Ui.MUTED, true))
        gameTxt = Ui.text(c, "", 14f, Ui.TXT)
        jg.addView(gameTxt)
        applyBtn = Ui.button(c, "APLICAR Y ABRIR JUEGO", true) { Stretcher.start(c) }
        jg.addView(applyBtn)
        jg.addView(Ui.button(c, "Restaurar tamaño y cerrar control", false) {
            Stretcher.stop(c)
            main.postDelayed({ refresh() }, 600)
        })
        col.addView(jg)

        // Comportamiento
        val cf = Ui.card(c)
        cf.addView(Ui.text(c, "COMPORTAMIENTO", 12f, Ui.MUTED, true))
        cf.addView(switchRow("Control flotante durante la partida", "bubble"))
        cf.addView(switchRow("Restaurar tamaño al salir del juego", "autoRestore"))
        cf.addView(Ui.text(c, "Al volver al juego se vuelve a aplicar el estiramiento.", 12f, Ui.MUTED))
        cf.addView(Switch(c).apply {
            text = "Modo Pro experimental (proyección, sin tocar el táctil)"
            textSize = 13f
            setTextColor(Ui.TXT)
            setPadding(0, Ui.dp(c, 10), 0, Ui.dp(c, 10))
            isChecked = prefs.getBoolean("proj", false)
            setOnCheckedChangeListener { _, on ->
                WmController.reset()
                prefs.edit().putBoolean("proj", on).apply()
                WmController.projMode = on
                StretchBus.notifyChanged()
                refresh()
            }
        })
        cf.addView(Ui.text(c, "Experimental: los toques se desalinean mientras esté activo. Desactivado por defecto.", 11f, Ui.MUTED))
        cf.addView(Ui.text(c, "Emergencia: pulsa Volumen + para restaurar la pantalla al instante.", 12f, Ui.ACCENT, true))
        col.addView(cf)

        // Diagnóstico
        val dg = Ui.card(c)
        dg.addView(Ui.button(c, "Diagnóstico del sistema", false) { diagnostics() })
        dg.addView(Ui.button(c, "Diagnóstico Pro (solo lectura)", false) { proDiagnostics() })
        col.addView(dg)

        col.addView(Ui.text(c, "Cambia el tamaño físico con wm size (Shizuku), sin pantalla virtual.", 11f, Ui.MUTED).apply {
            setPadding(Ui.dp(c, 20), Ui.dp(c, 16), Ui.dp(c, 20), 0)
        })
        return scroll
    }

    private fun chipRow(vararg items: Pair<String, () -> Unit>): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((t, f) in items) r.addView(Ui.chip(this, t, false, f))
        return r
    }

    private fun switchRow(title: String, key: String): Switch {
        val pad = Ui.dp(this, 10)
        return Switch(this).apply {
            text = title
            textSize = 14f
            setTextColor(Ui.TXT)
            setPadding(0, pad, 0, pad)
            isChecked = prefs.getBoolean(key, true)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(key, on).apply() }
        }
    }

    private fun diagnostics() {
        val app = applicationContext
        Thread({
            val ok = WmController.connect(app)
            val text = if (ok) WmController.probe() else "Shizuku no está conectado."
            if (!BubbleService.running) WmController.disconnect()
            main.post {
                AlertDialog.Builder(this)
                    .setTitle("Diagnóstico")
                    .setMessage(text)
                    .setPositiveButton("OK", null)
                    .show()
            }
        }, "diagnostics").start()
    }

    private fun proDiagnostics() {
        Toast.makeText(this, "Toca la pantalla durante 4 s…", Toast.LENGTH_LONG).show()
        val app = applicationContext
        Thread({
            val ok = WmController.connect(app)
            val text = if (ok) WmController.proProbe() else "Shizuku no está conectado."
            if (!BubbleService.running) WmController.disconnect()
            main.post { showCopyable("Diagnóstico Pro", text) }
        }, "pro-diag").start()
    }

    /** Muestra el texto seleccionable y con botón para copiar todo al portapapeles. */
    private fun showCopyable(title: String, text: String) {
        val c = this
        val body = TextView(c).apply {
            this.text = text
            textSize = 11f
            setTextColor(Ui.TXT)
            setTextIsSelectable(true)
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(Ui.dp(c, 16), Ui.dp(c, 8), Ui.dp(c, 16), Ui.dp(c, 8))
        }
        val scroll = ScrollView(c).apply { addView(body) }
        val dialog = AlertDialog.Builder(c)
            .setTitle(title)
            .setView(scroll)
            .setPositiveButton("Cerrar", null)
            .setNeutralButton("Copiar todo", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val cm = getSystemService(android.content.ClipboardManager::class.java)
                cm.setPrimaryClip(android.content.ClipData.newPlainText(title, text))
                Toast.makeText(c, "Copiado", Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()
    }

    private fun refresh() {
        val c = this
        val r = ratio()
        ratioTxt.text = fmt(r)
        if (seek.progress != r - Stretch.MIN) seek.progress = r - Stretch.MIN
        Ui.paintChip(c, axisVert, vertical())
        Ui.paintChip(c, axisHorz, !vertical())

        val size = WmController.nativeSize()
        nativeTxt.text = (if (size != null) {
            "Panel ${size.first}×${size.second} · " + if (BubbleService.running) "aplicado" else "sin aplicar"
        } else {
            "Panel: se detecta al aplicar"
        }) + (if (WmController.lastError.isNotEmpty()) "\nError: ${WmController.lastError}" else "")

        val (sTxt, sCol) = when (HorizonBridge.state()) {
            HorizonBridge.State.READY -> "Shizuku listo" to Ui.OK
            HorizonBridge.State.NO_PERMISSION -> "Shizuku sin permiso · toca para conceder" to Ui.ACCENT
            HorizonBridge.State.NOT_RUNNING -> "Shizuku no está activo" to Ui.BAD
            HorizonBridge.State.UNSUPPORTED -> "Versión de Shizuku no compatible" to Ui.BAD
        }
        shizukuTxt.text = sTxt
        shizukuTxt.setTextColor(sCol)

        permTxt.text = "Superposición ${ok(Permisos.overlay(c))} · Notificaciones ${ok(Permisos.notif(c))} · " +
            "Uso de apps ${ok(Permisos.uso(c))} · Batería ${ok(Permisos.bateria(c))}"
        gameTxt.text = if (Permisos.instalado(c)) "${Game.NAME} instalado" else "${Game.NAME} no está instalado"
        applyBtn.text = if (BubbleService.running) "REAPLICAR Y ABRIR JUEGO" else "APLICAR Y ABRIR JUEGO"
    }

    private fun ok(b: Boolean) = if (b) "✓" else "✗"
}
