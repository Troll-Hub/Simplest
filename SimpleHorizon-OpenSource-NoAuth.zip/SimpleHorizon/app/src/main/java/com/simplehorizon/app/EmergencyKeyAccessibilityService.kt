package com.simplehorizon.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class EmergencyKeyAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
