package com.simplehorizon.app

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.edit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CrpTheme {
                Surface(Modifier.fillMaxSize(), color = Color(0xFF0A0A0A)) {
                    CrpMainScreen()
                }
            }
        }
    }
}

private val Orange = Color(0xFFFF6B00)
private val OrangeDim = Color(0xFFCC5500)
private val CardBg = Color(0xFF141414)
private val SurfaceBg = Color(0xFF1C1C1C)

@Composable
fun CrpTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Orange,
            secondary = Color(0xFFFF9A3C),
            background = Color(0xFF0A0A0A),
            surface = SurfaceBg,
            onPrimary = Color.Black,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}

@Composable
fun CrpMainScreen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("horizon", Context.MODE_PRIVATE) }
    var ratio by remember { mutableIntStateOf(prefs.getInt("r", 129)) }
    var vertical by remember { mutableStateOf(prefs.getBoolean("axis", true)) }
    var projMode by remember { mutableStateOf(prefs.getBoolean("proj", true)) }
    var status by remember { mutableStateOf("Pronto") }
    var applied by remember { mutableStateOf(prefs.getBoolean("applied", false)) }
    var tab by remember { mutableIntStateOf(0) } // 0=main 1=diag 2=info
    var diagText by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val shizuku = HorizonBridge.state()

    Column(Modifier.fillMaxSize()) {
        // Top bar
        Row(
            Modifier.fillMaxWidth().background(Color(0xFF0F0F0F)).padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("SIMPLE HORIZON", fontWeight = FontWeight.Black, fontSize = 18.sp, color = Orange)
            Text(" PRO", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
            Spacer(Modifier.weight(1f))
            Text(
                when (shizuku) {
                    HorizonBridge.State.READY -> "Shizuku OK"
                    HorizonBridge.State.NO_PERMISSION -> "Sem permissão"
                    HorizonBridge.State.NOT_RUNNING -> "Shizuku off"
                    else -> "N/A"
                },
                fontSize = 11.sp,
                color = if (shizuku == HorizonBridge.State.READY) Color(0xFF4CAF50) else Color(0xFFFF5252)
            )
        }

        // Tabs
        TabRow(selectedTabIndex = tab, containerColor = Color(0xFF0F0F0F), contentColor = Orange) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Esticar") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Diagnóstico") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Info") })
        }

        when (tab) {
            0 -> Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(8.dp))
                // Big ratio display
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Brush.verticalGradient(listOf(Color(0xFF1A120A), CardBg)))
                        .border(1.dp, Orange.copy(0.3f), RoundedCornerShape(20.dp))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("FATOR", fontSize = 12.sp, color = Color(0xFF888888), letterSpacing = 2.sp)
                        Text(
                            "%.2f".format(ratio / 100f),
                            fontSize = 64.sp,
                            fontWeight = FontWeight.Black,
                            color = Orange
                        )
                        Text(if (vertical) "EIXO VERTICAL" else "EIXO HORIZONTAL", fontSize = 12.sp, color = Color(0xFFAAAAAA))
                    }
                }

                Spacer(Modifier.height(16.dp))
                Slider(
                    value = ratio.toFloat(),
                    onValueChange = { ratio = it.toInt() },
                    valueRange = 100f..199f,
                    steps = 98,
                    colors = SliderDefaults.colors(thumbColor = Orange, activeTrackColor = Orange, inactiveTrackColor = Color(0xFF333333))
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    listOf(100 to "1.00", 120 to "1.20", 129 to "1.29", 150 to "1.50", 180 to "1.80").forEach { (v, label) ->
                        Text(
                            label,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (ratio == v) Orange else Color(0xFF222222))
                                .clickable { ratio = v }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            fontSize = 12.sp,
                            color = if (ratio == v) Color.Black else Color(0xFFCCCCCC),
                            fontWeight = if (ratio == v) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }

                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AxisChip("Vertical", vertical) { vertical = true }
                    AxisChip("Horizontal", !vertical) { vertical = false }
                }

                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Modo Pro", fontWeight = FontWeight.SemiBold, color = Color.White)
                        Text("SurfaceFlinger · projeção", fontSize = 11.sp, color = Color(0xFF777777))
                    }
                    Switch(checked = projMode, onCheckedChange = { projMode = it },
                        colors = SwitchDefaults.colors(checkedTrackColor = Orange, checkedThumbColor = Color.White))
                }

                Spacer(Modifier.height(24.dp))

                Button(
                    onClick = {
                        if (busy) return@Button
                        if (!Permisos.listo(ctx as ComponentActivity)) return@Button
                        busy = true
                        status = "Conectando Shizuku…"
                        Thread {
                            val ok = WmController.connect(ctx)
                            (ctx as ComponentActivity).runOnUiThread {
                                busy = false
                                if (!ok) {
                                    status = "Shizuku não está pronto"
                                    Toast.makeText(ctx, "Abra o Shizuku e conceda permissão", Toast.LENGTH_LONG).show()
                                    return@runOnUiThread
                                }
                                prefs.edit {
                                    putInt("r", ratio)
                                    putBoolean("axis", vertical)
                                    putBoolean("proj", projMode)
                                    putBoolean("applied", true)
                                }
                                WmController.projMode = projMode
                                WmController.apply(ratio, vertical)
                                FloatingControlService.start(ctx)
                                applied = true
                                status = "Aplicado · ${"%.2f".format(ratio / 100f)} · ${if (projMode) "PRO" else "wm"}"
                            }
                        }.start()
                    },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Orange, disabledContainerColor = OrangeDim)
                ) {
                    if (busy) CircularProgressIndicator(Modifier.size(22.dp), color = Color.Black, strokeWidth = 2.dp)
                    else {
                        Icon(Icons.Default.PlayArrow, null, tint = Color.Black)
                        Spacer(Modifier.width(8.dp))
                        Text("APLICAR", fontWeight = FontWeight.Black, fontSize = 16.sp, color = Color.Black)
                    }
                }

                Spacer(Modifier.height(10.dp))
                OutlinedButton(
                    onClick = {
                        FloatingControlService.stop(ctx)
                        WmController.reset()
                        WmController.disconnect()
                        prefs.edit { putBoolean("applied", false) }
                        applied = false
                        status = "Restaurado"
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Orange),
                    border = ButtonDefaults.outlinedButtonBorder.copy(width = 1.dp)
                ) {
                    Icon(Icons.Default.Refresh, null)
                    Spacer(Modifier.width(8.dp))
                    Text("RESTAURAR", fontWeight = FontWeight.Bold)
                }

                Spacer(Modifier.height(16.dp))
                Text(status, color = Color(0xFF999999), fontSize = 13.sp, textAlign = TextAlign.Center)
                if (applied) {
                    Text("Controle flutuante ativo · VOLUME + restaura", color = Color(0xFF4CAF50), fontSize = 12.sp, textAlign = TextAlign.Center)
                }
                Spacer(Modifier.height(24.dp))
            }
            1 -> Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
                Text("Diagnóstico do sistema", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Orange)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        busy = true
                        Thread {
                            val t = if (WmController.connect(ctx)) WmController.probe() else "Sem conexão Shizuku"
                            (ctx as ComponentActivity).runOnUiThread { diagText = t; busy = false }
                        }.start()
                    }, colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Text("Probe", color = Color.Black) }
                    Button(onClick = {
                        busy = true
                        Thread {
                            val t = if (WmController.connect(ctx)) WmController.proProbe() else "Sem conexão Shizuku"
                            (ctx as ComponentActivity).runOnUiThread { diagText = t; busy = false }
                        }.start()
                    }, colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Text("Pro Probe", color = Color.Black) }
                }
                Spacer(Modifier.height(12.dp))
                if (busy) CircularProgressIndicator(color = Orange)
                if (diagText.isNotEmpty()) {
                    Text(diagText, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color(0xFFCCCCCC),
                        modifier = Modifier.fillMaxWidth().background(Color(0xFF111111), RoundedCornerShape(8.dp)).padding(10.dp))
                }
            }
            2 -> Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState())) {
                Text("SimpleHorizon — Open Source", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Orange)
                Spacer(Modifier.height(12.dp))
                Text(
                    "Clone open-source das funções principais do SimpleHorizon:\n\n" +
                    "• Modo Pro (SurfaceFlinger setDisplayProjection)\n" +
                    "• wm size clássico\n" +
                    "• Token físico (getPhysicalDisplayToken + transact 7)\n" +
                    "• Controle flutuante\n" +
                    "• Emergência VOLUME +\n" +
                    "• Diagnóstico completo\n\n" +
                    "Sem login, sem servidor, sem binários fechados.\n" +
                    "100% código aberto.\n\n" +
                    "Requer Shizuku ativo.",
                    color = Color(0xFFCCCCCC), fontSize = 13.sp, lineHeight = 20.sp
                )
            }
        }
    }
}

@Composable
private fun AxisChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) Orange else Color(0xFF222222))
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp)
            .widthIn(min = 120.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (selected) Color.Black else Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}
