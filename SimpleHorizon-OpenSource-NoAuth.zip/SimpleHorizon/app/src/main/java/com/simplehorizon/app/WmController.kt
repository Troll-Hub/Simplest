package com.simplehorizon.app

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.os.IBinder
import rikka.shizuku.Shizuku
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

object WmController {
    private val exec = Executors.newSingleThreadExecutor()
    @Volatile private var svc: IPrivilegedStretchService? = null
    private var args: Shizuku.UserServiceArgs? = null
    private var conn: ServiceConnection? = null
    @Volatile private var nativeW = 0
    @Volatile private var nativeH = 0
    @Volatile var projMode = true
    @Volatile var lastError = ""

    fun connect(ctx: Context): Boolean {
        if (svc != null) return true
        if (HorizonBridge.state() != HorizonBridge.State.READY) return false
        val latch = CountDownLatch(1)
        val c = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                svc = if (binder != null && binder.pingBinder()) IPrivilegedStretchService.Stub.asInterface(binder) else null
                latch.countDown()
            }
            override fun onServiceDisconnected(name: ComponentName?) { svc = null }
        }
        val a = HorizonBridge.serviceArgs(ctx)
        args = a
        conn = c
        try { Shizuku.bindUserService(a, c) } catch (_: Throwable) { return false }
        latch.await(12, TimeUnit.SECONDS)
        if (svc == null) return false
        try { svc?.startEmergency() } catch (_: Throwable) {}
        return readNative()
    }

    private fun readNative(): Boolean {
        val out = try { svc?.wm("") ?: "" } catch (_: Throwable) { "" }
        val m = Regex("Physical size: (\\d+)x(\\d+)").find(out) ?: return false
        nativeW = m.groupValues[1].toInt()
        nativeH = m.groupValues[2].toInt()
        return true
    }

    fun nativeSize(): Pair<Int, Int>? = if (nativeW > 0) nativeW to nativeH else null

    fun apply(ratio: Int, vertical: Boolean) {
        exec.execute {
            val s = svc ?: return@execute
            val p = Stretch.clamp(ratio)
            if (projMode) {
                val r = try { s.projectStretch(p, vertical) } catch (e: Throwable) { "error: ${e.message}" }
                lastError = if (r == "ok") "" else r ?: ""
                return@execute
            }
            if (nativeW == 0 && !readNative()) return@execute
            fun cut(v: Int) = ((v * 100 / p) / 2 * 2).coerceAtLeast(64)
            val arg = when {
                p == 100 -> "reset"
                vertical -> "${cut(nativeW)}x$nativeH"
                else -> "${nativeW}x${cut(nativeH)}"
            }
            try { s.wm(arg) } catch (_: Throwable) {}
        }
    }

    fun reset() {
        exec.execute {
            try { svc?.wm("reset") } catch (_: Throwable) {}
            try { svc?.projectRestore() } catch (_: Throwable) {}
            lastError = ""
        }
    }

    fun probe(): String = try { svc?.probe() ?: "" } catch (_: Throwable) { "" }
    fun proProbe(): String = try { svc?.proProbe() ?: "" } catch (_: Throwable) { "" }

    fun disconnect() {
        exec.execute {
            try {
                val a = args
                val c = conn
                if (a != null && c != null) Shizuku.unbindUserService(a, c, true)
            } catch (_: Throwable) {}
            svc = null
            conn = null
            args = null
        }
    }
}
