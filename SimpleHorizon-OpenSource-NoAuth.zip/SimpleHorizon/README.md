# SimpleHorizon

Clone open-source de las funciones principales de Cat Resolution Pro.

- Sin login
- Sin verificación de firma
- Sin servicios de actualización
- 100% código abierto
- Nombre: SimpleHorizon (package com.simplehorizon.app)

## Características
- UI Compose (tema oscuro + naranja)
- Modo Pro (SurfaceFlinger setDisplayProjection)
- wm size clásico
- Token físico (getPhysicalDisplayToken + fallback transact 7)
- Control flotante (APLICAR, ±0.10, eje, cerrar)
- Emergencia VOLUME +
- Diagnóstico y Pro Probe
- Tabs: Esticar / Diagnóstico / Info

## Requisitos
- Shizuku activo
- Permiso de superposición
- minSdk 26

## Build
```bash
./gradlew assembleDebug
```

## GitHub Actions
`.github/workflows/build.yml` genera el APK debug automáticamente en cada push.
