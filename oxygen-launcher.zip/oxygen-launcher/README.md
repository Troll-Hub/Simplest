# Oxygen Launcher

Launcher Android nativo inspirado en OxygenOS. Está hecho con Kotlin, layouts XML y ViewBinding; no usa Jetpack Compose. El proyecto incluye pantalla de inicio configurable, cajón de aplicaciones, carpetas, accesos rápidos, búsqueda, índice alfabético, packs de iconos compatibles, fondo local, ajustes persistentes y gestos opcionales.

## Requisitos

- Android Studio Ladybug (2024.2.1) o posterior, o el wrapper incluido
- JDK 17
- Android SDK Platform 35 y Build Tools 35.0.0
- Dispositivo o emulador con Android 8.0 (API 26) o posterior

El APK resultante tiene `minSdk 26` y `targetSdk 34`.

## Compilar

Abre `oxygen-launcher/` en Android Studio y espera a que termine la sincronización de Gradle. Para compilar desde la terminal, desde esta carpeta:

```sh
./gradlew assembleDebug
```

El APK se genera en `app/build/outputs/apk/debug/app-debug.apk`. También puedes abrir el proyecto desde Android Studio y ejecutar la configuración `app`.

### Compilar desde el ZIP

El script `build-from-zip.sh` incluido junto al proyecto extrae el archivo fuente en una carpeta temporal, compila el APK y lo copia a `dist/app-debug.apk` (o al directorio que indiques). Desde la carpeta que contiene el script y el ZIP:

```sh
./build-from-zip.sh oxygen-launcher-source.zip
```

El script requiere JDK 17, Android SDK Platform 35, Build Tools 35.0.0 y `unzip`; informa claramente si falta algún requisito.

## Elegirlo como launcher

Instala el APK, pulsa el botón Inicio y elige **Oxygen Launcher** como aplicación de inicio. La actividad declara las categorías `HOME` y `DEFAULT`. Si el dispositivo no ofrece el selector, ve a Ajustes de Android → Aplicaciones → Aplicaciones predeterminadas → Aplicación de inicio.

## Permisos opcionales de Android

- **Puntos de notificación:** activa el acceso a notificaciones desde Ajustes del launcher. Solo se conserva el conjunto de paquetes que tienen notificaciones activas; no se leen ni almacenan el texto, el emisor ni el contenido.
- **Doble toque para bloquear:** Android requiere activar el administrador del dispositivo para poder bloquear la pantalla. La app solicita esta activación al usar el gesto por primera vez. Para desinstalarla, desactiva primero el administrador desde los ajustes de seguridad de Android si el sistema lo solicita.
- **Deslizar hacia abajo para notificaciones:** Android reserva la apertura del panel de notificaciones para accesibilidad o componentes del sistema. Si activas este gesto, Android pedirá habilitar el servicio de accesibilidad del launcher. El servicio solo ejecuta la acción de mostrar el panel; no inspecciona ventanas ni captura entradas.
- **Fondo:** se elige una imagen local mediante el selector de documentos de Android. El launcher conserva el permiso de lectura para mostrarla.

Los permisos especiales se conceden en pantallas del sistema y son optativos. Sin ellos, las demás funciones siguen disponibles.

## Funciones incluidas

- Grid de inicio con columnas y filas configurables, iconos redimensionables y dock persistente.
- Agregar/quitar aplicaciones del inicio y del dock; crear carpetas desde el menú contextual de una app del inicio.
- Cajón inferior deslizable con búsqueda, orden alfabético e índice lateral.
- Menú contextual para agregar, mover, ocultar, abrir información o desinstalar una aplicación.
- Packs de iconos que exponen `appfilter.xml` y un intent de tema ADW/Nova; la disponibilidad depende del pack instalado.
- Máscaras círculo, cuadrado, redondeado y squircle; modo claro, oscuro o del sistema.
- Actualización de la lista tras instalar o desinstalar apps; caché de iconos en memoria.
- MotionLayout para la transición del panel y SpringAnimation para la respuesta de gestos. Se respeta la escala de animación del sistema.

## Contribuir

1. Crea una rama desde `main`.
2. Mantén las pantallas Android clásicas en XML y ViewBinding; no introduzcas Compose.
3. Conserva API 26 como mínimo y `targetSdk 34`, salvo que el cambio requiera documentar una actualización.
4. Ejecuta `./gradlew assembleDebug` y prueba en un emulador con Android 8+ antes de abrir un pull request.
5. Describe los permisos especiales, los cambios de privacidad y las limitaciones del dispositivo en el pull request.

Las contribuciones se publican bajo Apache License 2.0.
