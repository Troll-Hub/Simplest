package com.oxygen.launcher.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.util.LruCache
import androidx.preference.PreferenceManager
import com.oxygen.launcher.settings.LauncherPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class LauncherRepository(context: Context) {
    private val appContext = context.applicationContext
    private val packageManager = appContext.packageManager
    private val preferences: SharedPreferences =
        PreferenceManager.getDefaultSharedPreferences(appContext)
    private val iconPacks = IconPackRepository(appContext)
    private val iconCache = LruCache<String, Drawable>(240)

    suspend fun loadApps(): List<AppEntry> = withContext(Dispatchers.IO) {
        val launchIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val activities = packageManager.queryIntentActivities(launchIntent, 0)

        activities
            .asSequence()
            .filter { it.activityInfo.packageName != appContext.packageName }
            .distinctBy { it.activityInfo.packageName }
            .mapNotNull { resolveInfo ->
                val activityInfo = resolveInfo.activityInfo
                val packageName = activityInfo.packageName
                try {
                    val label = resolveInfo.loadLabel(packageManager)?.toString()
                        ?: packageName.substringAfterLast('.')
                    AppEntry(
                        packageName = packageName,
                        activityName = activityInfo.name,
                        label = label,
                        icon = loadIcon(packageName, activityInfo.name)
                    )
                } catch (_: PackageManager.NameNotFoundException) {
                    null
                } catch (_: RuntimeException) {
                    null
                }
            }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    fun ensureDefaultLayout(apps: List<AppEntry>) {
        if (preferences.contains(LauncherPreferences.HOME_APPS)) return
        val packages = apps.map(AppEntry::packageName)
        preferences.edit()
            .putString(LauncherPreferences.HOME_APPS, JSONArray(packages.drop(5).take(12)).toString())
            .putString(LauncherPreferences.DOCK_APPS, JSONArray(packages.take(5)).toString())
            .apply()
    }

    fun homeItems(apps: List<AppEntry>): List<HomeItem> {
        val byPackage = apps.associateBy(AppEntry::packageName)
        val pinned = readStringList(LauncherPreferences.HOME_APPS).ifEmpty {
            apps.take(12).map(AppEntry::packageName)
        }
        val folders = readFolders()
        val packagesInFolders = folders.values.flatMap { it.packages }.toSet()
        val folderAt = folders.entries.associateBy { it.value.packages.firstOrNull() }
        val emittedFolders = mutableSetOf<String>()

        return pinned.mapNotNull { packageName ->
            val folderEntry = folderAt[packageName]
            if (folderEntry != null) {
                if (!emittedFolders.add(folderEntry.key)) return@mapNotNull null
                val folderApps = folderEntry.value.packages.mapNotNull(byPackage::get)
                if (folderApps.isEmpty()) null
                else HomeItem.Folder(
                    id = "folder:${folderEntry.key}",
                    name = folderEntry.value.name,
                    apps = folderApps
                )
            } else if (packageName in packagesInFolders) {
                null
            } else {
                byPackage[packageName]?.let { HomeItem.App(it) }
            }
        }
    }

    fun dockApps(apps: List<AppEntry>): List<AppEntry> {
        val byPackage = apps.associateBy(AppEntry::packageName)
        return readStringList(LauncherPreferences.DOCK_APPS).mapNotNull(byPackage::get)
    }

    fun hiddenPackages(): Set<String> =
        preferences.getStringSet(LauncherPreferences.HIDDEN_APPS, emptySet())?.toSet() ?: emptySet()

    fun addToHome(packageName: String) = updatePackageList(LauncherPreferences.HOME_APPS, packageName, true)

    fun removeFromHome(packageName: String) =
        updatePackageList(LauncherPreferences.HOME_APPS, packageName, false)

    fun addToDock(packageName: String) = updatePackageList(LauncherPreferences.DOCK_APPS, packageName, true)

    fun removeFromDock(packageName: String) =
        updatePackageList(LauncherPreferences.DOCK_APPS, packageName, false)

    fun toggleHidden(packageName: String) {
        val hidden = hiddenPackages().toMutableSet()
        if (hidden.add(packageName)) {
            removeFromHome(packageName)
            removeFromDock(packageName)
            removeAppFromFolders(packageName)
        } else {
            hidden.remove(packageName)
        }
        preferences.edit().putStringSet(LauncherPreferences.HIDDEN_APPS, hidden).apply()
    }

    fun createFolder(name: String, firstPackage: String, secondPackage: String) {
        if (firstPackage == secondPackage) return
        val pinned = readStringList(LauncherPreferences.HOME_APPS).toMutableList()
        if (firstPackage !in pinned) pinned.add(firstPackage)
        if (secondPackage !in pinned) pinned.add(secondPackage)
        val folders = readFolders().toMutableMap()
        folders.entries.removeAll { (_, folder) ->
            firstPackage in folder.packages || secondPackage in folder.packages
        }
        folders[firstPackage] = FolderRecord(
            name = name.ifBlank { "Carpeta" },
            packages = listOf(firstPackage, secondPackage)
        )
        saveStringList(LauncherPreferences.HOME_APPS, pinned)
        saveFolders(folders)
    }

    fun removeAppFromFolders(packageName: String) {
        val folders = readFolders().toMutableMap()
        folders.entries.toList().forEach { (key, folder) ->
            val remaining = folder.packages.filterNot { it == packageName }
            if (remaining.size < 2) folders.remove(key)
            else folders[key] = folder.copy(packages = remaining)
        }
        saveFolders(folders)
    }

    fun dissolveFolder(anchorPackage: String) {
        val folders = readFolders().toMutableMap()
        folders.remove(anchorPackage)
        saveFolders(folders)
    }

    fun invalidateIcons() = iconCache.evictAll()

    private fun loadIcon(packageName: String, activityName: String): Drawable {
        val pack = preferences.getString(LauncherPreferences.ICON_PACK, "system") ?: "system"
        val cacheKey = "$pack|$packageName|$activityName"
        iconCache.get(cacheKey)?.let { return copyDrawable(it) }

        val themed = if (pack != "system") {
            iconPacks.loadIcon(pack, packageName, activityName)
        } else null
        val base = themed ?: packageManager.getActivityIcon(
            ComponentName(packageName, activityName)
        )
        iconCache.put(cacheKey, base)
        return copyDrawable(base)
    }

    private fun copyDrawable(drawable: Drawable): Drawable =
        drawable.constantState?.newDrawable(appContext.resources)?.mutate() ?: drawable.mutate()

    private fun updatePackageList(key: String, packageName: String, add: Boolean) {
        val values = readStringList(key).toMutableList()
        if (add && packageName !in values) values.add(packageName)
        if (!add) values.remove(packageName)
        saveStringList(key, values)
    }

    private fun readStringList(key: String): List<String> = runCatching {
        val json = preferences.getString(key, null) ?: return emptyList()
        val array = JSONArray(json)
        List(array.length()) { index -> array.getString(index) }
    }.getOrDefault(emptyList())

    private fun saveStringList(key: String, values: List<String>) {
        preferences.edit().putString(key, JSONArray(values).toString()).apply()
    }

    private fun readFolders(): Map<String, FolderRecord> = runCatching {
        val array = JSONArray(preferences.getString(LauncherPreferences.FOLDERS, "[]"))
        buildMap {
            for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                val packages = item.getJSONArray("packages")
                val members = List(packages.length()) { packages.getString(it) }
                if (members.size >= 2) {
                    put(item.getString("anchor"), FolderRecord(item.getString("name"), members))
                }
            }
        }
    }.getOrDefault(emptyMap())

    private fun saveFolders(folders: Map<String, FolderRecord>) {
        val array = JSONArray()
        folders.forEach { (anchor, folder) ->
            array.put(
                JSONObject()
                    .put("anchor", anchor)
                    .put("name", folder.name)
                    .put("packages", JSONArray(folder.packages))
            )
        }
        preferences.edit().putString(LauncherPreferences.FOLDERS, array.toString()).apply()
    }
}
