package com.oxygen.launcher.ui

import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.oxygen.launcher.R
import com.oxygen.launcher.data.AppEntry
import com.oxygen.launcher.data.HomeItem
import com.oxygen.launcher.databinding.ItemDockAppBinding
import com.oxygen.launcher.databinding.ItemDrawerAppBinding
import com.oxygen.launcher.databinding.ItemFolderBinding
import com.oxygen.launcher.databinding.ItemLauncherAppBinding
import com.oxygen.launcher.util.IconShape

class HomeAdapter(
    private val onAppClick: (AppEntry) -> Unit,
    private val onAppLongClick: (AppEntry, View) -> Unit,
    private val onFolderClick: (HomeItem.Folder) -> Unit,
    private val onFolderLongClick: (HomeItem.Folder, View) -> Unit
) : ListAdapter<HomeItem, RecyclerView.ViewHolder>(HomeItemDiff) {
    private var iconShape: String = "rounded"
    private var iconSize: Int = 64
    private var cellHeight: Int = 106
    private var columns: Int = 4

    fun setIconStyle(shape: String, size: Int, cellHeightDp: Int, columns: Int) {
        iconShape = shape
        iconSize = size
        cellHeight = cellHeightDp
        this.columns = columns
    }

    override fun getItemViewType(position: Int): Int =
        if (getItem(position) is HomeItem.Folder) TYPE_FOLDER else TYPE_APP

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_FOLDER) {
            FolderHolder(ItemFolderBinding.inflate(inflater, parent, false))
        } else {
            AppHolder(ItemLauncherAppBinding.inflate(inflater, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val item = getItem(position)) {
            is HomeItem.App -> (holder as AppHolder).bind(item.entry)
            is HomeItem.Folder -> (holder as FolderHolder).bind(item)
        }
    }

    private inner class AppHolder(
        private val binding: ItemLauncherAppBinding
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind(app: AppEntry) {
            binding.root.layoutParams = binding.root.layoutParams.apply {
                height = dp(binding.root, cellHeight)
            }
            binding.icon.setImageDrawable(app.icon.copyForView())
            IconShape.apply(binding.icon, iconShape)
            val maxCellWidth = (
                binding.root.resources.displayMetrics.widthPixels /
                    binding.root.resources.displayMetrics.density / columns - 8
                ).toInt().coerceAtLeast(36)
            val effectiveIconSize = iconSize.coerceAtMost(
                minOf(cellHeight - 20, maxCellWidth).coerceAtLeast(36)
            )
            binding.icon.layoutParams = binding.icon.layoutParams.apply {
                width = dp(binding.root, effectiveIconSize)
                height = dp(binding.root, effectiveIconSize)
            }
            binding.label.text = app.label
            binding.notificationDot.visibility = if (app.hasNotification) View.VISIBLE else View.GONE
            binding.root.contentDescription = app.label
            binding.root.setOnClickListener { onAppClick(app) }
            binding.root.setOnLongClickListener {
                onAppLongClick(app, binding.root)
                true
            }
        }
    }

    private inner class FolderHolder(
        private val binding: ItemFolderBinding
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind(folder: HomeItem.Folder) {
            binding.root.layoutParams = binding.root.layoutParams.apply {
                height = dp(binding.root, cellHeight)
            }
            binding.icon.setImageResource(R.drawable.ic_folder)
            IconShape.apply(binding.icon, iconShape)
            val maxCellWidth = (
                binding.root.resources.displayMetrics.widthPixels /
                    binding.root.resources.displayMetrics.density / columns - 8
                ).toInt().coerceAtLeast(36)
            val effectiveIconSize = iconSize.coerceAtMost(
                minOf(cellHeight - 20, maxCellWidth).coerceAtLeast(36)
            )
            binding.icon.layoutParams = binding.icon.layoutParams.apply {
                width = dp(binding.root, effectiveIconSize)
                height = dp(binding.root, effectiveIconSize)
            }
            binding.folderCount.text = folder.apps.size.toString()
            binding.label.text = folder.name
            binding.root.contentDescription = "${folder.name}, ${folder.apps.size} aplicaciones"
            binding.root.setOnClickListener { onFolderClick(folder) }
            binding.root.setOnLongClickListener {
                onFolderLongClick(folder, binding.root)
                true
            }
        }
    }

    companion object {
        private const val TYPE_APP = 0
        private const val TYPE_FOLDER = 1
    }
}

private object HomeItemDiff : DiffUtil.ItemCallback<HomeItem>() {
    override fun areItemsTheSame(oldItem: HomeItem, newItem: HomeItem): Boolean =
        oldItem.id == newItem.id

    override fun areContentsTheSame(oldItem: HomeItem, newItem: HomeItem): Boolean =
        when {
            oldItem is HomeItem.App && newItem is HomeItem.App ->
                oldItem.entry.packageName == newItem.entry.packageName &&
                    oldItem.entry.label == newItem.entry.label &&
                    oldItem.entry.hasNotification == newItem.entry.hasNotification
            oldItem is HomeItem.Folder && newItem is HomeItem.Folder ->
                oldItem.name == newItem.name &&
                    oldItem.apps.map(AppEntry::packageName) == newItem.apps.map(AppEntry::packageName)
            else -> false
        }
}

class DockAdapter(
    private val onClick: (AppEntry) -> Unit,
    private val onLongClick: (AppEntry, View) -> Unit
) : ListAdapter<AppEntry, DockAdapter.Holder>(AppDiff) {
    private var iconShape = "rounded"
    private var iconSize = 48

    fun setIconStyle(shape: String, size: Int) {
        iconShape = shape
        iconSize = size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(ItemDockAppBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) = holder.bind(getItem(position))

    inner class Holder(private val binding: ItemDockAppBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(app: AppEntry) {
            binding.icon.setImageDrawable(app.icon.copyForView())
            IconShape.apply(binding.icon, iconShape)
            binding.icon.layoutParams = binding.icon.layoutParams.apply {
                width = dp(binding.root, iconSize)
                height = dp(binding.root, iconSize)
            }
            binding.notificationDot.visibility = if (app.hasNotification) View.VISIBLE else View.GONE
            binding.root.contentDescription = app.label
            binding.root.setOnClickListener { onClick(app) }
            binding.root.setOnLongClickListener {
                onLongClick(app, binding.root)
                true
            }
        }
    }
}

class DrawerListAdapter(
    private val onClick: (AppEntry) -> Unit,
    private val onLongClick: (AppEntry, View) -> Unit
) : ListAdapter<AppEntry, DrawerListAdapter.Holder>(AppDiff) {
    private var iconShape = "rounded"
    private var iconSize = 42

    fun setIconStyle(shape: String, size: Int) {
        iconShape = shape
        iconSize = size.coerceIn(32, 54)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(ItemDrawerAppBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) =
        holder.bind(getItem(position), iconShape)

    inner class Holder(private val binding: ItemDrawerAppBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(app: AppEntry, shape: String) {
            binding.icon.setImageDrawable(app.icon.copyForView())
            IconShape.apply(binding.icon, shape)
            binding.icon.layoutParams = binding.icon.layoutParams.apply {
                width = dp(binding.root, iconSize)
                height = dp(binding.root, iconSize)
            }
            binding.label.text = app.label
            binding.notificationDot.visibility = if (app.hasNotification) View.VISIBLE else View.GONE
            binding.root.contentDescription = app.label
            binding.root.setOnClickListener { onClick(app) }
            binding.root.setOnLongClickListener {
                onLongClick(app, binding.root)
                true
            }
        }
    }
}

private object AppDiff : DiffUtil.ItemCallback<AppEntry>() {
    override fun areItemsTheSame(oldItem: AppEntry, newItem: AppEntry): Boolean =
        oldItem.packageName == newItem.packageName

    override fun areContentsTheSame(oldItem: AppEntry, newItem: AppEntry): Boolean =
        oldItem.label == newItem.label &&
            oldItem.hasNotification == newItem.hasNotification
}

private fun Drawable.copyForView(): Drawable =
    constantState?.newDrawable()?.mutate() ?: mutate()

private fun dp(view: View, value: Int): Int =
    (value * view.resources.displayMetrics.density).toInt()
