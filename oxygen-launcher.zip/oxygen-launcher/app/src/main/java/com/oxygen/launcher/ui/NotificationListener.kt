package com.oxygen.launcher.ui

import android.content.Context
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.preference.PreferenceManager
import com.oxygen.launcher.settings.LauncherPreferences

class LauncherNotificationListener : NotificationListenerService() {
    override fun onListenerConnected() {
        super.onListenerConnected()
        refreshPackages()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) = refreshPackages()

    override fun onNotificationRemoved(sbn: StatusBarNotification?) = refreshPackages()

    private fun refreshPackages() {
        val packageNames = runCatching {
            activeNotifications
                .map(StatusBarNotification::getPackageName)
                .filter { it != packageName }
                .toSet()
        }.getOrDefault(emptySet())

        PreferenceManager.getDefaultSharedPreferences(this)
            .edit()
            .putStringSet(LauncherPreferences.NOTIFICATION_PACKAGES, packageNames)
            .apply()
        sendBroadcast(
            Intent(ACTION_NOTIFICATIONS_CHANGED).setPackage(packageName)
        )
    }

    companion object {
        const val ACTION_NOTIFICATIONS_CHANGED =
            "com.oxygen.launcher.action.NOTIFICATIONS_CHANGED"

        fun hasAccess(context: Context): Boolean =
            runCatching {
                android.provider.Settings.Secure.getString(
                    context.contentResolver,
                    "enabled_notification_listeners"
                )?.contains(context.packageName) == true
            }.getOrDefault(false)
    }
}
