package com.oxygen.launcher.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AppChangeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // MainViewModel reloads the package list and icons on Dispatchers.IO.
        context.applicationContext.sendBroadcast(
            Intent(ACTION_APPS_CHANGED).setPackage(context.packageName)
        )
    }

    companion object {
        const val ACTION_APPS_CHANGED = "com.oxygen.launcher.action.APPS_CHANGED"
    }
}
