package com.oxygen.launcher.util

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.preference.PreferenceManager
import com.oxygen.launcher.settings.LauncherPreferences

object ThemeController {
    fun apply(context: Context) {
        val theme = PreferenceManager.getDefaultSharedPreferences(context)
            .getString(LauncherPreferences.THEME, "system")
        AppCompatDelegate.setDefaultNightMode(
            when (theme) {
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )
    }
}
