package com.oxygen.launcher.settings

object LauncherPreferences {
    const val GRID_COLUMNS = "grid_columns"
    const val GRID_ROWS = "grid_rows"
    const val ICON_SIZE = "icon_size"
    const val ICON_SHAPE = "icon_shape"
    const val ICON_PACK = "icon_pack"
    const val WALLPAPER_URI = "wallpaper_uri"
    const val GESTURE_DOUBLE_TAP = "gesture_double_tap"
    const val GESTURE_SWIPE_DOWN = "gesture_swipe_down"
    const val GESTURE_SWIPE_UP = "gesture_swipe_up"
    const val ANIMATION_SPEED = "animation_speed"
    const val HIDDEN_APPS = "hidden_apps"
    const val HOME_APPS = "home_apps"
    const val DOCK_APPS = "dock_apps"
    const val FOLDERS = "folders"
    const val THEME = "theme"
    const val NOTIFICATION_DOTS = "notification_dots"
    const val NOTIFICATION_PACKAGES = "notification_packages"
}
