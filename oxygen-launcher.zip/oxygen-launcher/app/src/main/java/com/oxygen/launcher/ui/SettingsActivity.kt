package com.oxygen.launcher.ui

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.ListPreference
import androidx.preference.MultiSelectListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceCategory
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.PreferenceManager
import androidx.preference.SeekBarPreference
import androidx.preference.SwitchPreferenceCompat
import androidx.lifecycle.lifecycleScope
import com.oxygen.launcher.R
import com.oxygen.launcher.data.IconPackRepository
import com.oxygen.launcher.data.LauncherRepository
import com.oxygen.launcher.settings.LauncherPreferences
import com.oxygen.launcher.util.ThemeController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeController.apply(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.settingsContainer, SettingsFragment())
                .commit()
        }
    }
}

class SettingsFragment : PreferenceFragmentCompat() {
    private val wallpaperPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                runCatching {
                    requireContext().contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
                PreferenceManager.getDefaultSharedPreferences(requireContext())
                    .edit()
                    .putString(LauncherPreferences.WALLPAPER_URI, uri.toString())
                    .apply()
                wallpaperPreference?.summary = uri.lastPathSegment
                broadcastSettingsChanged()
            }
        }

    private var iconPackPreference: ListPreference? = null
    private var hiddenAppsPreference: MultiSelectListPreference? = null
    private var wallpaperPreference: Preference? = null
    private lateinit var sharedPreferences:
        android.content.SharedPreferences

    private val preferenceListener =
        android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            broadcastSettingsChanged()
            if (key == LauncherPreferences.THEME) {
                ThemeController.apply(requireContext())
                activity?.recreate()
            }
            if (key == LauncherPreferences.ICON_PACK) {
                broadcastSettingsChanged()
            }
        }

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(requireContext())
        preferenceScreen = preferenceManager.createPreferenceScreen(requireContext())

        val home = category("Inicio")
        home.addPreference(seekBar(LauncherPreferences.GRID_COLUMNS, "Columnas", 3, 6, 4))
        home.addPreference(seekBar(LauncherPreferences.GRID_ROWS, "Filas visibles", 3, 8, 5))
        home.addPreference(seekBar(LauncherPreferences.ICON_SIZE, "Tamaño de iconos", 40, 88, 64))

        val appearance = category("Apariencia")
        appearance.addPreference(
            listPreference(
                LauncherPreferences.ICON_SHAPE,
                "Forma de iconos",
                arrayOf("Redondeado", "Squircle", "Círculo", "Cuadrado"),
                arrayOf("rounded", "squircle", "circle", "square"),
                "rounded"
            )
        )
        iconPackPreference = listPreference(
            LauncherPreferences.ICON_PACK,
            "Pack de iconos",
            arrayOf("Iconos del sistema"),
            arrayOf("system"),
            "system"
        ).also(appearance::addPreference)
        wallpaperPreference = Preference(requireContext()).apply {
            key = "choose_wallpaper"
            title = "Fondo de pantalla"
            summary = this@SettingsFragment.sharedPreferences.getString(LauncherPreferences.WALLPAPER_URI, null)
                ?.substringAfterLast('/')
                ?: "Elegir una imagen del dispositivo"
            setOnPreferenceClickListener {
                wallpaperPicker.launch(arrayOf("image/*"))
                true
            }
        }.also(appearance::addPreference)
        appearance.addPreference(
            listPreference(
                LauncherPreferences.THEME,
                "Tema",
                arrayOf("Seguir al sistema", "Claro", "Oscuro"),
                arrayOf("system", "light", "dark"),
                "system"
            )
        )

        val gestures = category("Gestos y animaciones")
        gestures.addPreference(
            switchPreference(
                LauncherPreferences.GESTURE_DOUBLE_TAP,
                "Doble toque para bloquear",
                true
            )
        )
        gestures.addPreference(
            switchPreference(
                LauncherPreferences.GESTURE_SWIPE_DOWN,
                "Deslizar hacia abajo para notificaciones",
                true
            )
        )
        gestures.addPreference(
            switchPreference(
                LauncherPreferences.GESTURE_SWIPE_UP,
                "Deslizar hacia arriba para el cajón",
                true
            )
        )
        gestures.addPreference(
            listPreference(
                LauncherPreferences.ANIMATION_SPEED,
                "Velocidad de animación",
                arrayOf("Lenta", "Normal", "Rápida"),
                arrayOf("0.7", "1.0", "1.3"),
                "1.0"
            )
        )

        val notifications = category("Notificaciones")
        notifications.addPreference(
            switchPreference(LauncherPreferences.NOTIFICATION_DOTS, "Mostrar puntos", true)
        )
        notifications.addPreference(Preference(requireContext()).apply {
            title = "Acceso a notificaciones"
            summary = "Necesario para detectar qué aplicaciones tienen avisos activos"
            setOnPreferenceClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                true
            }
        })

        val privacy = category("Aplicaciones")
        hiddenAppsPreference = MultiSelectListPreference(requireContext()).apply {
            key = LauncherPreferences.HIDDEN_APPS
            title = "Aplicaciones ocultas"
            summary = "Selecciona las apps que no quieres mostrar en el cajón"
            values = this@SettingsFragment.sharedPreferences.getStringSet(key, emptySet())?.toMutableSet()
                ?: mutableSetOf<String>()
            entries = emptyArray()
            entryValues = emptyArray()
        }.also(privacy::addPreference)

        val accessibility = category("Permisos especiales")
        accessibility.addPreference(Preference(requireContext()).apply {
            title = "Servicio de gestos"
            summary = "Actívalo para abrir el panel de notificaciones al deslizar hacia abajo"
            setOnPreferenceClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                true
            }
        })

        loadIconPacks()
        loadInstalledApps()
    }

    override fun onStart() {
        super.onStart()
        sharedPreferences.registerOnSharedPreferenceChangeListener(preferenceListener)
    }

    override fun onStop() {
        sharedPreferences.unregisterOnSharedPreferenceChangeListener(preferenceListener)
        super.onStop()
    }

    private fun category(title: String): PreferenceCategory =
        PreferenceCategory(requireContext()).also {
            it.title = title
            preferenceScreen.addPreference(it)
        }

    private fun seekBar(
        key: String,
        title: String,
        min: Int,
        max: Int,
        default: Int
    ): SeekBarPreference = SeekBarPreference(requireContext()).apply {
        this.key = key
        this.title = title
        this.min = min
        this.max = max
        this.value = this@SettingsFragment.sharedPreferences.getInt(key, default).coerceIn(min, max)
        showSeekBarValue = true
        updatesContinuously = false
    }

    private fun listPreference(
        key: String,
        title: String,
        entries: Array<CharSequence>,
        values: Array<CharSequence>,
        default: String
    ): ListPreference = ListPreference(requireContext()).apply {
        this.key = key
        this.title = title
        this.entries = entries
        entryValues = values
        setDefaultValue(default)
    }

    private fun switchPreference(
        key: String,
        title: String,
        default: Boolean
    ): SwitchPreferenceCompat = SwitchPreferenceCompat(requireContext()).apply {
        this.key = key
        this.title = title
        setDefaultValue(default)
    }

    private fun loadIconPacks() {
        val context = requireContext().applicationContext
        lifecycleScope.launch {
            val packs = withContext(Dispatchers.IO) {
                IconPackRepository(context).availablePacks()
            }
            val entries = listOf("Iconos del sistema") + packs.map { it.label }
            val values = listOf("system") + packs.map { it.packageName }
            iconPackPreference?.entries = entries.toTypedArray()
            iconPackPreference?.entryValues = values.toTypedArray()
            if (sharedPreferences.getString(LauncherPreferences.ICON_PACK, "system") !in values) {
                sharedPreferences.edit().putString(LauncherPreferences.ICON_PACK, "system").apply()
            }
        }
    }

    private fun loadInstalledApps() {
        val context = requireContext().applicationContext
        lifecycleScope.launch {
            val apps = LauncherRepository(context).loadApps()
            val preference = hiddenAppsPreference ?: return@launch
            preference.entries = apps.map { it.label }.toTypedArray()
            preference.entryValues = apps.map { it.packageName }.toTypedArray()
            preference.values = sharedPreferences.getStringSet(
                LauncherPreferences.HIDDEN_APPS,
                emptySet()
            )?.toMutableSet() ?: mutableSetOf()
        }
    }

    private fun broadcastSettingsChanged() {
        context?.sendBroadcast(
            Intent(MainActivity.ACTION_SETTINGS_CHANGED)
                .setPackage(requireContext().packageName)
        )
    }
}
