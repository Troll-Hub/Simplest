package com.oxygen.launcher.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.oxygen.launcher.data.AppEntry
import com.oxygen.launcher.data.HomeItem
import com.oxygen.launcher.data.LauncherRepository
import com.oxygen.launcher.settings.LauncherPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.preference.PreferenceManager

data class MainUiState(
    val allApps: List<AppEntry> = emptyList(),
    val visibleApps: List<AppEntry> = emptyList(),
    val homeItems: List<HomeItem> = emptyList(),
    val dockApps: List<AppEntry> = emptyList(),
    val isLoading: Boolean = true
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = LauncherRepository(application)
    private val preferences = PreferenceManager.getDefaultSharedPreferences(application)
    private val mutableState = MutableStateFlow(MainUiState())
    val state: StateFlow<MainUiState> = mutableState.asStateFlow()

    fun refresh() {
        viewModelScope.launch {
            mutableState.value = mutableState.value.copy(isLoading = true)
            val apps = repository.loadApps()
            repository.ensureDefaultLayout(apps)
            val hidden = repository.hiddenPackages()
            val notified = if (preferences.getBoolean(LauncherPreferences.NOTIFICATION_DOTS, true)) {
                preferences.getStringSet(
                    LauncherPreferences.NOTIFICATION_PACKAGES,
                    emptySet()
                )?.toSet().orEmpty()
            } else {
                emptySet()
            }
            val decoratedApps = withContext(Dispatchers.Default) {
                apps.map { it.copy(hasNotification = it.packageName in notified) }
            }
            val visible = decoratedApps.filterNot { it.packageName in hidden }
            mutableState.value = MainUiState(
                allApps = decoratedApps,
                visibleApps = visible,
                homeItems = repository.homeItems(visible),
                dockApps = repository.dockApps(visible),
                isLoading = false
            )
        }
    }

    fun addToHome(packageName: String) = mutate {
        repository.addToHome(packageName)
    }

    fun removeFromHome(packageName: String) = mutate {
        repository.removeFromHome(packageName)
        repository.removeAppFromFolders(packageName)
    }

    fun addToDock(packageName: String) = mutate {
        repository.addToDock(packageName)
    }

    fun moveToDock(packageName: String) = mutate {
        repository.removeFromHome(packageName)
        repository.removeAppFromFolders(packageName)
        repository.addToDock(packageName)
    }

    fun moveToHome(packageName: String) = mutate {
        repository.removeFromDock(packageName)
        repository.addToHome(packageName)
    }

    fun removeFromDock(packageName: String) = mutate {
        repository.removeFromDock(packageName)
    }

    fun toggleHidden(packageName: String) = mutate {
        repository.toggleHidden(packageName)
    }

    fun createFolder(name: String, firstPackage: String, secondPackage: String) = mutate {
        repository.createFolder(name, firstPackage, secondPackage)
    }

    fun dissolveFolder(anchorPackage: String) = mutate {
        repository.dissolveFolder(anchorPackage)
    }

    fun invalidateIconsAndRefresh() {
        repository.invalidateIcons()
        refresh()
    }

    fun refreshNotificationBadges() {
        val current = mutableState.value
        if (current.isLoading || current.allApps.isEmpty()) return
        val notified = if (preferences.getBoolean(LauncherPreferences.NOTIFICATION_DOTS, true)) {
            preferences.getStringSet(
                LauncherPreferences.NOTIFICATION_PACKAGES,
                emptySet()
            )?.toSet().orEmpty()
        } else {
            emptySet()
        }
        val visiblePackages = current.visibleApps.map(AppEntry::packageName).toSet()
        val updatedApps = current.allApps.map {
            it.copy(hasNotification = it.packageName in notified)
        }
        val visible = updatedApps.filter { it.packageName in visiblePackages }
        mutableState.value = current.copy(
            allApps = updatedApps,
            visibleApps = visible,
            homeItems = repository.homeItems(visible),
            dockApps = repository.dockApps(visible)
        )
    }

    private fun mutate(action: () -> Unit) {
        action()
        refresh()
    }
}
