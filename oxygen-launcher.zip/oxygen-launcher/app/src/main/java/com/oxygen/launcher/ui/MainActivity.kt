package com.oxygen.launcher.ui

import android.app.admin.DevicePolicyManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.BitmapFactory
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.animation.ValueAnimator
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.preference.PreferenceManager
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.oxygen.launcher.R
import com.oxygen.launcher.data.AppEntry
import com.oxygen.launcher.data.HomeItem
import com.oxygen.launcher.databinding.ActivityMainBinding
import com.oxygen.launcher.settings.LauncherPreferences
import com.oxygen.launcher.util.IconShape
import com.oxygen.launcher.util.ThemeController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce

class MainActivity : AppCompatActivity() {
    private val viewModel: MainViewModel by viewModels()
    private lateinit var binding: ActivityMainBinding
    private lateinit var sheetBehavior: BottomSheetBehavior<LinearLayout>
    private lateinit var homeAdapter: HomeAdapter
    private lateinit var dockAdapter: DockAdapter
    private lateinit var drawerAdapter: DrawerListAdapter
    private var allVisibleApps: List<AppEntry> = emptyList()
    private var drawerApps: List<AppEntry> = emptyList()
    private var gestureStartX = 0f
    private var gestureStartY = 0f
    private var lastHeaderTap = 0L
    private var lastGridColumns = -1

    private val preferences by lazy { PreferenceManager.getDefaultSharedPreferences(this) }
    private val devicePolicyManager by lazy {
        getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    }
    private val adminComponent by lazy {
        ComponentName(this, LockDeviceAdminReceiver::class.java)
    }

    private val refreshReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == LauncherNotificationListener.ACTION_NOTIFICATIONS_CHANGED) {
                viewModel.refreshNotificationBadges()
            } else {
                viewModel.refresh()
            }
        }
    }

    private val lockAdminLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (devicePolicyManager.isAdminActive(adminComponent)) {
                devicePolicyManager.lockNow()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeController.apply(this)
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window.addFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED)
        configureHome()
        configureDrawer()
        configureAnimationSpeed()
        updateDate()
        loadWallpaper()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.state.collect(::render)
            }
        }
        binding.homeAppsRecycler.addOnLayoutChangeListener { _, _, top, _, bottom, _, oldTop, _, oldBottom ->
            if (bottom - top != oldBottom - oldTop) updateHomeCellHeight()
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(AppChangeReceiver.ACTION_APPS_CHANGED)
            addAction(LauncherNotificationListener.ACTION_NOTIFICATIONS_CHANGED)
            addAction(ACTION_SETTINGS_CHANGED)
        }
        ContextCompat.registerReceiver(
            this,
            refreshReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onResume() {
        super.onResume()
        ThemeController.apply(this)
        updateDate()
        loadWallpaper()
        configureAnimationSpeed()
        viewModel.refresh()
    }

    override fun onStop() {
        runCatching { unregisterReceiver(refreshReceiver) }
        super.onStop()
    }

    private fun configureHome() {
        homeAdapter = HomeAdapter(
            onAppClick = ::launchApp,
            onAppLongClick = { app, anchor -> showAppMenu(app, anchor) },
            onFolderClick = ::openFolder,
            onFolderLongClick = ::showFolderMenu
        )
        dockAdapter = DockAdapter(
            onClick = ::launchApp,
            onLongClick = { app, anchor -> showAppMenu(app, anchor) }
        )

        binding.homeAppsRecycler.adapter = homeAdapter
        binding.homeAppsRecycler.setHasFixedSize(true)
        binding.homeAppsRecycler.itemAnimator = null
        binding.homeAppsRecycler.overScrollMode = View.OVER_SCROLL_NEVER
        updateGridLayout()

        binding.dockRecycler.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.dockRecycler.adapter = dockAdapter
        binding.dockRecycler.setHasFixedSize(true)
        binding.dockRecycler.itemAnimator = null
        binding.dockRecycler.overScrollMode = View.OVER_SCROLL_NEVER

        binding.settingsButton.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.homeAppsRecycler.setItemViewCacheSize(24)
        binding.dockRecycler.setItemViewCacheSize(8)
    }

    private fun configureDrawer() {
        sheetBehavior = BottomSheetBehavior.from(binding.appDrawerSheet)
        sheetBehavior.isHideable = true
        sheetBehavior.isFitToContents = true
        sheetBehavior.peekHeight = 0
        sheetBehavior.expandedOffset = dp(14)
        binding.appDrawerSheet.layoutParams.height =
            (resources.displayMetrics.heightPixels - dp(32)).coerceAtLeast(dp(360))
        sheetBehavior.state = BottomSheetBehavior.STATE_HIDDEN

        drawerAdapter = DrawerListAdapter(
            onClick = ::launchApp,
            onLongClick = { app, anchor -> showAppMenu(app, anchor) }
        )
        binding.drawerAppsRecycler.layoutManager = LinearLayoutManager(this)
        binding.drawerAppsRecycler.adapter = drawerAdapter
        binding.drawerAppsRecycler.setHasFixedSize(true)
        binding.drawerAppsRecycler.itemAnimator = null
        binding.drawerAppsRecycler.overScrollMode = View.OVER_SCROLL_NEVER

        binding.drawerSearch.addTextChangedListener(
            object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) =
                    filterDrawer(s?.toString().orEmpty())
                override fun afterTextChanged(s: android.text.Editable?) = Unit
            }
        )
        binding.letterIndex.setOnTouchListener { view, event ->
            if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
                val letters = binding.letterIndex.text.toString().filterNot { it.isWhitespace() }
                if (letters.isNotEmpty()) {
                    val letterIndex = ((event.y / view.height) * letters.length)
                        .toInt().coerceIn(0, letters.lastIndex)
                    jumpToLetter(letters[letterIndex])
                }
                true
            } else {
                true
            }
        }
        sheetBehavior.addBottomSheetCallback(object :
            BottomSheetBehavior.BottomSheetCallback() {
            override fun onStateChanged(bottomSheet: View, newState: Int) {
                if (newState == BottomSheetBehavior.STATE_EXPANDED) {
                    binding.motionHome.transitionToEnd()
                } else if (
                    newState == BottomSheetBehavior.STATE_HIDDEN ||
                    newState == BottomSheetBehavior.STATE_COLLAPSED
                ) {
                    binding.motionHome.transitionToStart()
                }
            }

            override fun onSlide(bottomSheet: View, slideOffset: Float) = Unit
        })
    }

    private fun configureAnimationSpeed() {
        val speed = preferences.getString(LauncherPreferences.ANIMATION_SPEED, "1.0")
            ?.toFloatOrNull()?.coerceIn(0.5f, 1.5f) ?: 1f
        binding.motionHome.setTransitionDuration((320f / speed).toInt())
    }

    private fun render(state: MainUiState) {
        if (isFinishing || isDestroyed) return
        allVisibleApps = state.visibleApps
        val columns = preferences.getInt(LauncherPreferences.GRID_COLUMNS, 4).coerceIn(3, 6)
        if (columns != lastGridColumns) updateGridLayout()
        val shape = preferences.getString(LauncherPreferences.ICON_SHAPE, "rounded") ?: "rounded"
        val iconSize = preferences.getInt(LauncherPreferences.ICON_SIZE, 64).coerceIn(40, 88)
        updateHomeCellHeight()
        dockAdapter.setIconStyle(shape, (iconSize * 0.75f).toInt().coerceIn(36, 48))
        dockAdapter.notifyItemRangeChanged(0, dockAdapter.itemCount)
        drawerAdapter.setIconStyle(shape, (iconSize * 0.7f).toInt())
        drawerAdapter.notifyItemRangeChanged(0, drawerAdapter.itemCount)
        homeAdapter.submitList(state.homeItems)
        dockAdapter.submitList(state.dockApps)
        filterDrawer(binding.drawerSearch.text?.toString().orEmpty())
    }

    private fun updateHomeCellHeight() {
        val rows = preferences.getInt(LauncherPreferences.GRID_ROWS, 5).coerceIn(3, 8)
        val iconSize = preferences.getInt(LauncherPreferences.ICON_SIZE, 64).coerceIn(40, 88)
        val shape = preferences.getString(LauncherPreferences.ICON_SHAPE, "rounded") ?: "rounded"
        val cellHeightDp = (binding.homeAppsRecycler.height / rows / resources.displayMetrics.density)
            .toInt()
            .coerceAtLeast(60)
        val columns = preferences.getInt(LauncherPreferences.GRID_COLUMNS, 4).coerceIn(3, 6)
        homeAdapter.setIconStyle(shape, iconSize, cellHeightDp, columns)
        homeAdapter.notifyItemRangeChanged(0, homeAdapter.itemCount)
    }

    private fun updateGridLayout() {
        val columns = preferences.getInt(LauncherPreferences.GRID_COLUMNS, 4).coerceIn(3, 6)
        lastGridColumns = columns
        binding.homeAppsRecycler.layoutManager = GridLayoutManager(this, columns)
    }

    private fun filterDrawer(query: String) {
        val needle = query.trim()
        drawerApps = if (needle.isEmpty()) allVisibleApps else {
            allVisibleApps.filter { it.label.contains(needle, ignoreCase = true) }
        }
        drawerAdapter.submitList(drawerApps)
        binding.letterIndex.isVisible = needle.isEmpty()
    }

    private fun jumpToLetter(letter: Char) {
        val position = drawerApps.indexOfFirst {
            it.label.firstOrNull()?.uppercaseChar() == letter
        }
        if (position >= 0) binding.drawerAppsRecycler.scrollToPosition(position)
    }

    private fun openDrawer() {
        if (!preferences.getBoolean(LauncherPreferences.GESTURE_SWIPE_UP, true)) return
        sheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
        binding.drawerSearch.clearFocus()
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gestureStartX = event.rawX
                gestureStartY = event.rawY
            }
            MotionEvent.ACTION_UP -> {
                val deltaY = event.rawY - gestureStartY
                val deltaX = event.rawX - gestureStartX
                if (kotlin.math.abs(deltaY) > dp(90) &&
                    kotlin.math.abs(deltaY) > kotlin.math.abs(deltaX) * 1.2f
                ) {
                    if (deltaY < 0 && sheetBehavior.state != BottomSheetBehavior.STATE_EXPANDED) {
                        if (preferences.getBoolean(LauncherPreferences.GESTURE_SWIPE_UP, true)) {
                            openDrawer()
                        }
                    } else if (deltaY > 0) {
                        handleSwipeDown()
                    }
                    springHomeBack()
                } else if (
                    kotlin.math.abs(deltaY) < dp(12) &&
                    kotlin.math.abs(deltaX) < dp(12) &&
                    isEmptyHomeTap(event.rawX, event.rawY) &&
                    preferences.getBoolean(LauncherPreferences.GESTURE_DOUBLE_TAP, true)
                ) {
                    val now = android.os.SystemClock.uptimeMillis()
                    if (now - lastHeaderTap < 360) {
                        lastHeaderTap = 0
                        lockScreen()
                    } else {
                        lastHeaderTap = now
                    }
                }
            }
        }
        return super.dispatchTouchEvent(event)
    }

    private fun handleSwipeDown() {
        if (sheetBehavior.state == BottomSheetBehavior.STATE_EXPANDED) {
            sheetBehavior.state = BottomSheetBehavior.STATE_HIDDEN
            return
        }
        if (!preferences.getBoolean(LauncherPreferences.GESTURE_SWIPE_DOWN, true)) return
        if (LauncherAccessibilityService.showNotifications()) return
        AlertDialog.Builder(this)
            .setTitle(R.string.enable_accessibility)
            .setMessage(R.string.accessibility_service_description)
            .setNegativeButton(android.R.string.cancel, null)
            .setPositiveButton(R.string.enable_accessibility) { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .show()
    }

    private fun isEmptyHomeTap(rawX: Float, rawY: Float): Boolean {
        if (sheetBehavior.state == BottomSheetBehavior.STATE_EXPANDED) return false
        val x = rawX.toInt()
        val y = rawY.toInt()
        val settingsRect = Rect()
        val dockRect = Rect()
        binding.settingsButton.getGlobalVisibleRect(settingsRect)
        binding.dockRecycler.getGlobalVisibleRect(dockRect)
        if (settingsRect.contains(x, y) || dockRect.contains(x, y)) return false
        for (index in 0 until binding.homeAppsRecycler.childCount) {
            val childRect = Rect()
            binding.homeAppsRecycler.getChildAt(index).getGlobalVisibleRect(childRect)
            if (childRect.contains(x, y)) return false
        }
        return true
    }

    private fun springHomeBack() {
        if (!ValueAnimator.areAnimatorsEnabled()) {
            binding.homePanel.translationY = 0f
            return
        }
        binding.homePanel.translationY = dp(4).toFloat()
        SpringAnimation(binding.homePanel, DynamicAnimation.TRANSLATION_Y, 0f).apply {
            spring = SpringForce(0f).apply {
                stiffness = SpringForce.STIFFNESS_MEDIUM
                dampingRatio = SpringForce.DAMPING_RATIO_NO_BOUNCY
            }
            start()
        }
    }

    private fun lockScreen() {
        if (!devicePolicyManager.isAdminActive(adminComponent)) {
            AlertDialog.Builder(this)
                .setTitle(R.string.lock_admin_title)
                .setMessage(R.string.lock_admin_message)
                .setNegativeButton(android.R.string.cancel, null)
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    val request = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                        .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
                        .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, getString(R.string.lock_admin_message))
                    lockAdminLauncher.launch(request)
                }
                .show()
            return
        }
        devicePolicyManager.lockNow()
    }

    private fun launchApp(app: AppEntry) {
        val launchIntent = packageManager.getLaunchIntentForPackage(app.packageName)
        if (launchIntent == null) {
            Toast.makeText(this, "No se puede abrir ${app.label}", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(
                launchIntent,
                android.app.ActivityOptions.makeCustomAnimation(
                    this,
                    R.anim.app_open_enter,
                    R.anim.app_open_exit
                ).toBundle()
            )
        } catch (exception: Exception) {
            Toast.makeText(this, "No se pudo abrir ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAppMenu(app: AppEntry, anchor: View) {
        val state = viewModel.state.value
        val isHome = state.homeItems.any { item ->
            when (item) {
                is HomeItem.App -> item.entry.packageName == app.packageName
                is HomeItem.Folder -> item.apps.any { it.packageName == app.packageName }
            }
        }
        val isDock = state.dockApps.any { it.packageName == app.packageName }
        val menu = PopupMenu(this, anchor)
        if (isHome) {
            menu.menu.add(R.string.action_move_to_dock).setOnMenuItemClickListener {
                viewModel.moveToDock(app.packageName)
                true
            }
            menu.menu.add(R.string.action_remove_home).setOnMenuItemClickListener {
                viewModel.removeFromHome(app.packageName)
                true
            }
            menu.menu.add(R.string.action_create_folder).setOnMenuItemClickListener {
                askCreateFolder(app)
                true
            }
        } else if (isDock) {
            menu.menu.add("Mover a la pantalla de inicio").setOnMenuItemClickListener {
                viewModel.moveToHome(app.packageName)
                true
            }
            menu.menu.add(R.string.action_remove_dock).setOnMenuItemClickListener {
                viewModel.removeFromDock(app.packageName)
                true
            }
        } else {
            menu.menu.add(R.string.action_add_home).setOnMenuItemClickListener {
                viewModel.addToHome(app.packageName)
                true
            }
            menu.menu.add(R.string.action_move_to_dock).setOnMenuItemClickListener {
                viewModel.moveToDock(app.packageName)
                true
            }
        }
        menu.menu.add(R.string.action_app_info).setOnMenuItemClickListener {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.parse("package:${app.packageName}"))
            )
            true
        }
        menu.menu.add(R.string.action_uninstall).setOnMenuItemClickListener {
            startActivity(
                Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}"))
            )
            true
        }
        menu.menu.add(R.string.action_hide).setOnMenuItemClickListener {
            viewModel.toggleHidden(app.packageName)
            true
        }
        menu.show()
    }

    private fun askCreateFolder(firstApp: AppEntry) {
        val candidates = viewModel.state.value.homeItems
            .filterIsInstance<HomeItem.App>()
            .map(HomeItem.App::entry)
            .filterNot { it.packageName == firstApp.packageName }
        if (candidates.isEmpty()) {
            Toast.makeText(this, "Agrega otra aplicación al inicio para crear una carpeta", Toast.LENGTH_SHORT).show()
            return
        }
        val folderName = EditText(this).apply {
            hint = getString(R.string.folder_name_hint)
            setText("Carpeta")
            setPadding(dp(18), dp(12), dp(18), dp(12))
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.action_create_folder)
            .setView(folderName)
            .setPositiveButton(R.string.folder_choose_app) { _, _ ->
                AlertDialog.Builder(this)
                    .setTitle(R.string.folder_choose_app)
                    .setItems(candidates.map(AppEntry::label).toTypedArray()) { _, index ->
                        viewModel.createFolder(
                            folderName.text.toString(),
                            firstApp.packageName,
                            candidates[index].packageName
                        )
                    }
                    .show()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun openFolder(folder: HomeItem.Folder) {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(24))
        }
        val title = android.widget.TextView(this).apply {
            text = folder.name
            textSize = 21f
            setTextColor(resolveThemeColor(android.R.attr.textColorPrimary))
            setPadding(0, 0, 0, dp(14))
        }
        content.addView(
            title,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        var row: LinearLayout? = null
        folder.apps.forEachIndexed { index, app ->
            val currentRow = if (index % 4 == 0) {
                LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER
                }.also { createdRow ->
                    row = createdRow
                    content.addView(
                        createdRow,
                        LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            dp(104)
                        )
                    )
                }
            } else {
                row
            }
            if (currentRow == null) return@forEachIndexed
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = android.view.Gravity.CENTER
                isClickable = true
                isFocusable = true
                setBackgroundResource(android.R.drawable.list_selector_background)
                contentDescription = app.label
            }
            val iconFrame = android.widget.FrameLayout(this)
            val icon = android.widget.ImageView(this).apply {
                setImageDrawable(app.icon.constantState?.newDrawable()?.mutate() ?: app.icon.mutate())
                scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
                IconShape.apply(this, preferences.getString(LauncherPreferences.ICON_SHAPE, "rounded") ?: "rounded")
            }
            iconFrame.addView(
                icon,
                android.widget.FrameLayout.LayoutParams(dp(52), dp(52), android.view.Gravity.CENTER)
            )
            if (app.hasNotification) {
                iconFrame.addView(
                    View(this).apply { setBackgroundResource(R.drawable.notification_dot) },
                    android.widget.FrameLayout.LayoutParams(dp(9), dp(9), android.view.Gravity.TOP or android.view.Gravity.END)
                )
            }
            tile.addView(iconFrame, LinearLayout.LayoutParams(dp(58), dp(58)))
            tile.addView(android.widget.TextView(this).apply {
                text = app.label
                textSize = 11f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                gravity = android.view.Gravity.CENTER
                setTextColor(resolveThemeColor(android.R.attr.textColorPrimary))
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ))
            tile.setOnClickListener {
                dialog.dismiss()
                launchApp(app)
            }
            currentRow.addView(
                tile,
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply {
                    marginStart = dp(3)
                    marginEnd = dp(3)
                }
            )
        }
        dialog.setContentView(content)
        dialog.show()
        content.post {
            if (ValueAnimator.areAnimatorsEnabled()) {
                content.scaleX = 0.94f
                content.scaleY = 0.94f
                SpringAnimation(content, DynamicAnimation.SCALE_X, 1f).apply {
                    spring = SpringForce(1f).apply {
                        stiffness = SpringForce.STIFFNESS_MEDIUM
                        dampingRatio = SpringForce.DAMPING_RATIO_NO_BOUNCY
                    }
                    start()
                }
                SpringAnimation(content, DynamicAnimation.SCALE_Y, 1f).apply {
                    spring = SpringForce(1f).apply {
                        stiffness = SpringForce.STIFFNESS_MEDIUM
                        dampingRatio = SpringForce.DAMPING_RATIO_NO_BOUNCY
                    }
                    start()
                }
            } else {
                content.scaleX = 1f
                content.scaleY = 1f
            }
        }
    }

    private fun showFolderMenu(folder: HomeItem.Folder, anchor: View) {
        PopupMenu(this, anchor).apply {
            menu.add("Abrir carpeta").setOnMenuItemClickListener {
                openFolder(folder)
                true
            }
            menu.add("Disolver carpeta").setOnMenuItemClickListener {
                viewModel.dissolveFolder(folder.id.removePrefix("folder:"))
                true
            }
            show()
        }
    }

    private fun loadWallpaper() {
        val value = preferences.getString(LauncherPreferences.WALLPAPER_URI, null)
        if (value.isNullOrBlank()) {
            binding.wallpaperImage.setImageDrawable(null)
            binding.wallpaperImage.visibility = View.GONE
            return
        }
        val uri = runCatching { Uri.parse(value) }.getOrNull() ?: return
        lifecycleScope.launch {
            val bitmap = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openInputStream(uri)?.use { input ->
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeStream(input, null, bounds)
                        val targetWidth = resources.displayMetrics.widthPixels
                        val targetHeight = resources.displayMetrics.heightPixels
                        var sampleSize = 1
                        while (bounds.outWidth / sampleSize > targetWidth * 2 ||
                            bounds.outHeight / sampleSize > targetHeight * 2
                        ) {
                            sampleSize *= 2
                        }
                        val options = BitmapFactory.Options().apply { inSampleSize = sampleSize }
                        contentResolver.openInputStream(uri)?.use { image ->
                            BitmapFactory.decodeStream(image, null, options)
                        }
                    }
                } catch (_: SecurityException) {
                    null
                } catch (_: java.io.IOException) {
                    null
                }
            }
            if (bitmap != null && !isDestroyed) {
                binding.wallpaperImage.setImageBitmap(bitmap)
                binding.wallpaperImage.visibility = View.VISIBLE
            }
        }
    }

    private fun updateDate() {
        val formatter = DateFormat.getDateInstance(DateFormat.FULL, Locale.getDefault())
        binding.homeDate.text = formatter.format(Date())
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun resolveThemeColor(attribute: Int): Int {
        val value = android.util.TypedValue()
        theme.resolveAttribute(attribute, value, true)
        if (value.resourceId != 0) {
            androidx.core.content.ContextCompat.getColorStateList(this, value.resourceId)
                ?.defaultColor?.let { return it }
        }
        return value.data
    }

    companion object {
        const val ACTION_SETTINGS_CHANGED =
            "com.oxygen.launcher.action.SETTINGS_CHANGED"
    }
}
