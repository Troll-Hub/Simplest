package com.oxygen.launcher.util

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.ImageView

object IconShape {
    fun apply(imageView: ImageView, shape: String) {
        val background = GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            when (shape) {
                "circle" -> setShape(GradientDrawable.OVAL)
                "square" -> {
                    setShape(GradientDrawable.RECTANGLE)
                    cornerRadius = 0f
                }
                "squircle" -> {
                    setShape(GradientDrawable.RECTANGLE)
                    cornerRadius = imageView.resources.displayMetrics.density * 18f
                }
                else -> {
                    setShape(GradientDrawable.RECTANGLE)
                    cornerRadius = imageView.resources.displayMetrics.density * 14f
                }
            }
        }
        imageView.background = background
        imageView.outlineProvider = ViewOutlineProvider.BACKGROUND
        imageView.clipToOutline = true
        imageView.visibility = View.VISIBLE
    }
}
