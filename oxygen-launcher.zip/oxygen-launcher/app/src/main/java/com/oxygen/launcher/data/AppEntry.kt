package com.oxygen.launcher.data

import android.graphics.drawable.Drawable

data class AppEntry(
    val packageName: String,
    val activityName: String,
    val label: String,
    val icon: Drawable,
    val hasNotification: Boolean = false
)

sealed interface HomeItem {
    val id: String

    data class App(val entry: AppEntry) : HomeItem {
        override val id: String = entry.packageName
    }

    data class Folder(
        override val id: String,
        val name: String,
        val apps: List<AppEntry>
    ) : HomeItem
}

data class FolderRecord(
    val name: String,
    val packages: List<String>
)
