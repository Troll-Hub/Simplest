package com.oxygen.launcher.ui

import android.app.admin.DeviceAdminReceiver

class LockDeviceAdminReceiver : DeviceAdminReceiver()
