package com.oxygen.launcher.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Resources
import android.graphics.drawable.Drawable
import android.util.Xml
import org.xmlpull.v1.XmlPullParser

data class IconPack(val packageName: String, val label: String)

/**
 * Supports the common ADW/Nova icon-pack contract. Icon packs remain optional:
 * apps without an appfilter entry use their system-provided icon.
 */
class IconPackRepository(private val context: Context) {
    private val packageManager = context.packageManager
    private val mappingCache = mutableMapOf<String, Map<String, String>>()

    fun availablePacks(): List<IconPack> {
        val knownActions = listOf("org.adw.ActivityChooser", "com.novalauncher.THEME")
        return knownActions
            .flatMap { action ->
                @Suppress("DEPRECATION")
                packageManager.queryIntentActivities(Intent(action), PackageManager.MATCH_DEFAULT_ONLY)
            }
            .mapNotNull { resolveInfo ->
                val packageName = resolveInfo.activityInfo?.packageName ?: return@mapNotNull null
                val label = resolveInfo.loadLabel(packageManager)?.toString() ?: packageName
                IconPack(packageName, label)
            }
            .distinctBy(IconPack::packageName)
            .sortedBy { it.label.lowercase() }
    }

    fun loadIcon(packPackage: String, targetPackage: String, activityName: String): Drawable? {
        return try {
            val resources = packageManager.getResourcesForApplication(packPackage)
            val component = "ComponentInfo{$targetPackage/$activityName}"
            val drawableName = mappings(packPackage, resources)[component] ?: return null
            val resourceId = resources.getIdentifier(drawableName, "drawable", packPackage)
            if (resourceId == 0) null else resources.getDrawable(resourceId, null)
        } catch (_: PackageManager.NameNotFoundException) {
            null
        } catch (_: Resources.NotFoundException) {
            null
        } catch (_: SecurityException) {
            null
        }
    }

    private fun mappings(packPackage: String, resources: Resources): Map<String, String> {
        mappingCache[packPackage]?.let { return it }
        val result = mutableMapOf<String, String>()
        val xmlId = resources.getIdentifier("appfilter", "xml", packPackage)
        if (xmlId != 0) {
            val parser = resources.getXml(xmlId)
            try {
                var event = parser.eventType
                while (event != XmlPullParser.END_DOCUMENT) {
                    if (event == XmlPullParser.START_TAG && parser.name == "item") {
                        val component = parser.getAttributeValue(null, "component")
                        val drawable = parser.getAttributeValue(null, "drawable")
                        if (!component.isNullOrBlank() && !drawable.isNullOrBlank()) {
                            result[component] = drawable
                        }
                    }
                    event = parser.next()
                }
            } finally {
                parser.close()
            }
        }
        mappingCache[packPackage] = result
        return result
    }
}
