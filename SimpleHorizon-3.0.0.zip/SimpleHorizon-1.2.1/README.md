# SimpleHorizon 3.0

Blood Strike (`com.netease.newspike`) corre en una **pantalla virtual** horizontal (p. ej. 3526×1220 en un panel de 2712×1220)
que se muestra a pantalla completa: el sistema la escala al panel y eso estira la imagen. No se toca `wm`, ni la resolución,
ni la proyección de SurfaceFlinger. Los toques se reescalan e inyectan en la pantalla virtual (Shizuku).

- Frecuencia pedida a la pantalla virtual: 60 / 90 / 120 / 144 Hz (`VirtualDisplayConfig.setRequestedRefreshRate`),
  y la ventana que la muestra pide el modo del panel más cercano. El valor real se ve en el menú flotante (↔).
- Menú flotante dentro de la ventana: ancho en tiempo real, atajos de %, salir.
- Tema negro y blanco.
