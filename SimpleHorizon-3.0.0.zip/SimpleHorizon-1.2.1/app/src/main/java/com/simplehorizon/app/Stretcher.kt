package com.simplehorizon.app

import android.app.Activity
import android.content.Intent
import android.widget.Toast

object Stretcher {
    fun start(act: Activity) {
        if (!Permisos.instalado(act)) {
            Toast.makeText(act, "${Game.NAME} no está instalado", Toast.LENGTH_LONG).show()
            return
        }
        when (HorizonBridge.state()) {
            HorizonBridge.State.READY -> act.startActivity(Intent(act, GameActivity::class.java))
            HorizonBridge.State.NO_PERMISSION -> { HorizonBridge.requestPermission(); Toast.makeText(act, "Concede el permiso de Shizuku", Toast.LENGTH_LONG).show() }
            else -> Toast.makeText(act, "Shizuku no está activo", Toast.LENGTH_LONG).show()
        }
    }
}
