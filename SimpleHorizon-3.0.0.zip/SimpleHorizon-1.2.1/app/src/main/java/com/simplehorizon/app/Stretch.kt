package com.simplehorizon.app

import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.view.Display
import rikka.shizuku.Shizuku
import kotlin.math.roundToInt

/** Único juego soportado. */
object Game {
    const val NAME = "Blood Strike"
    const val PKG = "com.netease.newspike"
    const val ACTIVITY = "com.netease.game.MessiahNativeActivity"
}

object Stretch {
    private fun even(v: Int) = v / 2 * 2
    /** El ancho de la pantalla virtual va del largo del panel hasta el doble. */
    fun clamp(target: Int, nl: Int) = even(target.coerceIn(nl, nl * 2))
    fun default(nl: Int) = clamp(nl * 114 / 100, nl)
    fun pct(target: Int, nl: Int) = if (nl <= 0) 0.0 else (target - nl) * 100.0 / nl
}

/** Ajustes compartidos entre la pantalla principal y la ventana del juego. */
object Cfg {
    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("horizon", Context.MODE_PRIVATE)

    private fun display(c: Context): Display? =
        c.getSystemService(DisplayManager::class.java)?.getDisplay(Display.DEFAULT_DISPLAY)

    @Suppress("DEPRECATION")
    private fun real(c: Context): Point {
        val p = Point()
        display(c)?.getRealSize(p)
        return p
    }

    /** Lado largo y corto del panel (el sistema no se modifica, así que coincide con el físico). */
    fun nl(c: Context): Int = real(c).let { maxOf(it.x, it.y) }
    fun ns(c: Context): Int = real(c).let { minOf(it.x, it.y) }

    fun target(c: Context): Int {
        val n = nl(c)
        if (n == 0) return 0
        val t = prefs(c).getInt("tw", 0)
        return if (t == 0) Stretch.default(n) else Stretch.clamp(t, n)
    }

    fun setTarget(c: Context, t: Int) {
        val n = nl(c)
        if (n > 0) prefs(c).edit().putInt("tw", Stretch.clamp(t, n)).apply()
    }

    /** Frecuencia máxima que admite el panel. */
    fun maxHz(c: Context): Int = try {
        display(c)?.supportedModes?.maxOf { it.refreshRate }?.roundToInt() ?: 60
    } catch (_: Throwable) { 60 }

    /** Frecuencia pedida (60–144), limitada a lo que admite el panel. */
    fun hz(c: Context): Int = prefs(c).getInt("hz", 144).coerceIn(60, 144).coerceAtMost(maxHz(c).coerceAtLeast(60))
    fun setHz(c: Context, h: Int) { prefs(c).edit().putInt("hz", h).apply() }
}

object HorizonBridge {
    private const val REQ = 4243
    private const val VERSION = 11
    enum class State { NOT_RUNNING, NO_PERMISSION, READY, UNSUPPORTED }

    fun state(): State = try {
        when {
            !Shizuku.pingBinder() -> State.NOT_RUNNING
            Shizuku.isPreV11() -> State.UNSUPPORTED
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> State.READY
            else -> State.NO_PERMISSION
        }
    } catch (_: Throwable) {
        State.NOT_RUNNING
    }

    fun requestPermission() {
        try { Shizuku.requestPermission(REQ) } catch (_: Throwable) {}
    }

    fun serviceArgs(ctx: Context): Shizuku.UserServiceArgs =
        Shizuku.UserServiceArgs(ComponentName(ctx.packageName, HorizonService::class.java.name))
            .daemon(false).processNameSuffix("horizon").version(VERSION)
}
