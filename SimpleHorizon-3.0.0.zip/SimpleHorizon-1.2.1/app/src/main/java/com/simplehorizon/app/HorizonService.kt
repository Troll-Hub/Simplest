package com.simplehorizon.app

import android.content.Context
import android.content.ContextWrapper
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface

/** Servicio de Shizuku (uid shell): crea la pantalla virtual (a la frecuencia pedida), lanza el juego en ella e inyecta la entrada. */
class HorizonService() : IHorizonService.Stub() {
    private var baseCtx: Context? = null
    constructor(context: Context) : this() { baseCtx = context }

    private companion object {
        val PKG = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")
        const val VD_PUBLIC = 1
        const val VD_PRESENTATION = 1 shl 1
        const val VD_OWN_CONTENT_ONLY = 1 shl 3
        const val VD_SUPPORTS_TOUCH = 1 shl 6
        const val VD_DESTROY_CONTENT_ON_REMOVAL = 1 shl 8
        const val VD_TRUSTED = 1 shl 10
        const val VD_OWN_DISPLAY_GROUP = 1 shl 11
        const val VD_ALWAYS_UNLOCKED = 1 shl 12
        const val VD_TOUCH_FEEDBACK_DISABLED = 1 shl 13
        const val VD_OWN_FOCUS = 1 shl 14
    }

    private fun validPkg(p: String) = PKG.matches(p)

    private fun shShell(script: String): Pair<Int, String> = try {
        val p = ProcessBuilder("sh", "-c", script).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText().trim()
        p.waitFor() to out
    } catch (_: Exception) {
        -1 to ""
    }

    /**
     * Contexto que se presenta como el paquete del shell (uid 2000): el servidor de pantallas exige que el
     * nombre de paquete coincida con el uid que llama. El resto de llamadas se delega al Context base.
     */
    private class ShellContext(base: Context?) : ContextWrapper(base) {
        override fun getPackageName(): String = "com.android.shell"
        override fun getApplicationContext(): Context = this
        override fun getAttributionTag(): String? = null

        // El servidor de pantallas valida este nombre contra el uid que llama
        override fun getOpPackageName(): String = "com.android.shell"
    }

    @Volatile private var vd: VirtualDisplay? = null
    @Volatile private var vdErr = ""
    private var vdToken: IBinder? = null
    private val vdDeath = IBinder.DeathRecipient { stopDisplay() }

    override fun lastError(): String = vdErr

    override fun startDisplay(surface: Surface?, width: Int, height: Int, dpi: Int, hz: Float, token: IBinder?): Int {
        stopDisplay()
        vdErr = ""
        if (surface == null || !surface.isValid || width < 64 || height < 64 || dpi < 60) {
            vdErr = "superficie o tamaño no válidos (${width}x$height, $dpi dpi)"
            return -1
        }
        val sdk = Build.VERSION.SDK_INT
        // Sin ROTATES_WITH_CONTENT: la pantalla virtual no gira sola (el juego es siempre horizontal).
        val basic = VD_PUBLIC or VD_PRESENTATION or VD_OWN_CONTENT_ONLY or VD_SUPPORTS_TOUCH or
            VD_DESTROY_CONTENT_ON_REMOVAL
        var full = basic
        if (sdk >= 33) full = full or VD_TRUSTED or VD_OWN_DISPLAY_GROUP or VD_ALWAYS_UNLOCKED or VD_TOUCH_FEEDBACK_DISABLED
        if (sdk >= 34) full = full or VD_OWN_FOCUS
        // De más completo a más básico: si el sistema rechaza un flag, se prueba sin él
        val attempts = linkedSetOf(full, full and VD_OWN_FOCUS.inv(), full and VD_ALWAYS_UNLOCKED.inv() and VD_OWN_FOCUS.inv(), basic)
        for (f in attempts) {
            try {
                val ctor = DisplayManager::class.java.getDeclaredConstructor(Context::class.java)
                ctor.isAccessible = true
                val dm = ctor.newInstance(ShellContext(baseCtx))
                val viaConfig = if (hz > 0f) try { createWithConfig(dm, width, height, dpi, surface, f, hz) } catch (_: Throwable) { null } else null
                val v = viaConfig ?: dm.createVirtualDisplay("SimpleHorizon", width, height, dpi, surface, f) ?: continue
                vd = v
                vdToken = token
                try { token?.linkToDeath(vdDeath, 0) } catch (_: Throwable) {}
                return v.display.displayId
            } catch (e: Throwable) {
                val c = e.cause ?: e
                vdErr = "${c.javaClass.simpleName}: ${c.message}".take(200)
            }
        }
        return -1
    }

    /** Android 14+: VirtualDisplayConfig permite pedir la frecuencia; por defecto una pantalla virtual va a 60 Hz. */
    private fun createWithConfig(dm: DisplayManager, w: Int, h: Int, dpi: Int, surface: Surface, flags: Int, hz: Float): VirtualDisplay? {
        val cfgCls = Class.forName("android.hardware.display.VirtualDisplayConfig")
        val bCls = Class.forName("android.hardware.display.VirtualDisplayConfig\$Builder")
        val int = Int::class.javaPrimitiveType
        val bld = bCls.getConstructor(String::class.java, int, int, int).newInstance("SimpleHorizon", w, h, dpi)
        bCls.getMethod("setFlags", int).invoke(bld, flags)
        bCls.getMethod("setSurface", Surface::class.java).invoke(bld, surface)
        bCls.getMethod("setRequestedRefreshRate", Float::class.javaPrimitiveType).invoke(bld, hz)
        val cfg = bCls.getMethod("build").invoke(bld)
        for (m in DisplayManager::class.java.declaredMethods) {
            if (m.name != "createVirtualDisplay" || m.parameterTypes.none { it == cfgCls }) continue
            try {
                m.isAccessible = true
                val a = Array<Any?>(m.parameterTypes.size) { i -> if (m.parameterTypes[i] == cfgCls) cfg else null }
                val r = m.invoke(dm, *a) as? VirtualDisplay
                if (r != null) return r
            } catch (_: Throwable) {
            }
        }
        return null
    }

    override fun refreshRate(): Float = try { vd?.display?.refreshRate ?: 0f } catch (_: Throwable) { 0f }

    override fun setSurface(surface: Surface?) {
        try { vd?.setSurface(surface) } catch (_: Throwable) {}
    }

    override fun resize(width: Int, height: Int, dpi: Int) {
        if (width < 64 || height < 64 || dpi < 60) return
        try { vd?.resize(width, height, dpi) } catch (_: Throwable) {}
    }

    override fun stopDisplay() {
        val v = vd
        vd = null
        try { vdToken?.unlinkToDeath(vdDeath, 0) } catch (_: Throwable) {}
        vdToken = null
        try { v?.release() } catch (_: Throwable) {}
    }

    /** Abre el juego en la pantalla virtual (am start --display). */
    override fun launchOnDisplay(pkg: String, activity: String, displayId: Int): Boolean {
        if (!validPkg(pkg) || !validPkg(activity) || displayId <= 0) return false
        val (code, out) = shShell(
            "am start --display $displayId -n $pkg/$activity 2>&1"
        )
        val bad = out.contains("Error", true) || out.contains("Exception", true)
        if (bad) vdErr = out.lineSequence().firstOrNull { it.isNotBlank() }.orEmpty().take(200)
        return code == 0 && !bad
    }

    // --- Entrada: se inyecta en la pantalla virtual con el InputManager del sistema ---
    private var inputTarget: Any? = null
    private var injectM: java.lang.reflect.Method? = null
    private var setDisplayM: java.lang.reflect.Method? = null

    private fun ensureInput(): Boolean {
        if (injectM != null && inputTarget != null && setDisplayM != null) return true
        for (cn in arrayOf("android.hardware.input.InputManagerGlobal", "android.hardware.input.InputManager")) {
            try {
                val c = Class.forName(cn)
                val gi = c.getDeclaredMethod("getInstance")
                gi.isAccessible = true
                val inst = gi.invoke(null) ?: continue
                val m = c.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
                val sd = InputEvent::class.java.getMethod("setDisplayId", Int::class.javaPrimitiveType)
                inputTarget = inst; injectM = m; setDisplayM = sd
                return true
            } catch (_: Throwable) {
            }
        }
        vdErr = "no se pudo acceder al InputManager"
        return false
    }

    override fun injectTouch(event: MotionEvent?, displayId: Int) {
        if (event == null) return
        try {
            if (ensureInput()) {
                setDisplayM!!.invoke(event, displayId)
                injectM!!.invoke(inputTarget, event, 0) // 0 = asíncrono
            }
        } catch (_: Throwable) {
        } finally {
            try { event.recycle() } catch (_: Throwable) {}
        }
    }

    override fun injectKey(keyCode: Int, displayId: Int): Boolean {
        if (!ensureInput()) return false
        return try {
            val now = SystemClock.uptimeMillis()
            for (act in intArrayOf(KeyEvent.ACTION_DOWN, KeyEvent.ACTION_UP)) {
                val ev = KeyEvent(now, now, act, keyCode, 0, 0, -1, 0, 0, InputDevice.SOURCE_KEYBOARD)
                setDisplayM!!.invoke(ev, displayId)
                injectM!!.invoke(inputTarget, ev, 0)
            }
            true
        } catch (_: Throwable) {
            false
        }
    }

    override fun forceStop(pkg: String): Boolean =
        validPkg(pkg) && shShell("am force-stop $pkg").first == 0

    override fun probe(): String {
        val sb = StringBuilder()
        fun add(t: String, s: String) { sb.append("## ").append(t).append('\n').append(s.trim().take(900)).append("\n\n") }
        add("shell", shShell("id").second)
        add("android", shShell("getprop ro.build.version.release; getprop ro.build.version.sdk; getprop ro.product.manufacturer; getprop ro.product.model").second)
        add("frecuencias", shShell("dumpsys display 2>&1 | grep -m2 -o 'supportedRefreshRates \\[[^]]*\\]'").second)
        add("VirtualDisplayConfig.setRequestedRefreshRate", try {
            Class.forName("android.hardware.display.VirtualDisplayConfig\$Builder")
                .getMethod("setRequestedRefreshRate", Float::class.javaPrimitiveType)
            "disponible"
        } catch (e: Throwable) { "NO disponible (${e.javaClass.simpleName}): la pantalla virtual irá a 60 Hz" })
        add("pantalla virtual", "activa=${vd != null} id=${try { vd?.display?.displayId } catch (_: Throwable) { null }} hz=${refreshRate()} error=$vdErr")
        return sb.toString()
    }

    override fun destroy() {
        stopDisplay()
        System.exit(0)
    }
}
