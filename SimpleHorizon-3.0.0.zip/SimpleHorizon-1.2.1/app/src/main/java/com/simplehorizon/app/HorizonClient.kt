package com.simplehorizon.app

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.os.IBinder
import rikka.shizuku.Shizuku
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Conexión con el servicio de Shizuku (bloqueante: llamar desde un hilo de fondo). */
object HorizonClient {
    @Volatile var svc: IHorizonService? = null
    private var args: Shizuku.UserServiceArgs? = null
    private var conn: ServiceConnection? = null

    fun alive(): Boolean = try { svc?.asBinder()?.pingBinder() == true } catch (_: Throwable) { false }

    @Synchronized
    fun connect(ctx: Context): Boolean {
        if (svc != null && alive()) return true
        if (HorizonBridge.state() != HorizonBridge.State.READY) return false
        disconnect()
        val latch = CountDownLatch(1)
        val c = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                svc = if (binder != null && binder.pingBinder()) IHorizonService.Stub.asInterface(binder) else null
                latch.countDown()
            }
            override fun onServiceDisconnected(name: ComponentName?) { svc = null }
        }
        val a = HorizonBridge.serviceArgs(ctx.applicationContext)
        args = a
        conn = c
        try { Shizuku.bindUserService(a, c) } catch (_: Throwable) { return false }
        latch.await(10, TimeUnit.SECONDS)
        return svc != null
    }

    /** Cierra el servicio: libera la pantalla virtual y el juego que corre en ella. */
    @Synchronized
    fun disconnect() {
        try {
            val a = args
            val c = conn
            if (a != null && c != null) Shizuku.unbindUserService(a, c, true)
        } catch (_: Throwable) {}
        svc = null
        conn = null
        args = null
    }
}
