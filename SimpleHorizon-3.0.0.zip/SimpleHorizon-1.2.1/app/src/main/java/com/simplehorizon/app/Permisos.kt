package com.simplehorizon.app

import android.content.Context

object Permisos {
    fun instalado(c: Context) = try {
        c.packageManager.getPackageInfo(Game.PKG, 0)
        true
    } catch (_: Exception) {
        false
    }
}
