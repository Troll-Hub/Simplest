package com.simplehorizon.app

import android.app.Activity
import android.graphics.Matrix
import android.graphics.drawable.GradientDrawable
import android.os.Binder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * Muestra la pantalla virtual donde corre el juego. La superficie tiene el tamaño de la pantalla virtual (p. ej. 3526×1220)
 * y el sistema la escala a todo el panel: ese es el estiramiento. Los toques se reescalan y se inyectan en la pantalla virtual.
 */
class GameActivity : Activity(), SurfaceHolder.Callback {
    private val main = Handler(Looper.getMainLooper())
    private val bg = Executors.newSingleThreadExecutor { r -> Thread(r, "horizon-vd").apply { isDaemon = true } }
    private val token = Binder()
    private lateinit var sv: SurfaceView
    private lateinit var root: FrameLayout
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var readout: TextView? = null
    private var subTxt: TextView? = null
    private var seek: SeekBar? = null
    private var panelOpen = false

    @Volatile private var displayId = -1
    @Volatile private var vdW = 0
    @Volatile private var vdH = 0
    private var dpi = 0
    private var started = false
    private var hz = 144

    private val applyRunnable = Runnable { applySize() }

    private fun dp(v: Int) = Ui.dp(this, v)

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        val lp = window.attributes
        lp.layoutInDisplayCutoutMode = if (android.os.Build.VERSION.SDK_INT >= 30)
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        GameActivityState.active = true
        hz = Cfg.hz(this)
        pickDisplayMode(lp)
        window.attributes = lp

        dpi = resources.configuration.densityDpi
        vdW = Cfg.target(this)
        vdH = Cfg.ns(this)

        root = FrameLayout(this).apply { setBackgroundColor(Ui.BG) }
        sv = SurfaceView(this)
        sv.holder.setFixedSize(vdW, vdH) // el sistema escala este tamaño al panel: aquí está el estiramiento
        sv.holder.addCallback(this)
        sv.setOnTouchListener { v, ev -> forwardTouch(v, ev); true }
        root.addView(sv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        buildMenu()
        setContentView(root)
    }

    /** Pide al panel el modo con la frecuencia más cercana a la pedida (misma resolución). */
    @Suppress("DEPRECATION")
    private fun pickDisplayMode(lp: WindowManager.LayoutParams) {
        try {
            val d = windowManager.defaultDisplay
            val cur = d.mode
            val best = d.supportedModes
                .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
                .minByOrNull { abs(it.refreshRate - hz) }
            if (best != null) lp.preferredDisplayModeId = best.modeId
            lp.preferredRefreshRate = hz.toFloat()
        } catch (_: Throwable) {
        }
    }

    // ---------- Superficie y pantalla virtual ----------
    override fun surfaceCreated(holder: SurfaceHolder) {
        if (!started) {
            started = true
            bg.execute { startVirtual(holder.surface) }
        } else {
            bg.execute { try { HorizonClient.svc?.setSurface(holder.surface) } catch (_: Throwable) {} }
        }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            try { holder.surface.setFrameRate(hz.toFloat(), Surface.FRAME_RATE_COMPATIBILITY_DEFAULT) } catch (_: Throwable) {}
        }
        if (displayId > 0) bg.execute { try { HorizonClient.svc?.setSurface(holder.surface) } catch (_: Throwable) {} }
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        // Se queda el juego corriendo; solo se suelta la superficie hasta volver
        bg.execute { try { HorizonClient.svc?.setSurface(null) } catch (_: Throwable) {} }
    }

    private fun toast(t: String) = main.post { Toast.makeText(this, t, Toast.LENGTH_LONG).show() }

    private fun startVirtual(surface: Surface) {
        if (!HorizonClient.connect(applicationContext)) { toast("Shizuku no está activo o no tiene permiso"); main.post { finish() }; return }
        val s = HorizonClient.svc ?: return
        try {
            s.forceStop(Game.PKG) // que arranque de cero dentro de la pantalla virtual
            val id = s.startDisplay(surface, vdW, vdH, dpi, hz.toFloat(), token)
            if (id <= 0) { toast("No se pudo crear la pantalla virtual: " + s.lastError()); main.post { finish() }; return }
            displayId = id
            var ok = false
            for (i in 0 until 4) {
                if (s.launchOnDisplay(Game.PKG, Game.ACTIVITY, id)) { ok = true; break }
                Thread.sleep(500)
            }
            if (!ok) toast("No se pudo abrir ${Game.NAME}: " + s.lastError())
            main.post { refreshInfo() }
        } catch (e: Throwable) {
            toast("Error: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    // ---------- Entrada ----------
    private fun forwardTouch(v: View, ev: MotionEvent) {
        val id = displayId
        val s = HorizonClient.svc
        if (id <= 0 || s == null || v.width == 0 || v.height == 0) return
        val m = Matrix().apply { setScale(vdW.toFloat() / v.width, vdH.toFloat() / v.height) }
        val e = MotionEvent.obtain(ev)
        try {
            e.transform(m)
            s.injectTouch(e, id)
        } catch (_: Throwable) {
        } finally {
            e.recycle()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val id = displayId
        if (id > 0) bg.execute { try { HorizonClient.svc?.injectKey(KeyEvent.KEYCODE_BACK, id) } catch (_: Throwable) {} }
        else finish()
    }

    // ---------- Menú flotante ----------
    private fun buildMenu() {
        val size = dp(48)
        val bgc = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Ui.ACCENT) }
        val b = TextView(this).apply {
            text = "↔"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Ui.BG)
            background = bgc
            elevation = dp(8).toFloat()
            alpha = 0.75f
        }
        val blp = FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.START).apply { leftMargin = dp(12); topMargin = dp(80) }
        b.setOnTouchListener(drag(b, blp))
        root.addView(b, blp)
        bubble = b

        val rt = Ui.text(this, "", 22f, Ui.TXT, true)
        readout = rt
        val st = Ui.text(this, "", 11f, Ui.MUTED)
        subTxt = st
        val sb = SeekBar(this).apply {
            max = 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val n = Cfg.nl(this@GameActivity)
                    if (fromUser && n > 0) rt.text = "${Stretch.clamp(n + p, n)} × ${Cfg.ns(this@GameActivity)}"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    val n = Cfg.nl(this@GameActivity)
                    if (n > 0) setWidth(n + (s?.progress ?: 0))
                }
            })
        }
        seek = sb
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(10))
            background = Ui.round(this@GameActivity, Ui.CARD, 18, Ui.LINE)
            elevation = dp(10).toFloat()
            visibility = View.GONE
            isClickable = true
            addView(rt)
            addView(st)
            addView(sb)
            addView(chipRow("−50" to { bump(-50) }, "−10" to { bump(-10) }, "−1" to { bump(-1) }, "+1" to { bump(1) }, "+10" to { bump(10) }, "+50" to { bump(50) }))
            addView(chipRow("+5%" to { pct(5) }, "+14%" to { pct(14) }, "+20%" to { pct(20) }, "+30%" to { pct(30) }, "+40%" to { pct(40) }))
            addView(chipRow("Ocultar" to { setPanel(false) }, "Salir" to { exitGame() }))
        }
        root.addView(p, FrameLayout.LayoutParams(dp(300), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
        panel = p
        refreshInfo()
    }

    private fun chipRow(vararg items: Pair<String, () -> Unit>): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((t, f) in items) r.addView(Ui.chip(this, t, false, 8, 12f) { f() })
        return r
    }

    private fun drag(v: View, lp: FrameLayout.LayoutParams): View.OnTouchListener {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        return View.OnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = lp.leftMargin; sy = lp.topMargin; tx = e.rawX; ty = e.rawY; moved = false; v.alpha = 1f }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (!moved && abs(dx) + abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.leftMargin = (sx + dx).coerceIn(0, (root.width - v.width).coerceAtLeast(0))
                        lp.topMargin = (sy + dy).coerceIn(0, (root.height - v.height).coerceAtLeast(0))
                        v.layoutParams = lp
                        placePanel()
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!moved && e.actionMasked == MotionEvent.ACTION_UP) setPanel(!panelOpen)
                    v.alpha = 0.75f
                }
            }
            true
        }
    }

    private fun placePanel() {
        val p = panel ?: return
        val b = bubble ?: return
        val blp = b.layoutParams as FrameLayout.LayoutParams
        val plp = p.layoutParams as FrameLayout.LayoutParams
        val pw = dp(300)
        val ph = if (p.height > 0) p.height else dp(260)
        val right = blp.leftMargin + b.width / 2 > root.width / 2
        plp.leftMargin = (if (right) blp.leftMargin - pw - dp(8) else blp.leftMargin + b.width + dp(8)).coerceIn(0, (root.width - pw).coerceAtLeast(0))
        plp.topMargin = blp.topMargin.coerceIn(dp(8), (root.height - ph - dp(8)).coerceAtLeast(dp(8)))
        p.layoutParams = plp
    }

    private fun setPanel(open: Boolean) {
        panelOpen = open
        val p = panel ?: return
        if (open) { refreshInfo(); placePanel(); p.visibility = View.VISIBLE; p.post { placePanel() } } else p.visibility = View.GONE
    }

    private fun bump(d: Int) = setWidth(Cfg.target(this) + d)
    private fun pct(p: Int) { val n = Cfg.nl(this); setWidth(n + n * p / 100) }

    private fun setWidth(t: Int) {
        Cfg.setTarget(this, t)
        refreshInfo()
        main.removeCallbacks(applyRunnable)
        main.postDelayed(applyRunnable, 350)
    }

    /** Redimensiona la pantalla virtual y la superficie al nuevo ancho, en tiempo real. */
    private fun applySize() {
        val w = Cfg.target(this)
        val h = Cfg.ns(this)
        if (w == vdW && h == vdH) return
        vdW = w
        vdH = h
        bg.execute { try { HorizonClient.svc?.resize(w, h, dpi) } catch (_: Throwable) {} }
        sv.holder.setFixedSize(w, h)
    }

    private fun refreshInfo() {
        val n = Cfg.nl(this)
        val t = Cfg.target(this)
        readout?.text = "$t × ${Cfg.ns(this)}"
        subTxt?.text = "Panel $n × ${Cfg.ns(this)} · +" + String.format(Locale.US, "%.1f", Stretch.pct(t, n)) + "% · pedido ${hz} Hz"
        seek?.let { if (n > 0) { it.max = n; it.progress = (t - n).coerceIn(0, n) } }
        bg.execute {
            val r = try { HorizonClient.svc?.refreshRate() ?: 0f } catch (_: Throwable) { 0f }
            if (r > 0f) main.post { subTxt?.text = subTxt?.text.toString().replace(Regex("pedido \\d+ Hz.*"), "pedido $hz Hz · real ${Math.round(r)} Hz") }
        }
    }

    private fun exitGame() {
        finish()
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        if (isFinishing) {
            GameActivityState.active = false
            // Cierra la pantalla virtual y el juego que corre en ella
            Thread({
                try { HorizonClient.svc?.forceStop(Game.PKG) } catch (_: Throwable) {}
                HorizonClient.disconnect()
            }, "horizon-stop").start()
        }
        super.onDestroy()
    }
}
