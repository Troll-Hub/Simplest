package com.simplehorizon.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/** Pantalla principal: ancho de la pantalla virtual, frecuencia y arranque del juego. */
class MainActivity : Activity() {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var readout: TextView
    private lateinit var sub: TextView
    private lateinit var seek: SeekBar
    private lateinit var edit: EditText
    private lateinit var shizukuTxt: TextView
    private lateinit var gameTxt: TextView
    private lateinit var hzTxt: TextView
    private val hzChips = mutableListOf<Pair<Int, TextView>>()
    private var seeking = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun commit(t: Int) {
        Cfg.setTarget(this, t)
        refresh()
    }

    private fun bump(d: Int) = commit(Cfg.target(this) + d)
    private fun pct(p: Int) { val n = Cfg.nl(this); commit(n + n * p / 100) }

    private fun buildUi(): View {
        val c = this
        val scroll = ScrollView(c).apply { setBackgroundColor(Ui.BG) }
        val col = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, Ui.dp(c, 28), 0, Ui.dp(c, 32))
        }
        scroll.addView(col)
        col.addView(Ui.text(c, "SimpleHorizon", 28f, Ui.TXT, true).apply { setPadding(Ui.dp(c, 20), 0, Ui.dp(c, 20), 0) })
        col.addView(Ui.text(c, "${Game.NAME} en pantalla virtual estirada a los lados", 13f, Ui.MUTED).apply {
            setPadding(Ui.dp(c, 20), Ui.dp(c, 2), Ui.dp(c, 20), Ui.dp(c, 8))
        })

        val st = Ui.card(c)
        shizukuTxt = Ui.text(c, "", 14f, Ui.TXT, true)
        shizukuTxt.setOnClickListener {
            if (HorizonBridge.state() == HorizonBridge.State.NO_PERMISSION) HorizonBridge.requestPermission()
            refresh()
        }
        st.addView(shizukuTxt)
        gameTxt = Ui.text(c, "", 12f, Ui.MUTED)
        st.addView(gameTxt)
        col.addView(st)

        val es = Ui.card(c)
        es.addView(Ui.text(c, "PANTALLA VIRTUAL (HORIZONTAL)", 12f, Ui.MUTED, true))
        readout = Ui.text(c, "", 36f, Ui.TXT, true)
        es.addView(readout)
        sub = Ui.text(c, "", 12f, Ui.MUTED)
        es.addView(sub)
        seek = SeekBar(c).apply {
            max = 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val n = Cfg.nl(c)
                    if (fromUser && n > 0) readout.text = "${Stretch.clamp(n + p, n)} × ${Cfg.ns(c)}"
                }
                override fun onStartTrackingTouch(s: SeekBar?) { seeking = true }
                override fun onStopTrackingTouch(s: SeekBar?) { seeking = false; commit(Cfg.nl(c) + seek.progress) }
            })
        }
        es.addView(seek)
        es.addView(chipRow("−50" to { bump(-50) }, "−10" to { bump(-10) }, "+10" to { bump(10) }, "+50" to { bump(50) }))
        es.addView(chipRow("+5%" to { pct(5) }, "+10%" to { pct(10) }, "+14%" to { pct(14) }, "+20%" to { pct(20) }, "+30%" to { pct(30) }))
        val exact = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        edit = EditText(c).apply {
            hint = "Ancho exacto (ej. 3526)"
            setHintTextColor(Ui.MUTED)
            setTextColor(Ui.TXT)
            textSize = 14f
            inputType = InputType.TYPE_CLASS_NUMBER
            background = Ui.round(c, Ui.CHIP, 12)
            setPadding(Ui.dp(c, 12), Ui.dp(c, 10), Ui.dp(c, 12), Ui.dp(c, 10))
        }
        exact.addView(edit, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { topMargin = Ui.dp(c, 8) })
        exact.addView(Ui.chip(c, "Fijar", true, 12) {
            val v = edit.text.toString().toIntOrNull()
            val n = Cfg.nl(c)
            if (v == null || v < n || v > n * 2) Toast.makeText(c, "Debe estar entre $n y ${n * 2}", Toast.LENGTH_SHORT).show()
            else { commit(v); edit.setText("") }
        }.apply { layoutParams = LinearLayout.LayoutParams(Ui.dp(c, 84), ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(c, 8); leftMargin = Ui.dp(c, 8) } })
        es.addView(exact)
        col.addView(es)

        val hz = Ui.card(c)
        hz.addView(Ui.text(c, "FRECUENCIA DE LA PANTALLA VIRTUAL", 12f, Ui.MUTED, true))
        val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        for (v in intArrayOf(60, 90, 120, 144)) {
            val chip = Ui.chip(c, "$v Hz", false, 10, 13f) { Cfg.setHz(c, v); refresh() }
            hzChips.add(v to chip)
            row.addView(chip)
        }
        hz.addView(row)
        hzTxt = Ui.text(c, "", 11f, Ui.MUTED)
        hzTxt.setPadding(0, Ui.dp(c, 8), 0, 0)
        hz.addView(hzTxt)
        col.addView(hz)

        val jg = Ui.card(c)
        jg.addView(Ui.button(c, "INICIAR ${Game.NAME.uppercase()}", true) { Stretcher.start(c) })
        jg.addView(Ui.text(c, "El juego corre en una pantalla virtual y se muestra estirado en toda la pantalla. Cambiar la frecuencia o el ancho se aplica al iniciar o desde el menú flotante (↔).", 11f, Ui.MUTED).apply { setPadding(0, Ui.dp(c, 10), 0, 0) })
        col.addView(jg)

        val dg = Ui.card(c)
        dg.addView(Ui.button(c, "Diagnóstico (copiar)", false) { diagnostics() })
        col.addView(dg)
        return scroll
    }

    private fun chipRow(vararg items: Pair<String, () -> Unit>): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((t, f) in items) r.addView(Ui.chip(this, t, false, 10, 13f) { f() })
        return r
    }

    private fun diagnostics() {
        val app = applicationContext
        Thread({
            val ok = HorizonClient.connect(app)
            val body = if (ok) (try { HorizonClient.svc?.probe() ?: "" } catch (e: Throwable) { "Error: ${e.message}" }) else "Shizuku no está conectado."
            val text = "SimpleHorizon ${version()}\npanel=${Cfg.nl(app)}x${Cfg.ns(app)} ancho_virtual=${Cfg.target(app)} hz_pedido=${Cfg.hz(app)} hz_max_panel=${Cfg.maxHz(app)}\n\n$body"
            if (!GameActivityState.active) HorizonClient.disconnect()
            main.post { showCopyable("Diagnóstico", text) }
        }, "diagnostics").start()
    }

    private fun version(): String = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "?" } catch (_: Exception) { "?" }

    private fun showCopyable(title: String, text: String) {
        val c = this
        val body = TextView(c).apply {
            this.text = text
            textSize = 11f
            setTextColor(Ui.TXT)
            setTextIsSelectable(true)
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(Ui.dp(c, 16), Ui.dp(c, 8), Ui.dp(c, 16), Ui.dp(c, 8))
        }
        val dialog = AlertDialog.Builder(c, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(title)
            .setView(ScrollView(c).apply { addView(body) })
            .setPositiveButton("Cerrar", null)
            .setNeutralButton("Copiar todo", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val cm = getSystemService(android.content.ClipboardManager::class.java)
                cm.setPrimaryClip(android.content.ClipData.newPlainText(title, text))
                Toast.makeText(c, "Copiado", Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()
    }

    private fun refresh() {
        val c = this
        val n = Cfg.nl(c)
        val t = Cfg.target(c)
        if (!seeking) readout.text = "$t × ${Cfg.ns(c)}"
        sub.text = "Panel $n × ${Cfg.ns(c)} · +" + String.format(Locale.US, "%.1f", Stretch.pct(t, n)) + "%"
        seek.max = n
        if (!seeking) seek.progress = (t - n).coerceIn(0, n)
        shizukuTxt.text = when (HorizonBridge.state()) {
            HorizonBridge.State.READY -> "✓ Shizuku listo"
            HorizonBridge.State.NO_PERMISSION -> "✗ Shizuku sin permiso · toca para conceder"
            HorizonBridge.State.NOT_RUNNING -> "✗ Shizuku no está activo"
            HorizonBridge.State.UNSUPPORTED -> "✗ Versión de Shizuku no compatible"
        }
        gameTxt.text = if (Permisos.instalado(c)) "${Game.NAME} instalado" else "${Game.NAME} no está instalado"
        val sel = Cfg.hz(c)
        val max = Cfg.maxHz(c)
        for ((v, chip) in hzChips) {
            Ui.paintChip(c, chip, v == sel)
            chip.alpha = if (v <= max) 1f else 0.35f
        }
        hzTxt.text = "Tu panel admite hasta $max Hz. Se pide ${sel} Hz; el valor real se ve en el menú flotante."
    }
}

/** Marca simple para no cerrar el servicio de Shizuku desde el diagnóstico mientras el juego está abierto. */
object GameActivityState { @Volatile var active = false }
